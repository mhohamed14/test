//
//  BurgerOrderAppCartViewController.swift
//  Food UI Kit
//
//  Created by [Author].
//  Copyright © 2018 [Company]. All rights reserved.
//

// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Import

import UIKit


// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Implementation

class BurgerOrderAppCartViewController: UIViewController {


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Properties

    @IBOutlet var rectangleCopy5View: UIView!
    @IBOutlet var rectangleCopy4View: UIView!
    @IBOutlet var group3View: UIView!
    @IBOutlet var group8Button: SupernovaButton!
    @IBOutlet var group3CopyView: UIView!
    @IBOutlet var group8TwoButton: SupernovaButton!
    @IBOutlet var labelLabel: SupernovaLabel!
    @IBOutlet var labelTwoLabel: SupernovaLabel!
    @IBOutlet var rectangleCopy6View: UIView!
    @IBOutlet var rectangleCopy4TwoView: UIView!
    @IBOutlet var group3TwoView: UIView!
    @IBOutlet var group8ThreeButton: SupernovaButton!
    @IBOutlet var group3CopyTwoView: UIView!
    @IBOutlet var group8FourButton: SupernovaButton!
    @IBOutlet var labelThreeLabel: SupernovaLabel!
    @IBOutlet var labelFourLabel: SupernovaLabel!
    @IBOutlet var rectangleCopy4ThreeView: UIView!
    @IBOutlet var group3ThreeView: UIView!
    @IBOutlet var group8FiveButton: SupernovaButton!
    @IBOutlet var group3CopyThreeView: UIView!
    @IBOutlet var group8SixButton: SupernovaButton!
    @IBOutlet var labelFiveLabel: SupernovaLabel!
    @IBOutlet var labelSixLabel: SupernovaLabel!
    @IBOutlet var rectangleCopy7View: UIView!
    @IBOutlet var rectangleCopy4FourView: UIView!
    @IBOutlet var group3FourView: UIView!
    @IBOutlet var group3CopyFourView: UIView!
    @IBOutlet var labelSevenLabel: SupernovaLabel!
    @IBOutlet var labelEightLabel: SupernovaLabel!
    @IBOutlet var rectangleCopy5TwoView: UIView!
    @IBOutlet var rectangleCopy4FiveView: UIView!
    @IBOutlet var group3FiveView: UIView!
    @IBOutlet var group3CopyFiveView: UIView!
    @IBOutlet var labelNineLabel: SupernovaLabel!
    @IBOutlet var labelTenLabel: SupernovaLabel!
    @IBOutlet var nextButton: SupernovaButton!
    @IBOutlet var buttonView: UIView!
    @IBOutlet var groupButton: SupernovaButton!
    @IBOutlet var groupCopyView: UIView!
    @IBOutlet var totalLabel: SupernovaLabel!
    @IBOutlet var labelElevenLabel: SupernovaLabel!


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Lifecycle

    override public func viewDidLoad()  {
        super.viewDidLoad()
        self.setupComponents()
        self.setupUI()
        self.setupGestureRecognizers()
        self.setupLocalization()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override public func viewWillAppear(_ animated: Bool)  {
        super.viewWillAppear(animated)
        
        // Navigation bar, if any
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Setup

    private func setupComponents()  {
        // Setup rectangleCopy5View
        self.rectangleCopy5View.layer.cornerRadius = 0.5
        self.rectangleCopy5View.layer.masksToBounds = true
        
        // Setup rectangleCopy4View
        self.rectangleCopy4View.layer.cornerRadius = 22
        self.rectangleCopy4View.layer.masksToBounds = true
        
        // Setup group3View
        self.group3View.layer.borderColor = UIColor(red: 0.953, green: 0.953, blue: 0.953, alpha: 1).cgColor /* #F3F3F3 */
        self.group3View.layer.borderWidth = 1
        
        self.group3View.layer.cornerRadius = 10
        self.group3View.layer.masksToBounds = true
        
        // Setup group8Button
        self.group8Button.snImageTextSpacing = 10
        
        // Setup group3CopyView
        self.group3CopyView.layer.borderColor = UIColor(red: 0.952, green: 0.952, blue: 0.952, alpha: 1).cgColor /* #F3F3F3 */
        self.group3CopyView.layer.borderWidth = 1
        
        self.group3CopyView.layer.cornerRadius = 10
        self.group3CopyView.layer.masksToBounds = true
        
        // Setup group8TwoButton
        self.group8TwoButton.snImageTextSpacing = 10
        
        // Setup labelLabel
        let labelLabelAttrString = NSMutableAttributedString(string: "3", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 16)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 16, paragraphSpacing: 0)
        ])
        self.labelLabel.attributedText = labelLabelAttrString
        
        // Setup labelTwoLabel
        let labelTwoLabelAttrString = NSMutableAttributedString(string: "$30.20", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 18)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 16, paragraphSpacing: 0)
        ])
        self.labelTwoLabel.attributedText = labelTwoLabelAttrString
        
        // Setup rectangleCopy6View
        self.rectangleCopy6View.layer.cornerRadius = 0.5
        self.rectangleCopy6View.layer.masksToBounds = true
        
        // Setup rectangleCopy4TwoView
        self.rectangleCopy4TwoView.layer.cornerRadius = 22
        self.rectangleCopy4TwoView.layer.masksToBounds = true
        
        // Setup group3TwoView
        self.group3TwoView.layer.borderColor = UIColor(red: 0.952, green: 0.952, blue: 0.952, alpha: 1).cgColor /* #F3F3F3 */
        self.group3TwoView.layer.borderWidth = 1
        
        self.group3TwoView.layer.cornerRadius = 10
        self.group3TwoView.layer.masksToBounds = true
        
        // Setup group8ThreeButton
        self.group8ThreeButton.snImageTextSpacing = 10
        
        // Setup group3CopyTwoView
        self.group3CopyTwoView.layer.borderColor = UIColor(red: 0.952, green: 0.952, blue: 0.952, alpha: 1).cgColor /* #F3F3F3 */
        self.group3CopyTwoView.layer.borderWidth = 1
        
        self.group3CopyTwoView.layer.cornerRadius = 10
        self.group3CopyTwoView.layer.masksToBounds = true
        
        // Setup group8FourButton
        self.group8FourButton.snImageTextSpacing = 10
        
        // Setup labelThreeLabel
        let labelThreeLabelAttrString = NSMutableAttributedString(string: "2", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 16)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 16, paragraphSpacing: 0)
        ])
        self.labelThreeLabel.attributedText = labelThreeLabelAttrString
        
        // Setup labelFourLabel
        let labelFourLabelAttrString = NSMutableAttributedString(string: "$25.30", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 18)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 16, paragraphSpacing: 0)
        ])
        self.labelFourLabel.attributedText = labelFourLabelAttrString
        
        // Setup rectangleCopy4ThreeView
        self.rectangleCopy4ThreeView.layer.cornerRadius = 22
        self.rectangleCopy4ThreeView.layer.masksToBounds = true
        
        // Setup group3ThreeView
        self.group3ThreeView.layer.borderColor = UIColor(red: 0.952, green: 0.952, blue: 0.952, alpha: 1).cgColor /* #F3F3F3 */
        self.group3ThreeView.layer.borderWidth = 1
        
        self.group3ThreeView.layer.cornerRadius = 10
        self.group3ThreeView.layer.masksToBounds = true
        
        // Setup group8FiveButton
        self.group8FiveButton.snImageTextSpacing = 10
        
        // Setup group3CopyThreeView
        self.group3CopyThreeView.layer.borderColor = UIColor(red: 0.952, green: 0.952, blue: 0.952, alpha: 1).cgColor /* #F3F3F3 */
        self.group3CopyThreeView.layer.borderWidth = 1
        
        self.group3CopyThreeView.layer.cornerRadius = 10
        self.group3CopyThreeView.layer.masksToBounds = true
        
        // Setup group8SixButton
        self.group8SixButton.snImageTextSpacing = 10
        
        // Setup labelFiveLabel
        let labelFiveLabelAttrString = NSMutableAttributedString(string: "1", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 16)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 16, paragraphSpacing: 0)
        ])
        self.labelFiveLabel.attributedText = labelFiveLabelAttrString
        
        // Setup labelSixLabel
        let labelSixLabelAttrString = NSMutableAttributedString(string: "$25.30", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 18)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 16, paragraphSpacing: 0)
        ])
        self.labelSixLabel.attributedText = labelSixLabelAttrString
        
        // Setup rectangleCopy7View
        self.rectangleCopy7View.layer.cornerRadius = 0.5
        self.rectangleCopy7View.layer.masksToBounds = true
        
        // Setup rectangleCopy4FourView
        self.rectangleCopy4FourView.layer.cornerRadius = 22
        self.rectangleCopy4FourView.layer.masksToBounds = true
        
        // Setup group3FourView
        self.group3FourView.layer.borderColor = UIColor(red: 0.952, green: 0.952, blue: 0.952, alpha: 1).cgColor /* #F3F3F3 */
        self.group3FourView.layer.borderWidth = 1
        
        self.group3FourView.layer.cornerRadius = 10
        self.group3FourView.layer.masksToBounds = true
        
        // Setup group3CopyFourView
        self.group3CopyFourView.layer.borderColor = UIColor(red: 0.952, green: 0.952, blue: 0.952, alpha: 1).cgColor /* #F3F3F3 */
        self.group3CopyFourView.layer.borderWidth = 1
        
        self.group3CopyFourView.layer.cornerRadius = 10
        self.group3CopyFourView.layer.masksToBounds = true
        
        // Setup labelSevenLabel
        let labelSevenLabelAttrString = NSMutableAttributedString(string: "1", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 16)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 16, paragraphSpacing: 0)
        ])
        self.labelSevenLabel.attributedText = labelSevenLabelAttrString
        
        // Setup labelEightLabel
        let labelEightLabelAttrString = NSMutableAttributedString(string: "$55.35", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 18)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 16, paragraphSpacing: 0)
        ])
        self.labelEightLabel.attributedText = labelEightLabelAttrString
        
        // Setup rectangleCopy5TwoView
        self.rectangleCopy5TwoView.layer.cornerRadius = 0.5
        self.rectangleCopy5TwoView.layer.masksToBounds = true
        
        // Setup rectangleCopy4FiveView
        self.rectangleCopy4FiveView.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.05).cgColor /* #000000 */
        self.rectangleCopy4FiveView.layer.shadowOffset = CGSize(width: 0, height: -1)
        self.rectangleCopy4FiveView.layer.shadowRadius = 3
        self.rectangleCopy4FiveView.layer.shadowOpacity = 1
        
        self.rectangleCopy4FiveView.layer.cornerRadius = 22
        self.rectangleCopy4FiveView.layer.masksToBounds = true
        
        // Setup group3FiveView
        self.group3FiveView.layer.borderColor = UIColor(red: 0.952, green: 0.952, blue: 0.952, alpha: 1).cgColor /* #F3F3F3 */
        self.group3FiveView.layer.borderWidth = 1
        
        self.group3FiveView.layer.cornerRadius = 10
        self.group3FiveView.layer.masksToBounds = true
        
        // Setup group3CopyFiveView
        self.group3CopyFiveView.layer.borderColor = UIColor(red: 0.952, green: 0.952, blue: 0.952, alpha: 1).cgColor /* #F3F3F3 */
        self.group3CopyFiveView.layer.borderWidth = 1
        
        self.group3CopyFiveView.layer.cornerRadius = 10
        self.group3CopyFiveView.layer.masksToBounds = true
        
        // Setup labelNineLabel
        let labelNineLabelAttrString = NSMutableAttributedString(string: "2", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 16)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 16, paragraphSpacing: 0)
        ])
        self.labelNineLabel.attributedText = labelNineLabelAttrString
        
        // Setup labelTenLabel
        let labelTenLabelAttrString = NSMutableAttributedString(string: "$20.60", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 18)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 16, paragraphSpacing: 0)
        ])
        self.labelTenLabel.attributedText = labelTenLabelAttrString
        
        // Setup nextButton
        self.nextButton.snImageTextSpacing = 10
        
        // Setup buttonView
        self.buttonView.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.05).cgColor /* #000000 */
        self.buttonView.layer.shadowOffset = CGSize(width: 0, height: -1)
        self.buttonView.layer.shadowRadius = 3
        self.buttonView.layer.shadowOpacity = 1
        
        self.buttonView.layer.cornerRadius = 12
        self.buttonView.layer.masksToBounds = true
        
        // Setup groupButton
        self.groupButton.layer.cornerRadius = 4
        self.groupButton.layer.masksToBounds = true
        self.groupButton.snImageTextSpacing = 10
        
        // Setup groupCopyView
        self.groupCopyView.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.02).cgColor /* #000000 */
        self.groupCopyView.layer.shadowOffset = CGSize(width: 0, height: 2)
        self.groupCopyView.layer.shadowRadius = 8
        self.groupCopyView.layer.shadowOpacity = 1
        
        self.groupCopyView.layer.cornerRadius = 4
        self.groupCopyView.layer.masksToBounds = true
        
        // Setup totalLabel
        let totalLabelAttrString = NSMutableAttributedString(string: "Total", attributes: [
            .font : UIFont(name: "Avenir-Book", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 12, paragraphSpacing: 0)
        ])
        self.totalLabel.attributedText = totalLabelAttrString
        
        // Setup labelElevenLabel
        let labelElevenLabelAttrString = NSMutableAttributedString(string: "$306.35", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.labelElevenLabel.attributedText = labelElevenLabelAttrString
        
    }

    private func setupUI()  {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    private func setupGestureRecognizers()  {
    
    }

    private func setupLocalization()  {
    
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Status Bar

    override public var prefersStatusBarHidden: Bool  {
        return false
    }

    override public var preferredStatusBarStyle: UIStatusBarStyle  {
        return .default
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Actions

    @IBAction public func onGroup8Pressed(_ sender: UIButton)  {
    
    }

    @IBAction public func onGroup8TwoPressed(_ sender: UIButton)  {
    
    }

    @IBAction public func onGroup8ThreePressed(_ sender: UIButton)  {
    
    }

    @IBAction public func onGroup8FourPressed(_ sender: UIButton)  {
    
    }

    @IBAction public func onGroup8FivePressed(_ sender: UIButton)  {
    
    }

    @IBAction public func onGroup8SixPressed(_ sender: UIButton)  {
    
    }

    @IBAction public func onNextPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Cart Delete", sender: nil)
    }

    @IBAction public func onGroupPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push User Review", sender: nil)
    }
}
