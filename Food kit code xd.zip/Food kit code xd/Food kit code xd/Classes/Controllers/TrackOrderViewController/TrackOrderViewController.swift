//
//  TrackOrderViewController.swift
//  Food UI Kit
//
//  Created by [Author].
//  Copyright © 2018 [Company]. All rights reserved.
//

// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Import

import UIKit


// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Implementation

class TrackOrderViewController: UIViewController {


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Properties

    @IBOutlet var rectangleView: UIView!
    @IBOutlet var rectangleButton: SupernovaButton!
    @IBOutlet var minLabel: SupernovaLabel!
    @IBOutlet var backButton: SupernovaButton!
    @IBOutlet var groupView: UIView!
    @IBOutlet var buttonButton: SupernovaButton!
    @IBOutlet var orderNo1454530Label: SupernovaLabel!
    @IBOutlet var trackingOrderLabel: SupernovaLabel!
    @IBOutlet var rectangleTwoView: UIView!
    @IBOutlet var mahfuzAliLabel: SupernovaLabel!
    @IBOutlet var deliveryManLabel: SupernovaLabel!


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Lifecycle

    override public func viewDidLoad()  {
        super.viewDidLoad()
        self.setupComponents()
        self.setupUI()
        self.setupGestureRecognizers()
        self.setupLocalization()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override public func viewWillAppear(_ animated: Bool)  {
        super.viewWillAppear(animated)
        
        // Navigation bar, if any
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Setup

    private func setupComponents()  {
        // Setup rectangleView
        self.rectangleView.layer.cornerRadius = 6
        self.rectangleView.layer.masksToBounds = true
        
        // Setup rectangleButton
        self.rectangleButton.layer.cornerRadius = 6
        self.rectangleButton.layer.masksToBounds = true
        self.rectangleButton.snImageTextSpacing = 10
        
        // Setup minLabel
        let minLabelAttrString = NSMutableAttributedString(string: "20 min", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.minLabel.attributedText = minLabelAttrString
        
        // Setup backButton
        self.backButton.snImageTextSpacing = 10
        
        // Setup groupView
        self.groupView.layer.shadowColor = UIColor(red: 0.827, green: 0.851, blue: 0.89, alpha: 0.149).cgColor /* #D3D9E3 */
        self.groupView.layer.shadowOffset = CGSize(width: 0, height: 2)
        self.groupView.layer.shadowRadius = 7
        self.groupView.layer.shadowOpacity = 1
        
        self.groupView.layer.cornerRadius = 24
        self.groupView.layer.masksToBounds = true
        
        // Setup buttonButton
        self.buttonButton.layer.cornerRadius = 4
        self.buttonButton.layer.masksToBounds = true
        self.buttonButton.snImageTextSpacing = 10
        
        // Setup orderNo1454530Label
        let orderNo1454530LabelAttrString = NSMutableAttributedString(string: "Order No: 1454530", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.97, green: 0.77, blue: 0.19, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.orderNo1454530Label.attributedText = orderNo1454530LabelAttrString
        
        // Setup trackingOrderLabel
        let trackingOrderLabelAttrString = NSMutableAttributedString(string: "Tracking Order", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 18)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 18, paragraphSpacing: 0)
        ])
        self.trackingOrderLabel.attributedText = trackingOrderLabelAttrString
        
        // Setup rectangleTwoView
        self.rectangleTwoView.layer.cornerRadius = 12
        self.rectangleTwoView.layer.masksToBounds = true
        
        // Setup mahfuzAliLabel
        let mahfuzAliLabelAttrString = NSMutableAttributedString(string: "Mahfuz Ali", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 18)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 18, paragraphSpacing: 0)
        ])
        self.mahfuzAliLabel.attributedText = mahfuzAliLabelAttrString
        
        // Setup deliveryManLabel
        let deliveryManLabelAttrString = NSMutableAttributedString(string: "Delivery Man", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.deliveryManLabel.attributedText = deliveryManLabelAttrString
        
    }

    private func setupUI()  {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    private func setupGestureRecognizers()  {
    
    }

    private func setupLocalization()  {
    
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Status Bar

    override public var prefersStatusBarHidden: Bool  {
        return false
    }

    override public var preferredStatusBarStyle: UIStatusBarStyle  {
        return .default
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Actions

    @IBAction public func onRectanglePressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Notification", sender: nil)
    }

    @IBAction public func onBackPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Order Details", sender: nil)
    }

    @IBAction public func onButtonPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Offer and promos Expired", sender: nil)
    }
}
