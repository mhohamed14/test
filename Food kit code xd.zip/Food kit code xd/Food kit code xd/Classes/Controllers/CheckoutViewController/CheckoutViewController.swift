//
//  CheckoutViewController.swift
//  Food UI Kit
//
//  Created by [Author].
//  Copyright © 2018 [Company]. All rights reserved.
//

// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Import

import UIKit


// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Implementation

class CheckoutViewController: UIViewController {


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Properties

    @IBOutlet var bgView: UIView!
    @IBOutlet var rectangleCopy7View: UIView!
    @IBOutlet var selectedButton: SupernovaButton!
    @IBOutlet var homeLabel: SupernovaLabel!
    @IBOutlet var visaView: UIView!
    @IBOutlet var rectangleCopy7TwoView: UIView!
    @IBOutlet var visaCardLabel: SupernovaLabel!
    @IBOutlet var paypalView: UIView!
    @IBOutlet var rectangleCopy7ThreeView: UIView!
    @IBOutlet var paypalLabel: SupernovaLabel!
    @IBOutlet var appleView: UIView!
    @IBOutlet var rectangleCopy7FourView: UIView!
    @IBOutlet var applePayLabel: SupernovaLabel!
    @IBOutlet var rectangleCopy7FiveView: UIView!
    @IBOutlet var selectedTwoButton: SupernovaButton!
    @IBOutlet var rectangleCopy7SixView: UIView!
    @IBOutlet var payAfterReciveDelLabel: SupernovaLabel!
    @IBOutlet var cashOnDeliveryLabel: SupernovaLabel!
    @IBOutlet var buttonButton: SupernovaButton!
    @IBOutlet var backButton: SupernovaButton!


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Lifecycle

    override public func viewDidLoad()  {
        super.viewDidLoad()
        self.setupComponents()
        self.setupUI()
        self.setupGestureRecognizers()
        self.setupLocalization()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override public func viewWillAppear(_ animated: Bool)  {
        super.viewWillAppear(animated)
        
        // Navigation bar, if any
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Setup

    private func setupComponents()  {
        // Setup bgView
        self.bgView.layer.shadowColor = UIColor(red: 0.827, green: 0.851, blue: 0.89, alpha: 0.149).cgColor /* #D3D9E3 */
        self.bgView.layer.shadowOffset = CGSize(width: 0, height: 2)
        self.bgView.layer.shadowRadius = 7
        self.bgView.layer.shadowOpacity = 1
        
        self.bgView.layer.cornerRadius = 12
        self.bgView.layer.masksToBounds = true
        
        // Setup rectangleCopy7View
        self.rectangleCopy7View.layer.cornerRadius = 9
        self.rectangleCopy7View.layer.masksToBounds = true
        
        // Setup selectedButton
        self.selectedButton.snImageTextSpacing = 10
        
        // Setup homeLabel
        let homeLabelAttrString = NSMutableAttributedString(string: "Home", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.homeLabel.attributedText = homeLabelAttrString
        
        // Setup visaView
        self.visaView.layer.cornerRadius = 9
        self.visaView.layer.masksToBounds = true
        
        // Setup rectangleCopy7TwoView
        self.rectangleCopy7TwoView.layer.cornerRadius = 7
        self.rectangleCopy7TwoView.layer.masksToBounds = true
        
        // Setup visaCardLabel
        let visaCardLabelAttrString = NSMutableAttributedString(string: "Visa Card", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.visaCardLabel.attributedText = visaCardLabelAttrString
        
        // Setup paypalView
        self.paypalView.layer.cornerRadius = 9
        self.paypalView.layer.masksToBounds = true
        
        // Setup rectangleCopy7ThreeView
        self.rectangleCopy7ThreeView.layer.cornerRadius = 7
        self.rectangleCopy7ThreeView.layer.masksToBounds = true
        
        // Setup paypalLabel
        let paypalLabelAttrString = NSMutableAttributedString(string: "Paypal", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.paypalLabel.attributedText = paypalLabelAttrString
        
        // Setup appleView
        self.appleView.layer.cornerRadius = 9
        self.appleView.layer.masksToBounds = true
        
        // Setup rectangleCopy7FourView
        self.rectangleCopy7FourView.layer.cornerRadius = 7
        self.rectangleCopy7FourView.layer.masksToBounds = true
        
        // Setup applePayLabel
        let applePayLabelAttrString = NSMutableAttributedString(string: "Apple Pay", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.applePayLabel.attributedText = applePayLabelAttrString
        
        // Setup rectangleCopy7FiveView
        self.rectangleCopy7FiveView.layer.cornerRadius = 9
        self.rectangleCopy7FiveView.layer.masksToBounds = true
        
        // Setup selectedTwoButton
        self.selectedTwoButton.snImageTextSpacing = 10
        
        // Setup rectangleCopy7SixView
        self.rectangleCopy7SixView.layer.cornerRadius = 7
        self.rectangleCopy7SixView.layer.masksToBounds = true
        
        // Setup payAfterReciveDelLabel
        let payAfterReciveDelLabelAttrString = NSMutableAttributedString(string: "Pay after recive delivery", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.payAfterReciveDelLabel.attributedText = payAfterReciveDelLabelAttrString
        
        // Setup cashOnDeliveryLabel
        let cashOnDeliveryLabelAttrString = NSMutableAttributedString(string: "Cash On Delivery", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.cashOnDeliveryLabel.attributedText = cashOnDeliveryLabelAttrString
        
        // Setup buttonButton
        self.buttonButton.layer.cornerRadius = 4
        self.buttonButton.layer.masksToBounds = true
        self.buttonButton.snImageTextSpacing = 10
        
        // Setup backButton
        self.backButton.snImageTextSpacing = 10
        
    }

    private func setupUI()  {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    private func setupGestureRecognizers()  {
    
    }

    private func setupLocalization()  {
    
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Status Bar

    override public var prefersStatusBarHidden: Bool  {
        return false
    }

    override public var preferredStatusBarStyle: UIStatusBarStyle  {
        return .default
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Actions

    @IBAction public func onSelectedPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Delivery Address", sender: nil)
    }

    @IBAction public func onSelectedTwoPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Cart Delete", sender: nil)
    }

    @IBAction public func onButtonPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Cart Delete Two", sender: nil)
    }

    @IBAction public func onBackPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Order Done", sender: nil)
    }
}
