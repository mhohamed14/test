//
//  FoodCategoryViewController.swift
//  Food UI Kit
//
//  Created by [Author].
//  Copyright © 2018 [Company]. All rights reserved.
//

// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Import

import UIKit


// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Implementation

class FoodCategoryViewController: UIViewController {


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Properties

    @IBOutlet var burgerView: UIView!
    @IBOutlet var burgerLabel: SupernovaLabel!
    @IBOutlet var sandwitchView: UIView!
    @IBOutlet var sandwitchLabel: SupernovaLabel!
    @IBOutlet var noodlesView: UIView!
    @IBOutlet var noodlesLabel: SupernovaLabel!
    @IBOutlet var pizzaView: UIView!
    @IBOutlet var pizzaLabel: SupernovaLabel!
    @IBOutlet var hotDogView: UIView!
    @IBOutlet var hotDogLabel: SupernovaLabel!
    @IBOutlet var donutsView: UIView!
    @IBOutlet var donutsLabel: SupernovaLabel!
    @IBOutlet var baguetteView: UIView!
    @IBOutlet var nuggetsLabel: SupernovaLabel!
    @IBOutlet var baguetteCopyView: UIView!
    @IBOutlet var nuggetsTwoLabel: SupernovaLabel!
    @IBOutlet var chipsView: UIView!
    @IBOutlet var chipsLabel: SupernovaLabel!
    @IBOutlet var ovalView: UIView!
    @IBOutlet var chipsCopyView: UIView!
    @IBOutlet var chipsTwoLabel: SupernovaLabel!
    @IBOutlet var ovalTwoView: UIView!
    @IBOutlet var backButton: SupernovaButton!
    @IBOutlet var cartButton: SupernovaButton!
    @IBOutlet var drinksLabel: SupernovaLabel!
    @IBOutlet var cookiesLabel: SupernovaLabel!
    @IBOutlet var saladLabel: SupernovaLabel!
    @IBOutlet var lunchLabel: SupernovaLabel!
    @IBOutlet var breakfastLabel: SupernovaLabel!
    @IBOutlet var dinnerLabel: SupernovaLabel!
    @IBOutlet var combinedShapeButton: SupernovaButton!
    @IBOutlet var fastFoodLabel: SupernovaLabel!
    @IBOutlet var tapBarCopyView: UIView!
    @IBOutlet var homeButton: SupernovaButton!
    @IBOutlet var profileLabel: SupernovaLabel!
    @IBOutlet var favouriteLabel: SupernovaLabel!
    @IBOutlet var group3Button: SupernovaButton!
    @IBOutlet var categoryLabel: SupernovaLabel!
    @IBOutlet var nearByLabel: SupernovaLabel!


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Lifecycle

    override public func viewDidLoad()  {
        super.viewDidLoad()
        self.setupComponents()
        self.setupUI()
        self.setupGestureRecognizers()
        self.setupLocalization()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override public func viewWillAppear(_ animated: Bool)  {
        super.viewWillAppear(animated)
        
        // Navigation bar, if any
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Setup

    private func setupComponents()  {
        // Setup burgerView
        self.burgerView.layer.borderColor = UIColor(red: 0.969, green: 0.973, blue: 0.976, alpha: 1).cgColor /* #F7F8F9 */
        self.burgerView.layer.borderWidth = 1
        
        self.burgerView.layer.cornerRadius = 14
        self.burgerView.layer.masksToBounds = true
        
        // Setup burgerLabel
        let burgerLabelAttrString = NSMutableAttributedString(string: "Burger", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.burgerLabel.attributedText = burgerLabelAttrString
        
        // Setup sandwitchView
        self.sandwitchView.layer.borderColor = UIColor(red: 0.969, green: 0.973, blue: 0.976, alpha: 1).cgColor /* #F7F8F9 */
        self.sandwitchView.layer.borderWidth = 1
        
        self.sandwitchView.layer.cornerRadius = 14
        self.sandwitchView.layer.masksToBounds = true
        
        // Setup sandwitchLabel
        let sandwitchLabelAttrString = NSMutableAttributedString(string: "Sandwitch", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.sandwitchLabel.attributedText = sandwitchLabelAttrString
        
        // Setup noodlesView
        self.noodlesView.layer.borderColor = UIColor(red: 0.969, green: 0.973, blue: 0.976, alpha: 1).cgColor /* #F7F8F9 */
        self.noodlesView.layer.borderWidth = 1
        
        self.noodlesView.layer.cornerRadius = 14
        self.noodlesView.layer.masksToBounds = true
        
        // Setup noodlesLabel
        let noodlesLabelAttrString = NSMutableAttributedString(string: "Noodles", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.noodlesLabel.attributedText = noodlesLabelAttrString
        
        // Setup pizzaView
        self.pizzaView.layer.borderColor = UIColor(red: 0.969, green: 0.973, blue: 0.976, alpha: 1).cgColor /* #F7F8F9 */
        self.pizzaView.layer.borderWidth = 1
        
        self.pizzaView.layer.cornerRadius = 14
        self.pizzaView.layer.masksToBounds = true
        
        // Setup pizzaLabel
        let pizzaLabelAttrString = NSMutableAttributedString(string: "Pizza", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.pizzaLabel.attributedText = pizzaLabelAttrString
        
        // Setup hotDogView
        self.hotDogView.layer.borderColor = UIColor(red: 0.969, green: 0.973, blue: 0.976, alpha: 1).cgColor /* #F7F8F9 */
        self.hotDogView.layer.borderWidth = 1
        
        self.hotDogView.layer.cornerRadius = 14
        self.hotDogView.layer.masksToBounds = true
        
        // Setup hotDogLabel
        let hotDogLabelAttrString = NSMutableAttributedString(string: "Hot Dog", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.hotDogLabel.attributedText = hotDogLabelAttrString
        
        // Setup donutsView
        self.donutsView.layer.borderColor = UIColor(red: 0.969, green: 0.973, blue: 0.976, alpha: 1).cgColor /* #F7F8F9 */
        self.donutsView.layer.borderWidth = 1
        
        self.donutsView.layer.cornerRadius = 14
        self.donutsView.layer.masksToBounds = true
        
        // Setup donutsLabel
        let donutsLabelAttrString = NSMutableAttributedString(string: "Donuts", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.donutsLabel.attributedText = donutsLabelAttrString
        
        // Setup baguetteView
        self.baguetteView.layer.borderColor = UIColor(red: 0.969, green: 0.973, blue: 0.976, alpha: 1).cgColor /* #F7F8F9 */
        self.baguetteView.layer.borderWidth = 1
        
        self.baguetteView.layer.cornerRadius = 14
        self.baguetteView.layer.masksToBounds = true
        
        // Setup nuggetsLabel
        let nuggetsLabelAttrString = NSMutableAttributedString(string: "Nuggets", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.nuggetsLabel.attributedText = nuggetsLabelAttrString
        
        // Setup baguetteCopyView
        self.baguetteCopyView.layer.borderColor = UIColor(red: 0.969, green: 0.973, blue: 0.976, alpha: 1).cgColor /* #F7F8F9 */
        self.baguetteCopyView.layer.borderWidth = 1
        
        self.baguetteCopyView.layer.cornerRadius = 14
        self.baguetteCopyView.layer.masksToBounds = true
        
        // Setup nuggetsTwoLabel
        let nuggetsTwoLabelAttrString = NSMutableAttributedString(string: "Nuggets", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.nuggetsTwoLabel.attributedText = nuggetsTwoLabelAttrString
        
        // Setup chipsView
        self.chipsView.layer.borderColor = UIColor(red: 0.969, green: 0.973, blue: 0.976, alpha: 1).cgColor /* #F7F8F9 */
        self.chipsView.layer.borderWidth = 1
        
        self.chipsView.layer.cornerRadius = 14
        self.chipsView.layer.masksToBounds = true
        
        // Setup chipsLabel
        let chipsLabelAttrString = NSMutableAttributedString(string: "Chips", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.chipsLabel.attributedText = chipsLabelAttrString
        
        // Setup ovalView
        self.ovalView.layer.cornerRadius = 36
        self.ovalView.layer.masksToBounds = true
        
        // Setup chipsCopyView
        self.chipsCopyView.layer.borderColor = UIColor(red: 0.969, green: 0.973, blue: 0.976, alpha: 1).cgColor /* #F7F8F9 */
        self.chipsCopyView.layer.borderWidth = 1
        
        self.chipsCopyView.layer.cornerRadius = 14
        self.chipsCopyView.layer.masksToBounds = true
        
        // Setup chipsTwoLabel
        let chipsTwoLabelAttrString = NSMutableAttributedString(string: "Chips", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.chipsTwoLabel.attributedText = chipsTwoLabelAttrString
        
        // Setup ovalTwoView
        self.ovalTwoView.layer.cornerRadius = 36
        self.ovalTwoView.layer.masksToBounds = true
        
        // Setup backButton
        self.backButton.snImageTextSpacing = 10
        
        // Setup cartButton
        self.cartButton.snImageTextSpacing = 10
        
        // Setup drinksLabel
        let drinksLabelAttrString = NSMutableAttributedString(string: "Drinks", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 12)!,
            .foregroundColor : UIColor(red: 0.27, green: 0.26, blue: 0.31, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 12, paragraphSpacing: 0)
        ])
        self.drinksLabel.attributedText = drinksLabelAttrString
        
        // Setup cookiesLabel
        let cookiesLabelAttrString = NSMutableAttributedString(string: "Cookies", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 12)!,
            .foregroundColor : UIColor(red: 0.27, green: 0.26, blue: 0.31, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 12, paragraphSpacing: 0)
        ])
        self.cookiesLabel.attributedText = cookiesLabelAttrString
        
        // Setup saladLabel
        let saladLabelAttrString = NSMutableAttributedString(string: "Salad", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 12)!,
            .foregroundColor : UIColor(red: 0.27, green: 0.26, blue: 0.31, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 12, paragraphSpacing: 0)
        ])
        self.saladLabel.attributedText = saladLabelAttrString
        
        // Setup lunchLabel
        let lunchLabelAttrString = NSMutableAttributedString(string: "Lunch", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 12)!,
            .foregroundColor : UIColor(red: 0.27, green: 0.26, blue: 0.31, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 12, paragraphSpacing: 0)
        ])
        self.lunchLabel.attributedText = lunchLabelAttrString
        
        // Setup breakfastLabel
        let breakfastLabelAttrString = NSMutableAttributedString(string: "Breakfast", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 12)!,
            .foregroundColor : UIColor(red: 0.27, green: 0.26, blue: 0.31, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 12, paragraphSpacing: 0)
        ])
        self.breakfastLabel.attributedText = breakfastLabelAttrString
        
        // Setup dinnerLabel
        let dinnerLabelAttrString = NSMutableAttributedString(string: "Dinner", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 12)!,
            .foregroundColor : UIColor(red: 0.27, green: 0.26, blue: 0.31, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 12, paragraphSpacing: 0)
        ])
        self.dinnerLabel.attributedText = dinnerLabelAttrString
        
        // Setup combinedShapeButton
        self.combinedShapeButton.snImageTextSpacing = 10
        
        // Setup fastFoodLabel
        let fastFoodLabelAttrString = NSMutableAttributedString(string: "Fast Food", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 12)!,
            .foregroundColor : UIColor(red: 0.27, green: 0.26, blue: 0.31, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 12, paragraphSpacing: 0)
        ])
        self.fastFoodLabel.attributedText = fastFoodLabelAttrString
        
        // Setup tapBarCopyView
        self.tapBarCopyView.layer.shadowColor = UIColor(red: 0.536, green: 0.657, blue: 0.794, alpha: 0.104).cgColor /* #89A8CA */
        self.tapBarCopyView.layer.shadowOffset = CGSize(width: 0, height: -1)
        self.tapBarCopyView.layer.shadowRadius = 3
        self.tapBarCopyView.layer.shadowOpacity = 1
        
        self.tapBarCopyView.layer.cornerRadius = 16
        self.tapBarCopyView.layer.masksToBounds = true
        
        // Setup homeButton
        self.homeButton.snImageTextSpacing = 10
        
        // Setup profileLabel
        let profileLabelAttrString = NSMutableAttributedString(string: "Profile", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.78, green: 0.81, blue: 0.86, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 12, paragraphSpacing: 0)
        ])
        self.profileLabel.attributedText = profileLabelAttrString
        
        // Setup favouriteLabel
        let favouriteLabelAttrString = NSMutableAttributedString(string: "Favourite", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.78, green: 0.81, blue: 0.86, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 12, paragraphSpacing: 0)
        ])
        self.favouriteLabel.attributedText = favouriteLabelAttrString
        
        // Setup group3Button
        self.group3Button.snImageTextSpacing = 10
        
        // Setup categoryLabel
        let categoryLabelAttrString = NSMutableAttributedString(string: "Category", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 12, paragraphSpacing: 0)
        ])
        self.categoryLabel.attributedText = categoryLabelAttrString
        
        // Setup nearByLabel
        let nearByLabelAttrString = NSMutableAttributedString(string: "Near By", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.78, green: 0.81, blue: 0.86, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 12, paragraphSpacing: 0)
        ])
        self.nearByLabel.attributedText = nearByLabelAttrString
        
    }

    private func setupUI()  {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    private func setupGestureRecognizers()  {
    
    }

    private func setupLocalization()  {
    
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Status Bar

    override public var prefersStatusBarHidden: Bool  {
        return false
    }

    override public var preferredStatusBarStyle: UIStatusBarStyle  {
        return .default
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Actions

    @IBAction public func onBackPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Burger Category Page", sender: nil)
    }

    @IBAction public func onCartPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Home Two", sender: nil)
    }

    @IBAction public func onCombinedShapePressed(_ sender: UIButton)  {
    
    }

    @IBAction public func onHomePressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Home", sender: nil)
    }

    @IBAction public func onGroup3Pressed(_ sender: UIButton)  {
    
    }
}
