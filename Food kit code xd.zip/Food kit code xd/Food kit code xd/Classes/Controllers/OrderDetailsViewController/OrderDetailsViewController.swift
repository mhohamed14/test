//
//  OrderDetailsViewController.swift
//  Food UI Kit
//
//  Created by [Author].
//  Copyright © 2018 [Company]. All rights reserved.
//

// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Import

import UIKit


// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Implementation

class OrderDetailsViewController: UIViewController {


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Properties

    @IBOutlet var deliverredLabel: SupernovaLabel!
    @IBOutlet var statusLabel: SupernovaLabel!
    @IBOutlet var group14View: UIView!
    @IBOutlet var may2019Label: SupernovaLabel!
    @IBOutlet var amLabel: SupernovaLabel!
    @IBOutlet var onTheWayLabel: SupernovaLabel!
    @IBOutlet var statusTwoLabel: SupernovaLabel!
    @IBOutlet var group13View: UIView!
    @IBOutlet var may2019TwoLabel: SupernovaLabel!
    @IBOutlet var amTwoLabel: SupernovaLabel!
    @IBOutlet var processingLabel: SupernovaLabel!
    @IBOutlet var statusThreeLabel: SupernovaLabel!
    @IBOutlet var may2019ThreeLabel: SupernovaLabel!
    @IBOutlet var amThreeLabel: SupernovaLabel!
    @IBOutlet var confirmedLabel: SupernovaLabel!
    @IBOutlet var statusFourLabel: SupernovaLabel!
    @IBOutlet var group14TwoView: UIView!
    @IBOutlet var may2019FourLabel: SupernovaLabel!
    @IBOutlet var amFourLabel: SupernovaLabel!
    @IBOutlet var orderPlacedLabel: SupernovaLabel!
    @IBOutlet var statusFiveLabel: SupernovaLabel!
    @IBOutlet var group14ThreeView: UIView!
    @IBOutlet var may2019FiveLabel: SupernovaLabel!
    @IBOutlet var amFiveLabel: SupernovaLabel!
    @IBOutlet var labelLabel: SupernovaLabel!
    @IBOutlet var may2019SixLabel: SupernovaLabel!
    @IBOutlet var orderIdLabel: SupernovaLabel!
    @IBOutlet var backButton: SupernovaButton!
    @IBOutlet var subtotalLabel: SupernovaLabel!
    @IBOutlet var deliveryLabel: SupernovaLabel!
    @IBOutlet var labelTwoLabel: SupernovaLabel!
    @IBOutlet var labelThreeLabel: SupernovaLabel!
    @IBOutlet var discountLabel: SupernovaLabel!
    @IBOutlet var labelFourLabel: SupernovaLabel!
    @IBOutlet var totalBillLabel: SupernovaLabel!
    @IBOutlet var labelFiveLabel: SupernovaLabel!
    @IBOutlet var paymentMethodLabel: SupernovaLabel!
    @IBOutlet var visaCardLabel: SupernovaLabel!
    @IBOutlet var rectangleCopy4View: UIView!
    @IBOutlet var labelSixLabel: SupernovaLabel!
    @IBOutlet var rectangleCopy7View: UIView!
    @IBOutlet var rectangleCopy8View: UIView!
    @IBOutlet var rectangleCopy9View: UIView!
    @IBOutlet var rectangleCopy4TwoView: UIView!
    @IBOutlet var labelSevenLabel: SupernovaLabel!
    @IBOutlet var x5Label: SupernovaLabel!
    @IBOutlet var orderedFromLabel: SupernovaLabel!
    @IBOutlet var burgerKingLabel: SupernovaLabel!


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Lifecycle

    override public func viewDidLoad()  {
        super.viewDidLoad()
        self.setupComponents()
        self.setupUI()
        self.setupGestureRecognizers()
        self.setupLocalization()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override public func viewWillAppear(_ animated: Bool)  {
        super.viewWillAppear(animated)
        
        // Navigation bar, if any
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Setup

    private func setupComponents()  {
        // Setup deliverredLabel
        let deliverredLabelAttrString = NSMutableAttributedString(string: "Deliverred", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 1, green: 0.66, blue: 0.08, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.deliverredLabel.attributedText = deliverredLabelAttrString
        
        // Setup statusLabel
        let statusLabelAttrString = NSMutableAttributedString(string: "Status:", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.statusLabel.attributedText = statusLabelAttrString
        
        // Setup group14View
        self.group14View.layer.cornerRadius = 8
        self.group14View.layer.masksToBounds = true
        
        // Setup may2019Label
        let may2019LabelAttrString = NSMutableAttributedString(string: "20 May, 2019", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.may2019Label.attributedText = may2019LabelAttrString
        
        // Setup amLabel
        let amLabelAttrString = NSMutableAttributedString(string: "10:50 am", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.amLabel.attributedText = amLabelAttrString
        
        // Setup onTheWayLabel
        let onTheWayLabelAttrString = NSMutableAttributedString(string: "On The Way", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.25, green: 0.38, blue: 1, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.onTheWayLabel.attributedText = onTheWayLabelAttrString
        
        // Setup statusTwoLabel
        let statusTwoLabelAttrString = NSMutableAttributedString(string: "Status:", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.statusTwoLabel.attributedText = statusTwoLabelAttrString
        
        // Setup group13View
        self.group13View.layer.cornerRadius = 8
        self.group13View.layer.masksToBounds = true
        
        // Setup may2019TwoLabel
        let may2019TwoLabelAttrString = NSMutableAttributedString(string: "20 May, 2019", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.may2019TwoLabel.attributedText = may2019TwoLabelAttrString
        
        // Setup amTwoLabel
        let amTwoLabelAttrString = NSMutableAttributedString(string: "10:50 am", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.amTwoLabel.attributedText = amTwoLabelAttrString
        
        // Setup processingLabel
        let processingLabelAttrString = NSMutableAttributedString(string: "Processing", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 1, green: 0.42, blue: 0.42, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.processingLabel.attributedText = processingLabelAttrString
        
        // Setup statusThreeLabel
        let statusThreeLabelAttrString = NSMutableAttributedString(string: "Status:", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.statusThreeLabel.attributedText = statusThreeLabelAttrString
        
        // Setup may2019ThreeLabel
        let may2019ThreeLabelAttrString = NSMutableAttributedString(string: "20 May, 2019", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.may2019ThreeLabel.attributedText = may2019ThreeLabelAttrString
        
        // Setup amThreeLabel
        let amThreeLabelAttrString = NSMutableAttributedString(string: "10:50 am", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.amThreeLabel.attributedText = amThreeLabelAttrString
        
        // Setup confirmedLabel
        let confirmedLabelAttrString = NSMutableAttributedString(string: "Confirmed", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.25, green: 0.67, blue: 0.24, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.confirmedLabel.attributedText = confirmedLabelAttrString
        
        // Setup statusFourLabel
        let statusFourLabelAttrString = NSMutableAttributedString(string: "Status:", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.statusFourLabel.attributedText = statusFourLabelAttrString
        
        // Setup group14TwoView
        self.group14TwoView.layer.cornerRadius = 8
        self.group14TwoView.layer.masksToBounds = true
        
        // Setup may2019FourLabel
        let may2019FourLabelAttrString = NSMutableAttributedString(string: "20 May, 2019", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.may2019FourLabel.attributedText = may2019FourLabelAttrString
        
        // Setup amFourLabel
        let amFourLabelAttrString = NSMutableAttributedString(string: "10:50 am", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.amFourLabel.attributedText = amFourLabelAttrString
        
        // Setup orderPlacedLabel
        let orderPlacedLabelAttrString = NSMutableAttributedString(string: "Order Placed", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.97, green: 0.77, blue: 0.19, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.orderPlacedLabel.attributedText = orderPlacedLabelAttrString
        
        // Setup statusFiveLabel
        let statusFiveLabelAttrString = NSMutableAttributedString(string: "Status:", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.statusFiveLabel.attributedText = statusFiveLabelAttrString
        
        // Setup group14ThreeView
        self.group14ThreeView.layer.cornerRadius = 8
        self.group14ThreeView.layer.masksToBounds = true
        
        // Setup may2019FiveLabel
        let may2019FiveLabelAttrString = NSMutableAttributedString(string: "20 May, 2019", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.may2019FiveLabel.attributedText = may2019FiveLabelAttrString
        
        // Setup amFiveLabel
        let amFiveLabelAttrString = NSMutableAttributedString(string: "10:50 am", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.amFiveLabel.attributedText = amFiveLabelAttrString
        
        // Setup labelLabel
        let labelLabelAttrString = NSMutableAttributedString(string: "1252502680", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.labelLabel.attributedText = labelLabelAttrString
        
        // Setup may2019SixLabel
        let may2019SixLabelAttrString = NSMutableAttributedString(string: "20 May, 2019", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.may2019SixLabel.attributedText = may2019SixLabelAttrString
        
        // Setup orderIdLabel
        let orderIdLabelAttrString = NSMutableAttributedString(string: "Order ID:", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.orderIdLabel.attributedText = orderIdLabelAttrString
        
        // Setup backButton
        self.backButton.snImageTextSpacing = 10
        
        // Setup subtotalLabel
        let subtotalLabelAttrString = NSMutableAttributedString(string: "Subtotal :", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.subtotalLabel.attributedText = subtotalLabelAttrString
        
        // Setup deliveryLabel
        let deliveryLabelAttrString = NSMutableAttributedString(string: "Delivery :", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.deliveryLabel.attributedText = deliveryLabelAttrString
        
        // Setup labelTwoLabel
        let labelTwoLabelAttrString = NSMutableAttributedString(string: "$306.35", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.labelTwoLabel.attributedText = labelTwoLabelAttrString
        
        // Setup labelThreeLabel
        let labelThreeLabelAttrString = NSMutableAttributedString(string: "$10.00", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.labelThreeLabel.attributedText = labelThreeLabelAttrString
        
        // Setup discountLabel
        let discountLabelAttrString = NSMutableAttributedString(string: "Discount :", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.discountLabel.attributedText = discountLabelAttrString
        
        // Setup labelFourLabel
        let labelFourLabelAttrString = NSMutableAttributedString(string: "$12.00", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.labelFourLabel.attributedText = labelFourLabelAttrString
        
        // Setup totalBillLabel
        let totalBillLabelAttrString = NSMutableAttributedString(string: "Total Bill :", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.totalBillLabel.attributedText = totalBillLabelAttrString
        
        // Setup labelFiveLabel
        let labelFiveLabelAttrString = NSMutableAttributedString(string: "$304.00", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.labelFiveLabel.attributedText = labelFiveLabelAttrString
        
        // Setup paymentMethodLabel
        let paymentMethodLabelAttrString = NSMutableAttributedString(string: "Payment method :", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.paymentMethodLabel.attributedText = paymentMethodLabelAttrString
        
        // Setup visaCardLabel
        let visaCardLabelAttrString = NSMutableAttributedString(string: "VISA Card", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.visaCardLabel.attributedText = visaCardLabelAttrString
        
        // Setup rectangleCopy4View
        self.rectangleCopy4View.layer.cornerRadius = 11
        self.rectangleCopy4View.layer.masksToBounds = true
        
        // Setup labelSixLabel
        let labelSixLabelAttrString = NSMutableAttributedString(string: "$30.10", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 18)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 16, paragraphSpacing: 0)
        ])
        self.labelSixLabel.attributedText = labelSixLabelAttrString
        
        // Setup rectangleCopy7View
        self.rectangleCopy7View.layer.cornerRadius = 0.5
        self.rectangleCopy7View.layer.masksToBounds = true
        
        // Setup rectangleCopy8View
        self.rectangleCopy8View.layer.cornerRadius = 0.5
        self.rectangleCopy8View.layer.masksToBounds = true
        
        // Setup rectangleCopy9View
        self.rectangleCopy9View.layer.cornerRadius = 0.5
        self.rectangleCopy9View.layer.masksToBounds = true
        
        // Setup rectangleCopy4TwoView
        self.rectangleCopy4TwoView.layer.cornerRadius = 11
        self.rectangleCopy4TwoView.layer.masksToBounds = true
        
        // Setup labelSevenLabel
        let labelSevenLabelAttrString = NSMutableAttributedString(string: "$25.30", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 18)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 16, paragraphSpacing: 0)
        ])
        self.labelSevenLabel.attributedText = labelSevenLabelAttrString
        
        // Setup x5Label
        let x5LabelAttrString = NSMutableAttributedString(string: "x5", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.x5Label.attributedText = x5LabelAttrString
        
        // Setup orderedFromLabel
        let orderedFromLabelAttrString = NSMutableAttributedString(string: "Ordered From:", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.orderedFromLabel.attributedText = orderedFromLabelAttrString
        
        // Setup burgerKingLabel
        let burgerKingLabelAttrString = NSMutableAttributedString(string: "Burger King", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.burgerKingLabel.attributedText = burgerKingLabelAttrString
        
    }

    private func setupUI()  {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    private func setupGestureRecognizers()  {
    
    }

    private func setupLocalization()  {
    
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Status Bar

    override public var prefersStatusBarHidden: Bool  {
        return false
    }

    override public var preferredStatusBarStyle: UIStatusBarStyle  {
        return .default
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Actions

    @IBAction public func onBackPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Track Order", sender: nil)
    }
}
