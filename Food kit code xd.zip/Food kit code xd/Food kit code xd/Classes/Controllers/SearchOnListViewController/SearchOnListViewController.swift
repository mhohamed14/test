//
//  SearchOnListViewController.swift
//  Food UI Kit
//
//  Created by [Author].
//  Copyright © 2018 [Company]. All rights reserved.
//

// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Import

import UIKit


// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Implementation

class SearchOnListViewController: UIViewController {


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Properties

    @IBOutlet var restaurantView: UIView!
    @IBOutlet var italianoRestaurantLabel: SupernovaLabel!
    @IBOutlet var nayasharak14KmLabel: SupernovaLabel!
    @IBOutlet var reviewsLabel: SupernovaLabel!
    @IBOutlet var restaurantTwoView: UIView!
    @IBOutlet var cafeLaVistaLabel: SupernovaLabel!
    @IBOutlet var nayasharak14KmTwoLabel: SupernovaLabel!
    @IBOutlet var reviewsTwoLabel: SupernovaLabel!
    @IBOutlet var restaurantThreeView: UIView!
    @IBOutlet var khacchiHouseLabel: SupernovaLabel!
    @IBOutlet var nayasharak14KmThreeLabel: SupernovaLabel!
    @IBOutlet var restaurantFourView: UIView!
    @IBOutlet var spiceRestaurantLabel: SupernovaLabel!
    @IBOutlet var nayasharak14KmFourLabel: SupernovaLabel!
    @IBOutlet var restaurantFiveView: UIView!
    @IBOutlet var maBabarHotelLabel: SupernovaLabel!
    @IBOutlet var nayasharak14KmFiveLabel: SupernovaLabel!
    @IBOutlet var restaurantSixView: UIView!
    @IBOutlet var hotelTerabanLabel: SupernovaLabel!
    @IBOutlet var nayasharak14KmSixLabel: SupernovaLabel!
    @IBOutlet var headerView: UIView!
    @IBOutlet var rectangleView: UIView!
    @IBOutlet var dinnerLabel: SupernovaLabel!
    @IBOutlet var breakfastLabel: SupernovaLabel!
    @IBOutlet var lunchLabel: SupernovaLabel!
    @IBOutlet var fastFoodLabel: SupernovaLabel!
    @IBOutlet var searchView: UIView!
    @IBOutlet var filterView: UIView!
    @IBOutlet var closeButton: SupernovaButton!
    @IBOutlet var seeOnMapButton: SupernovaButton!


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Lifecycle

    override public func viewDidLoad()  {
        super.viewDidLoad()
        self.setupComponents()
        self.setupUI()
        self.setupGestureRecognizers()
        self.setupLocalization()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override public func viewWillAppear(_ animated: Bool)  {
        super.viewWillAppear(animated)
        
        // Navigation bar, if any
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Setup

    private func setupComponents()  {
        // Setup restaurantView
        self.restaurantView.layer.shadowColor = UIColor(red: 0.827, green: 0.851, blue: 0.89, alpha: 0.104).cgColor /* #D3D9E3 */
        self.restaurantView.layer.shadowOffset = CGSize(width: 0, height: 1)
        self.restaurantView.layer.shadowRadius = 5
        self.restaurantView.layer.shadowOpacity = 1
        
        self.restaurantView.layer.cornerRadius = 10
        self.restaurantView.layer.masksToBounds = true
        
        // Setup italianoRestaurantLabel
        let italianoRestaurantLabelAttrString = NSMutableAttributedString(string: "Italiano Restaurant", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 16)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 16, paragraphSpacing: 0)
        ])
        self.italianoRestaurantLabel.attributedText = italianoRestaurantLabelAttrString
        
        // Setup nayasharak14KmLabel
        let nayasharak14KmLabelAttrString = NSMutableAttributedString(string: "Nayasharak - 14 KM", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.nayasharak14KmLabel.attributedText = nayasharak14KmLabelAttrString
        
        // Setup reviewsLabel
        let reviewsLabelAttrString = NSMutableAttributedString(string: "130 reviews", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 12, paragraphSpacing: 0)
        ])
        self.reviewsLabel.attributedText = reviewsLabelAttrString
        
        // Setup restaurantTwoView
        self.restaurantTwoView.layer.shadowColor = UIColor(red: 0.827, green: 0.851, blue: 0.89, alpha: 0.104).cgColor /* #D3D9E3 */
        self.restaurantTwoView.layer.shadowOffset = CGSize(width: 0, height: 1)
        self.restaurantTwoView.layer.shadowRadius = 5
        self.restaurantTwoView.layer.shadowOpacity = 1
        
        self.restaurantTwoView.layer.cornerRadius = 10
        self.restaurantTwoView.layer.masksToBounds = true
        
        // Setup cafeLaVistaLabel
        let cafeLaVistaLabelAttrString = NSMutableAttributedString(string: "Cafe La Vista", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 16)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 16, paragraphSpacing: 0)
        ])
        self.cafeLaVistaLabel.attributedText = cafeLaVistaLabelAttrString
        
        // Setup nayasharak14KmTwoLabel
        let nayasharak14KmTwoLabelAttrString = NSMutableAttributedString(string: "Nayasharak - 14 KM", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.nayasharak14KmTwoLabel.attributedText = nayasharak14KmTwoLabelAttrString
        
        // Setup reviewsTwoLabel
        let reviewsTwoLabelAttrString = NSMutableAttributedString(string: "130 reviews", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 12, paragraphSpacing: 0)
        ])
        self.reviewsTwoLabel.attributedText = reviewsTwoLabelAttrString
        
        // Setup restaurantThreeView
        self.restaurantThreeView.layer.shadowColor = UIColor(red: 0.827, green: 0.851, blue: 0.89, alpha: 0.104).cgColor /* #D3D9E3 */
        self.restaurantThreeView.layer.shadowOffset = CGSize(width: 0, height: 1)
        self.restaurantThreeView.layer.shadowRadius = 5
        self.restaurantThreeView.layer.shadowOpacity = 1
        
        self.restaurantThreeView.layer.cornerRadius = 10
        self.restaurantThreeView.layer.masksToBounds = true
        
        // Setup khacchiHouseLabel
        let khacchiHouseLabelAttrString = NSMutableAttributedString(string: "Khacchi House", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 16)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 16, paragraphSpacing: 0)
        ])
        self.khacchiHouseLabel.attributedText = khacchiHouseLabelAttrString
        
        // Setup nayasharak14KmThreeLabel
        let nayasharak14KmThreeLabelAttrString = NSMutableAttributedString(string: "Nayasharak - 14 KM", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.nayasharak14KmThreeLabel.attributedText = nayasharak14KmThreeLabelAttrString
        
        // Setup restaurantFourView
        self.restaurantFourView.layer.shadowColor = UIColor(red: 0.827, green: 0.851, blue: 0.89, alpha: 0.104).cgColor /* #D3D9E3 */
        self.restaurantFourView.layer.shadowOffset = CGSize(width: 0, height: 1)
        self.restaurantFourView.layer.shadowRadius = 5
        self.restaurantFourView.layer.shadowOpacity = 1
        
        self.restaurantFourView.layer.cornerRadius = 10
        self.restaurantFourView.layer.masksToBounds = true
        
        // Setup spiceRestaurantLabel
        let spiceRestaurantLabelAttrString = NSMutableAttributedString(string: "Spice Restaurant", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 16)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 16, paragraphSpacing: 0)
        ])
        self.spiceRestaurantLabel.attributedText = spiceRestaurantLabelAttrString
        
        // Setup nayasharak14KmFourLabel
        let nayasharak14KmFourLabelAttrString = NSMutableAttributedString(string: "Nayasharak - 14 KM", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.nayasharak14KmFourLabel.attributedText = nayasharak14KmFourLabelAttrString
        
        // Setup restaurantFiveView
        self.restaurantFiveView.layer.shadowColor = UIColor(red: 0.827, green: 0.851, blue: 0.89, alpha: 0.104).cgColor /* #D3D9E3 */
        self.restaurantFiveView.layer.shadowOffset = CGSize(width: 0, height: 1)
        self.restaurantFiveView.layer.shadowRadius = 5
        self.restaurantFiveView.layer.shadowOpacity = 1
        
        self.restaurantFiveView.layer.cornerRadius = 10
        self.restaurantFiveView.layer.masksToBounds = true
        
        // Setup maBabarHotelLabel
        let maBabarHotelLabelAttrString = NSMutableAttributedString(string: "Ma Babar Hotel", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 16)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 16, paragraphSpacing: 0)
        ])
        self.maBabarHotelLabel.attributedText = maBabarHotelLabelAttrString
        
        // Setup nayasharak14KmFiveLabel
        let nayasharak14KmFiveLabelAttrString = NSMutableAttributedString(string: "Nayasharak - 14 KM", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.nayasharak14KmFiveLabel.attributedText = nayasharak14KmFiveLabelAttrString
        
        // Setup restaurantSixView
        self.restaurantSixView.layer.shadowColor = UIColor(red: 0.827, green: 0.851, blue: 0.89, alpha: 0.104).cgColor /* #D3D9E3 */
        self.restaurantSixView.layer.shadowOffset = CGSize(width: 0, height: 1)
        self.restaurantSixView.layer.shadowRadius = 5
        self.restaurantSixView.layer.shadowOpacity = 1
        
        self.restaurantSixView.layer.cornerRadius = 10
        self.restaurantSixView.layer.masksToBounds = true
        
        // Setup hotelTerabanLabel
        let hotelTerabanLabelAttrString = NSMutableAttributedString(string: "Hotel Teraban", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 16)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 16, paragraphSpacing: 0)
        ])
        self.hotelTerabanLabel.attributedText = hotelTerabanLabelAttrString
        
        // Setup nayasharak14KmSixLabel
        let nayasharak14KmSixLabelAttrString = NSMutableAttributedString(string: "Nayasharak - 14 KM", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.nayasharak14KmSixLabel.attributedText = nayasharak14KmSixLabelAttrString
        
        // Setup headerView
        self.headerView.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.05).cgColor /* #000000 */
        self.headerView.layer.shadowOffset = CGSize(width: 0, height: -1)
        self.headerView.layer.shadowRadius = 3
        self.headerView.layer.shadowOpacity = 1
        
        
        // Setup rectangleView
        self.rectangleView.layer.cornerRadius = 1.5
        self.rectangleView.layer.masksToBounds = true
        
        // Setup dinnerLabel
        let dinnerLabelAttrString = NSMutableAttributedString(string: "Dinner", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.dinnerLabel.attributedText = dinnerLabelAttrString
        
        // Setup breakfastLabel
        let breakfastLabelAttrString = NSMutableAttributedString(string: "Breakfast", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.breakfastLabel.attributedText = breakfastLabelAttrString
        
        // Setup lunchLabel
        let lunchLabelAttrString = NSMutableAttributedString(string: "Lunch", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.lunchLabel.attributedText = lunchLabelAttrString
        
        // Setup fastFoodLabel
        let fastFoodLabelAttrString = NSMutableAttributedString(string: "Fast Food", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.fastFoodLabel.attributedText = fastFoodLabelAttrString
        
        // Setup searchView
        self.searchView.layer.cornerRadius = 7
        self.searchView.layer.masksToBounds = true
        
        // Setup filterView
        self.filterView.layer.cornerRadius = 7
        self.filterView.layer.masksToBounds = true
        
        // Setup closeButton
        self.closeButton.snImageTextSpacing = 10
        
        // Setup seeOnMapButton
        self.seeOnMapButton.snImageTextSpacing = 10
        
    }

    private func setupUI()  {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    private func setupGestureRecognizers()  {
    
    }

    private func setupLocalization()  {
    
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Status Bar

    override public var prefersStatusBarHidden: Bool  {
        return false
    }

    override public var preferredStatusBarStyle: UIStatusBarStyle  {
        return .default
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Actions

    @IBAction public func onClosePressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Shop Home", sender: nil)
    }

    @IBAction public func onSeeOnMapPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Search On Map", sender: nil)
    }
}
