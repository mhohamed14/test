//
//  ChangePasswordViewController.swift
//  Food UI Kit
//
//  Created by [Author].
//  Copyright © 2018 [Company]. All rights reserved.
//

// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Import

import UIKit


// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Implementation

class ChangePasswordViewController: UIViewController {


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Properties

    @IBOutlet var backButton: SupernovaButton!
    @IBOutlet var bgView: UIView!
    @IBOutlet var newPassswordLabel: SupernovaLabel!
    @IBOutlet var group16View: UIView!
    @IBOutlet var shakibulIslamLabel: SupernovaLabel!
    @IBOutlet var confirmNewPasssworLabel: SupernovaLabel!
    @IBOutlet var group16TwoView: UIView!
    @IBOutlet var shakibulIslamTwoLabel: SupernovaLabel!
    @IBOutlet var buttonButton: SupernovaButton!


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Lifecycle

    override public func viewDidLoad()  {
        super.viewDidLoad()
        self.setupComponents()
        self.setupUI()
        self.setupGestureRecognizers()
        self.setupLocalization()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override public func viewWillAppear(_ animated: Bool)  {
        super.viewWillAppear(animated)
        
        // Navigation bar, if any
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Setup

    private func setupComponents()  {
        // Setup backButton
        self.backButton.snImageTextSpacing = 10
        
        // Setup bgView
        self.bgView.layer.shadowColor = UIColor(red: 0.827, green: 0.851, blue: 0.89, alpha: 0.149).cgColor /* #D3D9E3 */
        self.bgView.layer.shadowOffset = CGSize(width: 0, height: 2)
        self.bgView.layer.shadowRadius = 7
        self.bgView.layer.shadowOpacity = 1
        
        self.bgView.layer.cornerRadius = 12
        self.bgView.layer.masksToBounds = true
        
        // Setup newPassswordLabel
        let newPassswordLabelAttrString = NSMutableAttributedString(string: "New Passsword", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 12, paragraphSpacing: 0)
        ])
        self.newPassswordLabel.attributedText = newPassswordLabelAttrString
        
        // Setup group16View
        self.group16View.layer.borderColor = UIColor(red: 0.929, green: 0.941, blue: 0.949, alpha: 1).cgColor /* #EDF0F2 */
        self.group16View.layer.borderWidth = 1
        
        self.group16View.layer.cornerRadius = 7
        self.group16View.layer.masksToBounds = true
        
        // Setup shakibulIslamLabel
        let shakibulIslamLabelAttrString = NSMutableAttributedString(string: "**************", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 16)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 16, paragraphSpacing: 0)
        ])
        self.shakibulIslamLabel.attributedText = shakibulIslamLabelAttrString
        
        // Setup confirmNewPasssworLabel
        let confirmNewPasssworLabelAttrString = NSMutableAttributedString(string: "Confirm New Passsword", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 12, paragraphSpacing: 0)
        ])
        self.confirmNewPasssworLabel.attributedText = confirmNewPasssworLabelAttrString
        
        // Setup group16TwoView
        self.group16TwoView.layer.borderColor = UIColor(red: 0.929, green: 0.941, blue: 0.949, alpha: 1).cgColor /* #EDF0F2 */
        self.group16TwoView.layer.borderWidth = 1
        
        self.group16TwoView.layer.cornerRadius = 7
        self.group16TwoView.layer.masksToBounds = true
        
        // Setup shakibulIslamTwoLabel
        let shakibulIslamTwoLabelAttrString = NSMutableAttributedString(string: "**************", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 16)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 16, paragraphSpacing: 0)
        ])
        self.shakibulIslamTwoLabel.attributedText = shakibulIslamTwoLabelAttrString
        
        // Setup buttonButton
        self.buttonButton.layer.cornerRadius = 4
        self.buttonButton.layer.masksToBounds = true
        self.buttonButton.snImageTextSpacing = 10
        
    }

    private func setupUI()  {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    private func setupGestureRecognizers()  {
    
    }

    private func setupLocalization()  {
    
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Status Bar

    override public var prefersStatusBarHidden: Bool  {
        return false
    }

    override public var preferredStatusBarStyle: UIStatusBarStyle  {
        return .default
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Actions

    @IBAction public func onBackPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Update Password", sender: nil)
    }

    @IBAction public func onButtonPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Reset Password", sender: nil)
    }
}
