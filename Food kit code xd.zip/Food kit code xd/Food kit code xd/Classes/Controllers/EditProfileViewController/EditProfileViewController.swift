//
//  EditProfileViewController.swift
//  Food UI Kit
//
//  Created by [Author].
//  Copyright © 2018 [Company]. All rights reserved.
//

// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Import

import UIKit


// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Implementation

class EditProfileViewController: UIViewController {


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Properties

    @IBOutlet var backButton: SupernovaButton!
    @IBOutlet var rectangleCopy8View: UIView!
    @IBOutlet var shakibulIslamLabel: SupernovaLabel!
    @IBOutlet var nameLabel: SupernovaLabel!
    @IBOutlet var rectangleCopy7View: UIView!
    @IBOutlet var abcGmailComLabel: SupernovaLabel!
    @IBOutlet var emailLabel: SupernovaLabel!
    @IBOutlet var rectangleCopy7TwoView: UIView!
    @IBOutlet var labelLabel: SupernovaLabel!
    @IBOutlet var phoneLabel: SupernovaLabel!
    @IBOutlet var rectangleCopy7ThreeView: UIView!
    @IBOutlet var maleLabel: SupernovaLabel!
    @IBOutlet var genderLabel: SupernovaLabel!
    @IBOutlet var rectangleCopy7FourView: UIView!
    @IBOutlet var may2020Label: SupernovaLabel!
    @IBOutlet var birthdayLabel: SupernovaLabel!
    @IBOutlet var rectangleCopy7FiveView: UIView!
    @IBOutlet var labelTwoLabel: SupernovaLabel!
    @IBOutlet var passwordLabel: SupernovaLabel!
    @IBOutlet var rectangleCopy7SixView: UIView!


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Lifecycle

    override public func viewDidLoad()  {
        super.viewDidLoad()
        self.setupComponents()
        self.setupUI()
        self.setupGestureRecognizers()
        self.setupLocalization()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override public func viewWillAppear(_ animated: Bool)  {
        super.viewWillAppear(animated)
        
        // Navigation bar, if any
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Setup

    private func setupComponents()  {
        // Setup backButton
        self.backButton.snImageTextSpacing = 10
        
        // Setup rectangleCopy8View
        self.rectangleCopy8View.layer.shadowColor = UIColor(red: 0.827, green: 0.851, blue: 0.89, alpha: 0.149).cgColor /* #D3D9E3 */
        self.rectangleCopy8View.layer.shadowOffset = CGSize(width: 0, height: 2)
        self.rectangleCopy8View.layer.shadowRadius = 7
        self.rectangleCopy8View.layer.shadowOpacity = 1
        
        self.rectangleCopy8View.layer.cornerRadius = 12
        self.rectangleCopy8View.layer.masksToBounds = true
        
        // Setup shakibulIslamLabel
        let shakibulIslamLabelAttrString = NSMutableAttributedString(string: "Shakibul Islam", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .right, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.shakibulIslamLabel.attributedText = shakibulIslamLabelAttrString
        
        // Setup nameLabel
        let nameLabelAttrString = NSMutableAttributedString(string: "Name", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.nameLabel.attributedText = nameLabelAttrString
        
        // Setup rectangleCopy7View
        self.rectangleCopy7View.layer.cornerRadius = 0.5
        self.rectangleCopy7View.layer.masksToBounds = true
        
        // Setup abcGmailComLabel
        let abcGmailComLabelAttrString = NSMutableAttributedString(string: "abc@gmail.com", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .right, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.abcGmailComLabel.attributedText = abcGmailComLabelAttrString
        
        // Setup emailLabel
        let emailLabelAttrString = NSMutableAttributedString(string: "Email", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.emailLabel.attributedText = emailLabelAttrString
        
        // Setup rectangleCopy7TwoView
        self.rectangleCopy7TwoView.layer.cornerRadius = 0.5
        self.rectangleCopy7TwoView.layer.masksToBounds = true
        
        // Setup labelLabel
        let labelLabelAttrString = NSMutableAttributedString(string: "+440 326 85 12", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .right, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.labelLabel.attributedText = labelLabelAttrString
        
        // Setup phoneLabel
        let phoneLabelAttrString = NSMutableAttributedString(string: "Phone", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.phoneLabel.attributedText = phoneLabelAttrString
        
        // Setup rectangleCopy7ThreeView
        self.rectangleCopy7ThreeView.layer.cornerRadius = 0.5
        self.rectangleCopy7ThreeView.layer.masksToBounds = true
        
        // Setup maleLabel
        let maleLabelAttrString = NSMutableAttributedString(string: "Male", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .right, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.maleLabel.attributedText = maleLabelAttrString
        
        // Setup genderLabel
        let genderLabelAttrString = NSMutableAttributedString(string: "Gender", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.genderLabel.attributedText = genderLabelAttrString
        
        // Setup rectangleCopy7FourView
        self.rectangleCopy7FourView.layer.cornerRadius = 0.5
        self.rectangleCopy7FourView.layer.masksToBounds = true
        
        // Setup may2020Label
        let may2020LabelAttrString = NSMutableAttributedString(string: "13 May, 2020", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .right, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.may2020Label.attributedText = may2020LabelAttrString
        
        // Setup birthdayLabel
        let birthdayLabelAttrString = NSMutableAttributedString(string: "Birthday", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.birthdayLabel.attributedText = birthdayLabelAttrString
        
        // Setup rectangleCopy7FiveView
        self.rectangleCopy7FiveView.layer.cornerRadius = 0.5
        self.rectangleCopy7FiveView.layer.masksToBounds = true
        
        // Setup labelTwoLabel
        let labelTwoLabelAttrString = NSMutableAttributedString(string: "***********", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .right, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.labelTwoLabel.attributedText = labelTwoLabelAttrString
        
        // Setup passwordLabel
        let passwordLabelAttrString = NSMutableAttributedString(string: "Password", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.passwordLabel.attributedText = passwordLabelAttrString
        
        // Setup rectangleCopy7SixView
        self.rectangleCopy7SixView.layer.cornerRadius = 0.5
        self.rectangleCopy7SixView.layer.masksToBounds = true
        
    }

    private func setupUI()  {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    private func setupGestureRecognizers()  {
    
    }

    private func setupLocalization()  {
    
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Status Bar

    override public var prefersStatusBarHidden: Bool  {
        return false
    }

    override public var preferredStatusBarStyle: UIStatusBarStyle  {
        return .default
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Actions

    @IBAction public func onBackPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Setting", sender: nil)
    }
}
