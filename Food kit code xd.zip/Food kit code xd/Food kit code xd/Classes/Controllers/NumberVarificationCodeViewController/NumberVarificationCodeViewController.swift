//
//  NumberVarificationCodeViewController.swift
//  Food UI Kit
//
//  Created by [Author].
//  Copyright © 2018 [Company]. All rights reserved.
//

// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Import

import UIKit


// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Implementation

class NumberVarificationCodeViewController: UIViewController {


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Properties

    @IBOutlet var rectangleView: UIView!
    @IBOutlet var foodiesLabel: SupernovaLabel!
    @IBOutlet var buttonButton: SupernovaButton!
    @IBOutlet var varificationNumberTextField: UITextField!
    @IBOutlet var varificationNumberTwoTextField: UITextField!
    @IBOutlet var varificationNumberThreeTextField: UITextField!
    @IBOutlet var varificationNumberFourTextField: UITextField!
    @IBOutlet var enterTheVarificatiLabel: SupernovaLabel!


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Lifecycle

    override public func viewDidLoad()  {
        super.viewDidLoad()
        self.setupComponents()
        self.setupUI()
        self.setupGestureRecognizers()
        self.setupLocalization()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override public func viewWillAppear(_ animated: Bool)  {
        super.viewWillAppear(animated)
        
        // Navigation bar, if any
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Setup

    private func setupComponents()  {
        // Setup rectangleView
        self.rectangleView.layer.cornerRadius = 15
        self.rectangleView.layer.masksToBounds = true
        
        // Setup foodiesLabel
        let foodiesLabelAttrString = NSMutableAttributedString(string: "Foodies ", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 16)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 12, paragraphSpacing: 0)
        ])
        self.foodiesLabel.attributedText = foodiesLabelAttrString
        
        // Setup buttonButton
        self.buttonButton.layer.cornerRadius = 4
        self.buttonButton.layer.masksToBounds = true
        self.buttonButton.snImageTextSpacing = 10
        
        // Setup varificationNumberTextField
        self.varificationNumberTextField.layer.borderColor = UIColor(red: 0.929, green: 0.941, blue: 0.949, alpha: 1).cgColor /* #EDF0F2 */
        self.varificationNumberTextField.layer.borderWidth = 1
        
        self.varificationNumberTextField.layer.cornerRadius = 7
        self.varificationNumberTextField.layer.masksToBounds = true
        
        // Setup varificationNumberTwoTextField
        self.varificationNumberTwoTextField.layer.borderColor = UIColor(red: 0.929, green: 0.941, blue: 0.949, alpha: 1).cgColor /* #EDF0F2 */
        self.varificationNumberTwoTextField.layer.borderWidth = 1
        
        self.varificationNumberTwoTextField.layer.cornerRadius = 7
        self.varificationNumberTwoTextField.layer.masksToBounds = true
        
        // Setup varificationNumberThreeTextField
        self.varificationNumberThreeTextField.layer.borderColor = UIColor(red: 0.929, green: 0.941, blue: 0.949, alpha: 1).cgColor /* #EDF0F2 */
        self.varificationNumberThreeTextField.layer.borderWidth = 1
        
        self.varificationNumberThreeTextField.layer.cornerRadius = 7
        self.varificationNumberThreeTextField.layer.masksToBounds = true
        
        // Setup varificationNumberFourTextField
        self.varificationNumberFourTextField.layer.borderColor = UIColor(red: 0.929, green: 0.941, blue: 0.949, alpha: 1).cgColor /* #EDF0F2 */
        self.varificationNumberFourTextField.layer.borderWidth = 1
        
        self.varificationNumberFourTextField.layer.cornerRadius = 7
        self.varificationNumberFourTextField.layer.masksToBounds = true
        
        // Setup enterTheVarificatiLabel
        let enterTheVarificatiLabelAttrString = NSMutableAttributedString(string: "Enter the varification code", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .right, lineHeight: 12, paragraphSpacing: 0)
        ])
        self.enterTheVarificatiLabel.attributedText = enterTheVarificatiLabelAttrString
        
    }

    private func setupUI()  {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    private func setupGestureRecognizers()  {
    
    }

    private func setupLocalization()  {
    
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Status Bar

    override public var prefersStatusBarHidden: Bool  {
        return false
    }

    override public var preferredStatusBarStyle: UIStatusBarStyle  {
        return .default
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Actions

    @IBAction public func onButtonPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Login", sender: nil)
    }
}
