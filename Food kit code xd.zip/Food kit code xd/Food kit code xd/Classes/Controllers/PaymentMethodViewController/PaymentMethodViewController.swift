//
//  PaymentMethodViewController.swift
//  Food UI Kit
//
//  Created by [Author].
//  Copyright © 2018 [Company]. All rights reserved.
//

// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Import

import UIKit


// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Implementation

class PaymentMethodViewController: UIViewController {


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Properties

    @IBOutlet var rectangleView: UIView!
    @IBOutlet var backButton: SupernovaButton!
    @IBOutlet var myCardLabel: SupernovaLabel!
    @IBOutlet var shadowView: UIView!
    @IBOutlet var labelLabel: UILabel!
    @IBOutlet var dannisAlbertLabel: SupernovaLabel!
    @IBOutlet var labelTwoLabel: SupernovaLabel!
    @IBOutlet var labelThreeLabel: UILabel!
    @IBOutlet var dannisAlbertTwoLabel: SupernovaLabel!
    @IBOutlet var labelFourLabel: SupernovaLabel!
    @IBOutlet var paypalView: UIView!
    @IBOutlet var cashView: UIView!
    @IBOutlet var cashOnDeliveryLabel: SupernovaLabel!
    @IBOutlet var payInCashLabel: SupernovaLabel!
    @IBOutlet var rectangleTwoView: UIView!
    @IBOutlet var applePayView: UIView!
    @IBOutlet var applePayLabel: SupernovaLabel!
    @IBOutlet var rectangleThreeView: UIView!
    @IBOutlet var appleButton: SupernovaButton!
    @IBOutlet var otherPaymentOptionLabel: SupernovaLabel!


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Lifecycle

    override public func viewDidLoad()  {
        super.viewDidLoad()
        self.setupComponents()
        self.setupUI()
        self.setupGestureRecognizers()
        self.setupLocalization()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override public func viewWillAppear(_ animated: Bool)  {
        super.viewWillAppear(animated)
        
        // Navigation bar, if any
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Setup

    private func setupComponents()  {
        // Setup rectangleView
        self.rectangleView.layer.cornerRadius = 36
        self.rectangleView.layer.masksToBounds = true
        
        // Setup backButton
        self.backButton.snImageTextSpacing = 10
        
        // Setup myCardLabel
        let myCardLabelAttrString = NSMutableAttributedString(string: "My Card", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.myCardLabel.attributedText = myCardLabelAttrString
        
        // Setup shadowView
        self.shadowView.layer.cornerRadius = 7
        self.shadowView.layer.masksToBounds = true
        
        // Setup labelLabel
        let labelLabelAttrString = NSMutableAttributedString(string: "1234  5678  1234  5678", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 11)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 2.16,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.labelLabel.attributedText = labelLabelAttrString
        self.labelLabel.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.25).cgColor /* #000000 */
        self.labelLabel.layer.shadowOffset = CGSize(width: 0, height: 2)
        self.labelLabel.layer.shadowRadius = 4
        self.labelLabel.layer.shadowOpacity = 1
        
        
        // Setup dannisAlbertLabel
        let dannisAlbertLabelAttrString = NSMutableAttributedString(string: "DANNIS ALBERT", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 10)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 10, paragraphSpacing: 0)
        ])
        self.dannisAlbertLabel.attributedText = dannisAlbertLabelAttrString
        
        // Setup labelTwoLabel
        let labelTwoLabelAttrString = NSMutableAttributedString(string: "10/24", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 10)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 10, paragraphSpacing: 0)
        ])
        self.labelTwoLabel.attributedText = labelTwoLabelAttrString
        
        // Setup labelThreeLabel
        let labelThreeLabelAttrString = NSMutableAttributedString(string: "1234  5678  1234  5678", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 11)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 2.16,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.labelThreeLabel.attributedText = labelThreeLabelAttrString
        self.labelThreeLabel.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.25).cgColor /* #000000 */
        self.labelThreeLabel.layer.shadowOffset = CGSize(width: 0, height: 2)
        self.labelThreeLabel.layer.shadowRadius = 4
        self.labelThreeLabel.layer.shadowOpacity = 1
        
        
        // Setup dannisAlbertTwoLabel
        let dannisAlbertTwoLabelAttrString = NSMutableAttributedString(string: "DANNIS ALBERT", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 10)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 10, paragraphSpacing: 0)
        ])
        self.dannisAlbertTwoLabel.attributedText = dannisAlbertTwoLabelAttrString
        
        // Setup labelFourLabel
        let labelFourLabelAttrString = NSMutableAttributedString(string: "10/24", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 10)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 10, paragraphSpacing: 0)
        ])
        self.labelFourLabel.attributedText = labelFourLabelAttrString
        
        // Setup paypalView
        self.paypalView.layer.cornerRadius = 12
        self.paypalView.layer.masksToBounds = true
        
        // Setup cashView
        self.cashView.layer.cornerRadius = 12
        self.cashView.layer.masksToBounds = true
        
        // Setup cashOnDeliveryLabel
        let cashOnDeliveryLabelAttrString = NSMutableAttributedString(string: "Cash On Delivery", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 18, paragraphSpacing: 0)
        ])
        self.cashOnDeliveryLabel.attributedText = cashOnDeliveryLabelAttrString
        
        // Setup payInCashLabel
        let payInCashLabelAttrString = NSMutableAttributedString(string: "Pay in cash", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 18, paragraphSpacing: 0)
        ])
        self.payInCashLabel.attributedText = payInCashLabelAttrString
        
        // Setup rectangleTwoView
        self.rectangleTwoView.layer.cornerRadius = 12
        self.rectangleTwoView.layer.masksToBounds = true
        
        // Setup applePayView
        self.applePayView.layer.cornerRadius = 12
        self.applePayView.layer.masksToBounds = true
        
        // Setup applePayLabel
        let applePayLabelAttrString = NSMutableAttributedString(string: "Apple Pay", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 18, paragraphSpacing: 0)
        ])
        self.applePayLabel.attributedText = applePayLabelAttrString
        
        // Setup rectangleThreeView
        self.rectangleThreeView.layer.cornerRadius = 12
        self.rectangleThreeView.layer.masksToBounds = true
        
        // Setup appleButton
        self.appleButton.snImageTextSpacing = 10
        
        // Setup otherPaymentOptionLabel
        let otherPaymentOptionLabelAttrString = NSMutableAttributedString(string: "Other Payment Option", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.otherPaymentOptionLabel.attributedText = otherPaymentOptionLabelAttrString
        
    }

    private func setupUI()  {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    private func setupGestureRecognizers()  {
    
    }

    private func setupLocalization()  {
    
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Status Bar

    override public var prefersStatusBarHidden: Bool  {
        return false
    }

    override public var preferredStatusBarStyle: UIStatusBarStyle  {
        return .default
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Actions

    @IBAction public func onBackPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Add Card", sender: nil)
    }

    @IBAction public func onApplePressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Search Filter", sender: nil)
    }
}
