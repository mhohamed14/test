//
//  UserReviewViewController.swift
//  Food UI Kit
//
//  Created by [Author].
//  Copyright © 2018 [Company]. All rights reserved.
//

// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Import

import UIKit


// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Implementation

class UserReviewViewController: UIViewController {


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Properties

    @IBOutlet var rectangleView: UIView!
    @IBOutlet var chickenBurgerLabel: SupernovaLabel!
    @IBOutlet var minLabel: SupernovaLabel!
    @IBOutlet var kmLabel: SupernovaLabel!
    @IBOutlet var labelLabel: SupernovaLabel!
    @IBOutlet var rectangleCopy3View: UIView!
    @IBOutlet var rafaIslamLabel: SupernovaLabel!
    @IBOutlet var pizzaIsASavoryDiLabel: UILabel!
    @IBOutlet var labelTwoLabel: SupernovaLabel!
    @IBOutlet var jonKalbertLabel: SupernovaLabel!
    @IBOutlet var pizzaIsASavoryDiTwoLabel: UILabel!
    @IBOutlet var labelThreeLabel: SupernovaLabel!
    @IBOutlet var backButton: SupernovaButton!
    @IBOutlet var addToCartView: UIView!
    @IBOutlet var addToCartButtonButton: SupernovaButton!
    @IBOutlet var numberView: UIView!


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Lifecycle

    override public func viewDidLoad()  {
        super.viewDidLoad()
        self.setupComponents()
        self.setupUI()
        self.setupGestureRecognizers()
        self.setupLocalization()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override public func viewWillAppear(_ animated: Bool)  {
        super.viewWillAppear(animated)
        
        // Navigation bar, if any
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Setup

    private func setupComponents()  {
        // Setup rectangleView
        self.rectangleView.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.05).cgColor /* #000000 */
        self.rectangleView.layer.shadowOffset = CGSize(width: 0, height: -1)
        self.rectangleView.layer.shadowRadius = 3
        self.rectangleView.layer.shadowOpacity = 1
        
        self.rectangleView.layer.cornerRadius = 50
        self.rectangleView.layer.masksToBounds = true
        
        // Setup chickenBurgerLabel
        let chickenBurgerLabelAttrString = NSMutableAttributedString(string: "Chicken Burger", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 24)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 22, paragraphSpacing: 0)
        ])
        self.chickenBurgerLabel.attributedText = chickenBurgerLabelAttrString
        
        // Setup minLabel
        let minLabelAttrString = NSMutableAttributedString(string: "30 min", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.minLabel.attributedText = minLabelAttrString
        
        // Setup kmLabel
        let kmLabelAttrString = NSMutableAttributedString(string: "1.4 km", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.kmLabel.attributedText = kmLabelAttrString
        
        // Setup labelLabel
        let labelLabelAttrString = NSMutableAttributedString(string: "4.3 (132)", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.labelLabel.attributedText = labelLabelAttrString
        
        // Setup rectangleCopy3View
        self.rectangleCopy3View.layer.cornerRadius = 33
        self.rectangleCopy3View.layer.masksToBounds = true
        
        // Setup rafaIslamLabel
        let rafaIslamLabelAttrString = NSMutableAttributedString(string: "Rafa Islam", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.rafaIslamLabel.attributedText = rafaIslamLabelAttrString
        
        // Setup pizzaIsASavoryDiLabel
        let pizzaIsASavoryDiLabelAttrString = NSMutableAttributedString(string: "Pizza is a savory dish of Italian origin consistin usualy round, flattened base of leavene cheas topped with tomatoes.", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 21, paragraphSpacing: 0)
        ])
        self.pizzaIsASavoryDiLabel.attributedText = pizzaIsASavoryDiLabelAttrString
        
        // Setup labelTwoLabel
        let labelTwoLabelAttrString = NSMutableAttributedString(string: "01-02-19", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.labelTwoLabel.attributedText = labelTwoLabelAttrString
        
        // Setup jonKalbertLabel
        let jonKalbertLabelAttrString = NSMutableAttributedString(string: "Jon Kalbert", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.jonKalbertLabel.attributedText = jonKalbertLabelAttrString
        
        // Setup pizzaIsASavoryDiTwoLabel
        let pizzaIsASavoryDiTwoLabelAttrString = NSMutableAttributedString(string: "Pizza is a savory dish of Italian origin consistin usualy round, flattened base of leavene cheas topped with tomatoes.", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 21, paragraphSpacing: 0)
        ])
        self.pizzaIsASavoryDiTwoLabel.attributedText = pizzaIsASavoryDiTwoLabelAttrString
        
        // Setup labelThreeLabel
        let labelThreeLabelAttrString = NSMutableAttributedString(string: "01-02-19", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.labelThreeLabel.attributedText = labelThreeLabelAttrString
        
        // Setup backButton
        self.backButton.snImageTextSpacing = 10
        
        // Setup addToCartView
        self.addToCartView.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.05).cgColor /* #000000 */
        self.addToCartView.layer.shadowOffset = CGSize(width: 0, height: -1)
        self.addToCartView.layer.shadowRadius = 3
        self.addToCartView.layer.shadowOpacity = 1
        
        self.addToCartView.layer.cornerRadius = 12
        self.addToCartView.layer.masksToBounds = true
        
        // Setup addToCartButtonButton
        self.addToCartButtonButton.layer.shadowColor = UIColor(red: 1, green: 0.824, blue: 0.306, alpha: 0.204).cgColor /* #FFD24E */
        self.addToCartButtonButton.layer.shadowOffset = CGSize(width: 0, height: 3)
        self.addToCartButtonButton.layer.shadowRadius = 8
        self.addToCartButtonButton.layer.shadowOpacity = 1
        
        self.addToCartButtonButton.layer.cornerRadius = 4
        self.addToCartButtonButton.layer.masksToBounds = true
        self.addToCartButtonButton.snImageTextSpacing = 10
        
        // Setup numberView
        self.numberView.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.02).cgColor /* #000000 */
        self.numberView.layer.shadowOffset = CGSize(width: 0, height: 2)
        self.numberView.layer.shadowRadius = 8
        self.numberView.layer.shadowOpacity = 1
        
        self.numberView.layer.cornerRadius = 4
        self.numberView.layer.masksToBounds = true
        
    }

    private func setupUI()  {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    private func setupGestureRecognizers()  {
    
    }

    private func setupLocalization()  {
    
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Status Bar

    override public var prefersStatusBarHidden: Bool  {
        return false
    }

    override public var preferredStatusBarStyle: UIStatusBarStyle  {
        return .default
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Actions

    @IBAction public func onBackPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Burger Order App Cart", sender: nil)
    }

    @IBAction public func onAddToCartButtonPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Burger Order App Details", sender: nil)
    }
}
