//
//  NotificationViewController.swift
//  Food UI Kit
//
//  Created by [Author].
//  Copyright © 2018 [Company]. All rights reserved.
//

// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Import

import UIKit


// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Implementation

class NotificationViewController: UIViewController {


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Properties

    @IBOutlet var backButton: SupernovaButton!
    @IBOutlet var notificationView: UIView!
    @IBOutlet var appNotificationLabel: SupernovaLabel!
    @IBOutlet var rectangleSwitch: UISwitch!
    @IBOutlet var rectangleCopy7View: UIView!
    @IBOutlet var emailNotificationLabel: SupernovaLabel!
    @IBOutlet var rectangleTwoSwitch: UISwitch!
    @IBOutlet var rectangleCopy7TwoView: UIView!
    @IBOutlet var offerNotificationLabel: SupernovaLabel!
    @IBOutlet var rectangleThreeSwitch: UISwitch!
    @IBOutlet var rectangleView: UIView!
    @IBOutlet var rectangleCopy7ThreeView: UIView!


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Lifecycle

    override public func viewDidLoad()  {
        super.viewDidLoad()
        self.setupComponents()
        self.setupUI()
        self.setupGestureRecognizers()
        self.setupLocalization()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override public func viewWillAppear(_ animated: Bool)  {
        super.viewWillAppear(animated)
        
        // Navigation bar, if any
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Setup

    private func setupComponents()  {
        // Setup backButton
        self.backButton.snImageTextSpacing = 10
        
        // Setup notificationView
        self.notificationView.layer.shadowColor = UIColor(red: 0.827, green: 0.851, blue: 0.89, alpha: 0.149).cgColor /* #D3D9E3 */
        self.notificationView.layer.shadowOffset = CGSize(width: 0, height: 2)
        self.notificationView.layer.shadowRadius = 7
        self.notificationView.layer.shadowOpacity = 1
        
        self.notificationView.layer.cornerRadius = 12
        self.notificationView.layer.masksToBounds = true
        
        // Setup appNotificationLabel
        let appNotificationLabelAttrString = NSMutableAttributedString(string: "App Notification", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.appNotificationLabel.attributedText = appNotificationLabelAttrString
        
        // Setup rectangleSwitch
        self.rectangleSwitch.layer.cornerRadius = 6
        self.rectangleSwitch.layer.masksToBounds = true
        
        // Setup rectangleCopy7View
        self.rectangleCopy7View.layer.cornerRadius = 0.5
        self.rectangleCopy7View.layer.masksToBounds = true
        
        // Setup emailNotificationLabel
        let emailNotificationLabelAttrString = NSMutableAttributedString(string: "Email Notification", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.emailNotificationLabel.attributedText = emailNotificationLabelAttrString
        
        // Setup rectangleTwoSwitch
        self.rectangleTwoSwitch.layer.cornerRadius = 8
        self.rectangleTwoSwitch.layer.masksToBounds = true
        
        // Setup rectangleCopy7TwoView
        self.rectangleCopy7TwoView.layer.cornerRadius = 0.5
        self.rectangleCopy7TwoView.layer.masksToBounds = true
        
        // Setup offerNotificationLabel
        let offerNotificationLabelAttrString = NSMutableAttributedString(string: "Offer Notification", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.offerNotificationLabel.attributedText = offerNotificationLabelAttrString
        
        // Setup rectangleThreeSwitch
        self.rectangleThreeSwitch.layer.cornerRadius = 8
        self.rectangleThreeSwitch.layer.masksToBounds = true
        
        // Setup rectangleView
        self.rectangleView.layer.cornerRadius = 6
        self.rectangleView.layer.masksToBounds = true
        
        // Setup rectangleCopy7ThreeView
        self.rectangleCopy7ThreeView.layer.cornerRadius = 0.5
        self.rectangleCopy7ThreeView.layer.masksToBounds = true
        
    }

    private func setupUI()  {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    private func setupGestureRecognizers()  {
    
    }

    private func setupLocalization()  {
    
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Status Bar

    override public var prefersStatusBarHidden: Bool  {
        return false
    }

    override public var preferredStatusBarStyle: UIStatusBarStyle  {
        return .default
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Actions

    @IBAction public func onBackPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Edit profile", sender: nil)
    }

    @IBAction public func onRectangleTwoValueChanged(_ sender: UISwitch)  {
    
    }

    @IBAction public func onRectangleFourValueChanged(_ sender: UISwitch)  {
    
    }

    @IBAction public func onRectangleThreeValueChanged(_ sender: UISwitch)  {
    
    }
}
