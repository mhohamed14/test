//
//  ShopHomeViewController.swift
//  Food UI Kit
//
//  Created by [Author].
//  Copyright © 2018 [Company]. All rights reserved.
//

// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Import

import UIKit


// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Implementation

class ShopHomeViewController: UIViewController {


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Properties

    @IBOutlet var rectangleView: UIView!
    @IBOutlet var buttonButton: SupernovaButton!
    @IBOutlet var searchSearchBar: UISearchBar!
    @IBOutlet var backButton: SupernovaButton!
    @IBOutlet var rectangleCopy7View: UIView!
    @IBOutlet var italianoRestaurantLabel: SupernovaLabel!
    @IBOutlet var rectangleCopy4View: UIView!
    @IBOutlet var rectangleCopy4TwoView: UIView!
    @IBOutlet var labelLabel: SupernovaLabel!
    @IBOutlet var labelTwoLabel: SupernovaLabel!
    @IBOutlet var rectangleCopy4ThreeView: UIView!
    @IBOutlet var rectangleCopy4FourView: UIView!
    @IBOutlet var labelThreeLabel: SupernovaLabel!
    @IBOutlet var labelFourLabel: SupernovaLabel!
    @IBOutlet var rectangleCopy4FiveView: UIView!
    @IBOutlet var rectangleCopy4SixView: UIView!
    @IBOutlet var labelFiveLabel: SupernovaLabel!
    @IBOutlet var labelSixLabel: SupernovaLabel!
    @IBOutlet var rectangleCopy4SevenView: UIView!
    @IBOutlet var rectangleCopy4EightView: UIView!
    @IBOutlet var labelSevenLabel: SupernovaLabel!
    @IBOutlet var labelEightLabel: SupernovaLabel!
    @IBOutlet var rectangleCopy4NineView: UIView!
    @IBOutlet var rectangleCopy4TenView: UIView!
    @IBOutlet var labelNineLabel: SupernovaLabel!
    @IBOutlet var labelTenLabel: SupernovaLabel!
    @IBOutlet var rectangleCopy4ElevenView: UIView!
    @IBOutlet var rectangleCopy4TwelveView: UIView!
    @IBOutlet var labelElevenLabel: SupernovaLabel!
    @IBOutlet var labelTwelveLabel: SupernovaLabel!
    @IBOutlet var rectangleCopy4ThirteenView: UIView!
    @IBOutlet var rectangleCopy4FourteenView: UIView!
    @IBOutlet var labelThirteenLabel: SupernovaLabel!
    @IBOutlet var labelFourteenLabel: SupernovaLabel!
    @IBOutlet var rectangleCopy4FifteenView: UIView!
    @IBOutlet var rectangleCopy4SixteenView: UIView!
    @IBOutlet var labelFifteenLabel: SupernovaLabel!
    @IBOutlet var labelSixteenLabel: SupernovaLabel!
    @IBOutlet var nayasharakRoadSylLabel: SupernovaLabel!
    @IBOutlet var labelSeventeenLabel: SupernovaLabel!
    @IBOutlet var reviewsLabel: SupernovaLabel!
    @IBOutlet var openLabel: SupernovaLabel!
    @IBOutlet var am11amLabel: SupernovaLabel!
    @IBOutlet var minLabel: SupernovaLabel!
    @IBOutlet var deliveryLabel: SupernovaLabel!


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Lifecycle

    override public func viewDidLoad()  {
        super.viewDidLoad()
        self.setupComponents()
        self.setupUI()
        self.setupGestureRecognizers()
        self.setupLocalization()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override public func viewWillAppear(_ animated: Bool)  {
        super.viewWillAppear(animated)
        
        // Navigation bar, if any
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Setup

    private func setupComponents()  {
        // Setup rectangleView
        self.rectangleView.layer.shadowColor = UIColor(red: 0.827, green: 0.851, blue: 0.89, alpha: 0.296).cgColor /* #D3D9E3 */
        self.rectangleView.layer.shadowOffset = CGSize(width: 0, height: -1)
        self.rectangleView.layer.shadowRadius = 5
        self.rectangleView.layer.shadowOpacity = 1
        
        self.rectangleView.layer.cornerRadius = 22
        self.rectangleView.layer.masksToBounds = true
        
        // Setup buttonButton
        self.buttonButton.layer.cornerRadius = 4
        self.buttonButton.layer.masksToBounds = true
        self.buttonButton.snImageTextSpacing = 10
        
        // Setup searchSearchBar
        self.searchSearchBar.snFont = UIFont.systemFont(ofSize: 12)
        self.searchSearchBar.snTextColor = UIColor(red: 0, green: 0, blue: 0, alpha: 1) /* #000000 */
        self.searchSearchBar.snFieldBackgroundColor = UIColor(red: 1, green: 1, blue: 1, alpha: 1) /* #FFFFFF */
        
        // Setup backButton
        self.backButton.snImageTextSpacing = 10
        
        // Setup rectangleCopy7View
        self.rectangleCopy7View.layer.cornerRadius = 0.5
        self.rectangleCopy7View.layer.masksToBounds = true
        
        // Setup italianoRestaurantLabel
        let italianoRestaurantLabelAttrString = NSMutableAttributedString(string: "Italiano Restaurant", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 24)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 22, paragraphSpacing: 0)
        ])
        self.italianoRestaurantLabel.attributedText = italianoRestaurantLabelAttrString
        
        // Setup rectangleCopy4View
        self.rectangleCopy4View.layer.cornerRadius = 14
        self.rectangleCopy4View.layer.masksToBounds = true
        
        // Setup rectangleCopy4TwoView
        self.rectangleCopy4TwoView.layer.cornerRadius = 14
        self.rectangleCopy4TwoView.layer.masksToBounds = true
        
        // Setup labelLabel
        let labelLabelAttrString = NSMutableAttributedString(string: "$35", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 12, paragraphSpacing: 0)
        ])
        self.labelLabel.attributedText = labelLabelAttrString
        
        // Setup labelTwoLabel
        let labelTwoLabelAttrString = NSMutableAttributedString(string: "3.3", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.labelTwoLabel.attributedText = labelTwoLabelAttrString
        
        // Setup rectangleCopy4ThreeView
        self.rectangleCopy4ThreeView.layer.cornerRadius = 14
        self.rectangleCopy4ThreeView.layer.masksToBounds = true
        
        // Setup rectangleCopy4FourView
        self.rectangleCopy4FourView.layer.cornerRadius = 14
        self.rectangleCopy4FourView.layer.masksToBounds = true
        
        // Setup labelThreeLabel
        let labelThreeLabelAttrString = NSMutableAttributedString(string: "$15", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 12, paragraphSpacing: 0)
        ])
        self.labelThreeLabel.attributedText = labelThreeLabelAttrString
        
        // Setup labelFourLabel
        let labelFourLabelAttrString = NSMutableAttributedString(string: "3.4", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.labelFourLabel.attributedText = labelFourLabelAttrString
        
        // Setup rectangleCopy4FiveView
        self.rectangleCopy4FiveView.layer.cornerRadius = 14
        self.rectangleCopy4FiveView.layer.masksToBounds = true
        
        // Setup rectangleCopy4SixView
        self.rectangleCopy4SixView.layer.cornerRadius = 14
        self.rectangleCopy4SixView.layer.masksToBounds = true
        
        // Setup labelFiveLabel
        let labelFiveLabelAttrString = NSMutableAttributedString(string: "$30", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 12, paragraphSpacing: 0)
        ])
        self.labelFiveLabel.attributedText = labelFiveLabelAttrString
        
        // Setup labelSixLabel
        let labelSixLabelAttrString = NSMutableAttributedString(string: "3.5", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.labelSixLabel.attributedText = labelSixLabelAttrString
        
        // Setup rectangleCopy4SevenView
        self.rectangleCopy4SevenView.layer.cornerRadius = 14
        self.rectangleCopy4SevenView.layer.masksToBounds = true
        
        // Setup rectangleCopy4EightView
        self.rectangleCopy4EightView.layer.cornerRadius = 14
        self.rectangleCopy4EightView.layer.masksToBounds = true
        
        // Setup labelSevenLabel
        let labelSevenLabelAttrString = NSMutableAttributedString(string: "$18", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 12, paragraphSpacing: 0)
        ])
        self.labelSevenLabel.attributedText = labelSevenLabelAttrString
        
        // Setup labelEightLabel
        let labelEightLabelAttrString = NSMutableAttributedString(string: "3.8", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.labelEightLabel.attributedText = labelEightLabelAttrString
        
        // Setup rectangleCopy4NineView
        self.rectangleCopy4NineView.layer.cornerRadius = 14
        self.rectangleCopy4NineView.layer.masksToBounds = true
        
        // Setup rectangleCopy4TenView
        self.rectangleCopy4TenView.layer.cornerRadius = 14
        self.rectangleCopy4TenView.layer.masksToBounds = true
        
        // Setup labelNineLabel
        let labelNineLabelAttrString = NSMutableAttributedString(string: "$25", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 12, paragraphSpacing: 0)
        ])
        self.labelNineLabel.attributedText = labelNineLabelAttrString
        
        // Setup labelTenLabel
        let labelTenLabelAttrString = NSMutableAttributedString(string: "3.9", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.labelTenLabel.attributedText = labelTenLabelAttrString
        
        // Setup rectangleCopy4ElevenView
        self.rectangleCopy4ElevenView.layer.cornerRadius = 14
        self.rectangleCopy4ElevenView.layer.masksToBounds = true
        
        // Setup rectangleCopy4TwelveView
        self.rectangleCopy4TwelveView.layer.cornerRadius = 14
        self.rectangleCopy4TwelveView.layer.masksToBounds = true
        
        // Setup labelElevenLabel
        let labelElevenLabelAttrString = NSMutableAttributedString(string: "$22", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 12, paragraphSpacing: 0)
        ])
        self.labelElevenLabel.attributedText = labelElevenLabelAttrString
        
        // Setup labelTwelveLabel
        let labelTwelveLabelAttrString = NSMutableAttributedString(string: "4.0", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.labelTwelveLabel.attributedText = labelTwelveLabelAttrString
        
        // Setup rectangleCopy4ThirteenView
        self.rectangleCopy4ThirteenView.layer.cornerRadius = 14
        self.rectangleCopy4ThirteenView.layer.masksToBounds = true
        
        // Setup rectangleCopy4FourteenView
        self.rectangleCopy4FourteenView.layer.cornerRadius = 14
        self.rectangleCopy4FourteenView.layer.masksToBounds = true
        
        // Setup labelThirteenLabel
        let labelThirteenLabelAttrString = NSMutableAttributedString(string: "$20", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 12, paragraphSpacing: 0)
        ])
        self.labelThirteenLabel.attributedText = labelThirteenLabelAttrString
        
        // Setup labelFourteenLabel
        let labelFourteenLabelAttrString = NSMutableAttributedString(string: "4.3", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.labelFourteenLabel.attributedText = labelFourteenLabelAttrString
        
        // Setup rectangleCopy4FifteenView
        self.rectangleCopy4FifteenView.layer.cornerRadius = 14
        self.rectangleCopy4FifteenView.layer.masksToBounds = true
        
        // Setup rectangleCopy4SixteenView
        self.rectangleCopy4SixteenView.layer.cornerRadius = 14
        self.rectangleCopy4SixteenView.layer.masksToBounds = true
        
        // Setup labelFifteenLabel
        let labelFifteenLabelAttrString = NSMutableAttributedString(string: "$14", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 12, paragraphSpacing: 0)
        ])
        self.labelFifteenLabel.attributedText = labelFifteenLabelAttrString
        
        // Setup labelSixteenLabel
        let labelSixteenLabelAttrString = NSMutableAttributedString(string: "4.5", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.labelSixteenLabel.attributedText = labelSixteenLabelAttrString
        
        // Setup nayasharakRoadSylLabel
        let nayasharakRoadSylLabelAttrString = NSMutableAttributedString(string: "Nayasharak Road, Sylhet  ", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.nayasharakRoadSylLabel.attributedText = nayasharakRoadSylLabelAttrString
        
        // Setup labelSeventeenLabel
        let labelSeventeenLabelAttrString = NSMutableAttributedString(string: "4.5", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.labelSeventeenLabel.attributedText = labelSeventeenLabelAttrString
        
        // Setup reviewsLabel
        let reviewsLabelAttrString = NSMutableAttributedString(string: "130 reviews", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 12, paragraphSpacing: 0)
        ])
        self.reviewsLabel.attributedText = reviewsLabelAttrString
        
        // Setup openLabel
        let openLabelAttrString = NSMutableAttributedString(string: "Open", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.openLabel.attributedText = openLabelAttrString
        
        // Setup am11amLabel
        let am11amLabelAttrString = NSMutableAttributedString(string: "10am - 11am", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 12, paragraphSpacing: 0)
        ])
        self.am11amLabel.attributedText = am11amLabelAttrString
        
        // Setup minLabel
        let minLabelAttrString = NSMutableAttributedString(string: "30min", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.minLabel.attributedText = minLabelAttrString
        
        // Setup deliveryLabel
        let deliveryLabelAttrString = NSMutableAttributedString(string: "Delivery", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 12, paragraphSpacing: 0)
        ])
        self.deliveryLabel.attributedText = deliveryLabelAttrString
        
    }

    private func setupUI()  {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    private func setupGestureRecognizers()  {
    
    }

    private func setupLocalization()  {
    
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Status Bar

    override public var prefersStatusBarHidden: Bool  {
        return false
    }

    override public var preferredStatusBarStyle: UIStatusBarStyle  {
        return .default
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Actions

    @IBAction public func onButtonPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Search On List", sender: nil)
    }

    @IBAction public func onBackPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Search Filter", sender: nil)
    }
}


// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Extension ShopHomeViewController

extension ShopHomeViewController: UISearchBarDelegate  {


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Methods
    public func searchBarTextDidBeginEditing(_ searchBar: UISearchBar)  {
    
    }

    public func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String)  {
    
    }

    public func searchBarTextDidEndEditing(_ searchBar: UISearchBar)  {
    
    }

    public func searchBarCancelButtonClicked(_ searchBar: UISearchBar)  {
    
    }

    public func searchBarSearchButtonClicked(_ searchBar: UISearchBar)  {
    
    }
}
