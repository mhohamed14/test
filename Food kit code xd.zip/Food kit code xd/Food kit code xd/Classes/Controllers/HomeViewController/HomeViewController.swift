//
//  HomeViewController.swift
//  Food UI Kit
//
//  Created by [Author].
//  Copyright © 2018 [Company]. All rights reserved.
//

// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Import

import UIKit


// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Implementation

class HomeViewController: UIViewController {


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Properties

    @IBOutlet var orderNowButton: SupernovaButton!
    @IBOutlet var orderAnyFoodFromLabel: UILabel!
    @IBOutlet var headerView: UIView!
    @IBOutlet var searchView: UIView!
    @IBOutlet var magnifyingGlassSearchBar: UISearchBar!
    @IBOutlet var filterButton: SupernovaButton!
    @IBOutlet var group5Button: SupernovaButton!
    @IBOutlet var rectangleView: UIView!
    @IBOutlet var rectangleButton: SupernovaButton!
    @IBOutlet var burgerLabel: SupernovaLabel!
    @IBOutlet var rectangleTwoView: UIView!
    @IBOutlet var rectangleTwoButton: SupernovaButton!
    @IBOutlet var pizzaLabel: SupernovaLabel!
    @IBOutlet var rectangleThreeView: UIView!
    @IBOutlet var rectangleThreeButton: SupernovaButton!
    @IBOutlet var sandwichLabel: SupernovaLabel!
    @IBOutlet var rectangleFourView: UIView!
    @IBOutlet var rectangleFourButton: SupernovaButton!
    @IBOutlet var drinksLabel: SupernovaLabel!
    @IBOutlet var rectangleCopy4View: UIView!
    @IBOutlet var rectangleCopy4TwoView: UIView!
    @IBOutlet var labelLabel: SupernovaLabel!
    @IBOutlet var labelTwoLabel: SupernovaLabel!
    @IBOutlet var rectangleCopy4ThreeView: UIView!
    @IBOutlet var rectangleCopy4FourView: UIView!
    @IBOutlet var labelThreeLabel: SupernovaLabel!
    @IBOutlet var labelFourLabel: SupernovaLabel!
    @IBOutlet var rectangleCopy4FiveView: UIView!
    @IBOutlet var rectangleCopy4SixView: UIView!
    @IBOutlet var labelFiveLabel: SupernovaLabel!
    @IBOutlet var labelSixLabel: SupernovaLabel!
    @IBOutlet var rectangleCopy4SevenView: UIView!
    @IBOutlet var rectangleCopy4EightView: UIView!
    @IBOutlet var labelSevenLabel: SupernovaLabel!
    @IBOutlet var labelEightLabel: SupernovaLabel!
    @IBOutlet var rectangleCopy4NineView: UIView!
    @IBOutlet var rectangleCopy4TenView: UIView!
    @IBOutlet var labelNineLabel: SupernovaLabel!
    @IBOutlet var labelTenLabel: SupernovaLabel!
    @IBOutlet var rectangleCopy4ElevenView: UIView!
    @IBOutlet var rectangleCopy4TwelveView: UIView!
    @IBOutlet var labelElevenLabel: SupernovaLabel!
    @IBOutlet var labelTwelveLabel: SupernovaLabel!
    @IBOutlet var rectangleCopy4ThirteenView: UIView!
    @IBOutlet var rectangleCopy4FourteenView: UIView!
    @IBOutlet var labelThirteenLabel: SupernovaLabel!
    @IBOutlet var labelFourteenLabel: SupernovaLabel!
    @IBOutlet var rectangleCopy4FifteenView: UIView!
    @IBOutlet var rectangleCopy4SixteenView: UIView!
    @IBOutlet var labelFifteenLabel: SupernovaLabel!
    @IBOutlet var labelSixteenLabel: SupernovaLabel!
    @IBOutlet var seeAllLabel: SupernovaLabel!
    @IBOutlet var nextButton: SupernovaButton!
    @IBOutlet var tapBarView: UIView!
    @IBOutlet var homeLabel: SupernovaLabel!
    @IBOutlet var profileLabel: SupernovaLabel!
    @IBOutlet var favouriteLabel: SupernovaLabel!
    @IBOutlet var categoryLabel: SupernovaLabel!
    @IBOutlet var nearByLabel: SupernovaLabel!


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Lifecycle

    override public func viewDidLoad()  {
        super.viewDidLoad()
        self.setupComponents()
        self.setupUI()
        self.setupGestureRecognizers()
        self.setupLocalization()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override public func viewWillAppear(_ animated: Bool)  {
        super.viewWillAppear(animated)
        
        // Navigation bar, if any
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Setup

    private func setupComponents()  {
        // Setup orderNowButton
        self.orderNowButton.snImageTextSpacing = 10
        
        // Setup orderAnyFoodFromLabel
        let orderAnyFoodFromLabelAttrString = NSMutableAttributedString(string: "Order any food from app and get the discount", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 18, paragraphSpacing: 0)
        ])
        self.orderAnyFoodFromLabel.attributedText = orderAnyFoodFromLabelAttrString
        
        // Setup headerView
        self.headerView.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.05).cgColor /* #000000 */
        self.headerView.layer.shadowOffset = CGSize(width: 0, height: -1)
        self.headerView.layer.shadowRadius = 3
        self.headerView.layer.shadowOpacity = 1
        
        
        // Setup searchView
        self.searchView.layer.cornerRadius = 7
        self.searchView.layer.masksToBounds = true
        
        // Setup magnifyingGlassSearchBar
        self.magnifyingGlassSearchBar.snFont = UIFont.systemFont(ofSize: 12)
        self.magnifyingGlassSearchBar.snTextColor = UIColor(red: 0, green: 0, blue: 0, alpha: 1) /* #000000 */
        self.magnifyingGlassSearchBar.snFieldBackgroundColor = UIColor(red: 1, green: 1, blue: 1, alpha: 1) /* #FFFFFF */
        
        // Setup filterButton
        self.filterButton.layer.cornerRadius = 7
        self.filterButton.layer.masksToBounds = true
        self.filterButton.snImageTextSpacing = 10
        
        // Setup group5Button
        self.group5Button.snImageTextSpacing = 10
        
        // Setup rectangleView
        self.rectangleView.layer.cornerRadius = 7
        self.rectangleView.layer.masksToBounds = true
        
        // Setup rectangleButton
        self.rectangleButton.layer.cornerRadius = 23
        self.rectangleButton.layer.masksToBounds = true
        self.rectangleButton.snImageTextSpacing = 10
        
        // Setup burgerLabel
        let burgerLabelAttrString = NSMutableAttributedString(string: "Burger", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 12, paragraphSpacing: 0)
        ])
        self.burgerLabel.attributedText = burgerLabelAttrString
        
        // Setup rectangleTwoView
        self.rectangleTwoView.layer.cornerRadius = 7
        self.rectangleTwoView.layer.masksToBounds = true
        
        // Setup rectangleTwoButton
        self.rectangleTwoButton.layer.cornerRadius = 23
        self.rectangleTwoButton.layer.masksToBounds = true
        self.rectangleTwoButton.snImageTextSpacing = 10
        
        // Setup pizzaLabel
        let pizzaLabelAttrString = NSMutableAttributedString(string: "Pizza", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 12, paragraphSpacing: 0)
        ])
        self.pizzaLabel.attributedText = pizzaLabelAttrString
        
        // Setup rectangleThreeView
        self.rectangleThreeView.layer.cornerRadius = 7
        self.rectangleThreeView.layer.masksToBounds = true
        
        // Setup rectangleThreeButton
        self.rectangleThreeButton.layer.cornerRadius = 23
        self.rectangleThreeButton.layer.masksToBounds = true
        self.rectangleThreeButton.snImageTextSpacing = 10
        
        // Setup sandwichLabel
        let sandwichLabelAttrString = NSMutableAttributedString(string: "Sandwich", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 12, paragraphSpacing: 0)
        ])
        self.sandwichLabel.attributedText = sandwichLabelAttrString
        
        // Setup rectangleFourView
        self.rectangleFourView.layer.cornerRadius = 7
        self.rectangleFourView.layer.masksToBounds = true
        
        // Setup rectangleFourButton
        self.rectangleFourButton.layer.cornerRadius = 23
        self.rectangleFourButton.layer.masksToBounds = true
        self.rectangleFourButton.snImageTextSpacing = 10
        
        // Setup drinksLabel
        let drinksLabelAttrString = NSMutableAttributedString(string: "Drinks", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 12, paragraphSpacing: 0)
        ])
        self.drinksLabel.attributedText = drinksLabelAttrString
        
        // Setup rectangleCopy4View
        self.rectangleCopy4View.layer.cornerRadius = 14
        self.rectangleCopy4View.layer.masksToBounds = true
        
        // Setup rectangleCopy4TwoView
        self.rectangleCopy4TwoView.layer.cornerRadius = 14
        self.rectangleCopy4TwoView.layer.masksToBounds = true
        
        // Setup labelLabel
        let labelLabelAttrString = NSMutableAttributedString(string: "$35", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 12, paragraphSpacing: 0)
        ])
        self.labelLabel.attributedText = labelLabelAttrString
        
        // Setup labelTwoLabel
        let labelTwoLabelAttrString = NSMutableAttributedString(string: "3.3", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.labelTwoLabel.attributedText = labelTwoLabelAttrString
        
        // Setup rectangleCopy4ThreeView
        self.rectangleCopy4ThreeView.layer.cornerRadius = 14
        self.rectangleCopy4ThreeView.layer.masksToBounds = true
        
        // Setup rectangleCopy4FourView
        self.rectangleCopy4FourView.layer.cornerRadius = 14
        self.rectangleCopy4FourView.layer.masksToBounds = true
        
        // Setup labelThreeLabel
        let labelThreeLabelAttrString = NSMutableAttributedString(string: "$15", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 12, paragraphSpacing: 0)
        ])
        self.labelThreeLabel.attributedText = labelThreeLabelAttrString
        
        // Setup labelFourLabel
        let labelFourLabelAttrString = NSMutableAttributedString(string: "3.4", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.labelFourLabel.attributedText = labelFourLabelAttrString
        
        // Setup rectangleCopy4FiveView
        self.rectangleCopy4FiveView.layer.cornerRadius = 14
        self.rectangleCopy4FiveView.layer.masksToBounds = true
        
        // Setup rectangleCopy4SixView
        self.rectangleCopy4SixView.layer.cornerRadius = 14
        self.rectangleCopy4SixView.layer.masksToBounds = true
        
        // Setup labelFiveLabel
        let labelFiveLabelAttrString = NSMutableAttributedString(string: "$30", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 12, paragraphSpacing: 0)
        ])
        self.labelFiveLabel.attributedText = labelFiveLabelAttrString
        
        // Setup labelSixLabel
        let labelSixLabelAttrString = NSMutableAttributedString(string: "3.5", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.labelSixLabel.attributedText = labelSixLabelAttrString
        
        // Setup rectangleCopy4SevenView
        self.rectangleCopy4SevenView.layer.cornerRadius = 14
        self.rectangleCopy4SevenView.layer.masksToBounds = true
        
        // Setup rectangleCopy4EightView
        self.rectangleCopy4EightView.layer.cornerRadius = 14
        self.rectangleCopy4EightView.layer.masksToBounds = true
        
        // Setup labelSevenLabel
        let labelSevenLabelAttrString = NSMutableAttributedString(string: "$18", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 12, paragraphSpacing: 0)
        ])
        self.labelSevenLabel.attributedText = labelSevenLabelAttrString
        
        // Setup labelEightLabel
        let labelEightLabelAttrString = NSMutableAttributedString(string: "3.8", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.labelEightLabel.attributedText = labelEightLabelAttrString
        
        // Setup rectangleCopy4NineView
        self.rectangleCopy4NineView.layer.cornerRadius = 14
        self.rectangleCopy4NineView.layer.masksToBounds = true
        
        // Setup rectangleCopy4TenView
        self.rectangleCopy4TenView.layer.cornerRadius = 14
        self.rectangleCopy4TenView.layer.masksToBounds = true
        
        // Setup labelNineLabel
        let labelNineLabelAttrString = NSMutableAttributedString(string: "$25", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 12, paragraphSpacing: 0)
        ])
        self.labelNineLabel.attributedText = labelNineLabelAttrString
        
        // Setup labelTenLabel
        let labelTenLabelAttrString = NSMutableAttributedString(string: "3.9", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.labelTenLabel.attributedText = labelTenLabelAttrString
        
        // Setup rectangleCopy4ElevenView
        self.rectangleCopy4ElevenView.layer.cornerRadius = 14
        self.rectangleCopy4ElevenView.layer.masksToBounds = true
        
        // Setup rectangleCopy4TwelveView
        self.rectangleCopy4TwelveView.layer.cornerRadius = 14
        self.rectangleCopy4TwelveView.layer.masksToBounds = true
        
        // Setup labelElevenLabel
        let labelElevenLabelAttrString = NSMutableAttributedString(string: "$22", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 12, paragraphSpacing: 0)
        ])
        self.labelElevenLabel.attributedText = labelElevenLabelAttrString
        
        // Setup labelTwelveLabel
        let labelTwelveLabelAttrString = NSMutableAttributedString(string: "4.0", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.labelTwelveLabel.attributedText = labelTwelveLabelAttrString
        
        // Setup rectangleCopy4ThirteenView
        self.rectangleCopy4ThirteenView.layer.cornerRadius = 14
        self.rectangleCopy4ThirteenView.layer.masksToBounds = true
        
        // Setup rectangleCopy4FourteenView
        self.rectangleCopy4FourteenView.layer.cornerRadius = 14
        self.rectangleCopy4FourteenView.layer.masksToBounds = true
        
        // Setup labelThirteenLabel
        let labelThirteenLabelAttrString = NSMutableAttributedString(string: "$20", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 12, paragraphSpacing: 0)
        ])
        self.labelThirteenLabel.attributedText = labelThirteenLabelAttrString
        
        // Setup labelFourteenLabel
        let labelFourteenLabelAttrString = NSMutableAttributedString(string: "4.3", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.labelFourteenLabel.attributedText = labelFourteenLabelAttrString
        
        // Setup rectangleCopy4FifteenView
        self.rectangleCopy4FifteenView.layer.cornerRadius = 14
        self.rectangleCopy4FifteenView.layer.masksToBounds = true
        
        // Setup rectangleCopy4SixteenView
        self.rectangleCopy4SixteenView.layer.cornerRadius = 14
        self.rectangleCopy4SixteenView.layer.masksToBounds = true
        
        // Setup labelFifteenLabel
        let labelFifteenLabelAttrString = NSMutableAttributedString(string: "$14", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 12, paragraphSpacing: 0)
        ])
        self.labelFifteenLabel.attributedText = labelFifteenLabelAttrString
        
        // Setup labelSixteenLabel
        let labelSixteenLabelAttrString = NSMutableAttributedString(string: "4.5", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.labelSixteenLabel.attributedText = labelSixteenLabelAttrString
        
        // Setup seeAllLabel
        let seeAllLabelAttrString = NSMutableAttributedString(string: "See all", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 14)!,
            .foregroundColor : UIColor(red: 1, green: 0.82, blue: 0.31, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.seeAllLabel.attributedText = seeAllLabelAttrString
        
        // Setup nextButton
        self.nextButton.snImageTextSpacing = 10
        
        // Setup tapBarView
        self.tapBarView.layer.shadowColor = UIColor(red: 0.536, green: 0.657, blue: 0.794, alpha: 0.104).cgColor /* #89A8CA */
        self.tapBarView.layer.shadowOffset = CGSize(width: 0, height: -1)
        self.tapBarView.layer.shadowRadius = 3
        self.tapBarView.layer.shadowOpacity = 1
        
        self.tapBarView.layer.cornerRadius = 16
        self.tapBarView.layer.masksToBounds = true
        
        // Setup homeLabel
        let homeLabelAttrString = NSMutableAttributedString(string: "Home", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 12, paragraphSpacing: 0)
        ])
        self.homeLabel.attributedText = homeLabelAttrString
        
        // Setup profileLabel
        let profileLabelAttrString = NSMutableAttributedString(string: "Profile", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.78, green: 0.81, blue: 0.86, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 12, paragraphSpacing: 0)
        ])
        self.profileLabel.attributedText = profileLabelAttrString
        
        // Setup favouriteLabel
        let favouriteLabelAttrString = NSMutableAttributedString(string: "Favourite", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.78, green: 0.81, blue: 0.86, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 12, paragraphSpacing: 0)
        ])
        self.favouriteLabel.attributedText = favouriteLabelAttrString
        
        // Setup categoryLabel
        let categoryLabelAttrString = NSMutableAttributedString(string: "Category", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.78, green: 0.81, blue: 0.86, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 12, paragraphSpacing: 0)
        ])
        self.categoryLabel.attributedText = categoryLabelAttrString
        
        // Setup nearByLabel
        let nearByLabelAttrString = NSMutableAttributedString(string: "Near By", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.78, green: 0.81, blue: 0.86, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 12, paragraphSpacing: 0)
        ])
        self.nearByLabel.attributedText = nearByLabelAttrString
        
    }

    private func setupUI()  {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    private func setupGestureRecognizers()  {
    
    }

    private func setupLocalization()  {
    
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Status Bar

    override public var prefersStatusBarHidden: Bool  {
        return false
    }

    override public var preferredStatusBarStyle: UIStatusBarStyle  {
        return .default
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Actions

    @IBAction public func onOrderNowPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Update Password", sender: nil)
    }

    @IBAction public func onFilterPressed(_ sender: UIButton)  {
    
    }

    @IBAction public func onGroup5Pressed(_ sender: UIButton)  {
    
    }

    @IBAction public func onRectanglePressed(_ sender: UIButton)  {
    
    }

    @IBAction public func onRectangleTwoPressed(_ sender: UIButton)  {
    
    }

    @IBAction public func onRectangleThreePressed(_ sender: UIButton)  {
    
    }

    @IBAction public func onRectangleFourPressed(_ sender: UIButton)  {
    
    }

    @IBAction public func onNextPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Food Category", sender: nil)
    }
}


// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Extension HomeViewController

extension HomeViewController: UISearchBarDelegate  {


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Methods
    public func searchBarTextDidBeginEditing(_ searchBar: UISearchBar)  {
    
    }

    public func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String)  {
    
    }

    public func searchBarTextDidEndEditing(_ searchBar: UISearchBar)  {
    
    }

    public func searchBarCancelButtonClicked(_ searchBar: UISearchBar)  {
    
    }

    public func searchBarSearchButtonClicked(_ searchBar: UISearchBar)  {
    
    }
}
