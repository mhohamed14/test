//
//  DeliveryAddressViewController.swift
//  Food UI Kit
//
//  Created by [Author].
//  Copyright © 2018 [Company]. All rights reserved.
//

// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Import

import UIKit


// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Implementation

class DeliveryAddressViewController: UIViewController {


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Properties

    @IBOutlet var addressView: UIView!
    @IBOutlet var puratonCustomChhaLabel: SupernovaLabel!
    @IBOutlet var cEastRoadLabel: SupernovaLabel!
    @IBOutlet var labelLabel: SupernovaLabel!
    @IBOutlet var addressCopyView: UIView!
    @IBOutlet var thanaGhatRoadChhLabel: SupernovaLabel!
    @IBOutlet var cEastRoadTwoLabel: SupernovaLabel!
    @IBOutlet var labelTwoLabel: SupernovaLabel!
    @IBOutlet var addressCopy2View: UIView!
    @IBOutlet var dhakBanglaRoadChLabel: SupernovaLabel!
    @IBOutlet var cEastRoadThreeLabel: SupernovaLabel!
    @IBOutlet var labelThreeLabel: SupernovaLabel!
    @IBOutlet var addressCopy3View: UIView!
    @IBOutlet var busStandChhatakLabel: SupernovaLabel!
    @IBOutlet var cEastRoadFourLabel: SupernovaLabel!
    @IBOutlet var labelFourLabel: SupernovaLabel!
    @IBOutlet var addButtonButton: SupernovaButton!


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Lifecycle

    override public func viewDidLoad()  {
        super.viewDidLoad()
        self.setupComponents()
        self.setupUI()
        self.setupGestureRecognizers()
        self.setupLocalization()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override public func viewWillAppear(_ animated: Bool)  {
        super.viewWillAppear(animated)
        
        // Navigation bar, if any
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Setup

    private func setupComponents()  {
        // Setup addressView
        self.addressView.layer.shadowColor = UIColor(red: 0.827, green: 0.851, blue: 0.89, alpha: 0.149).cgColor /* #D3D9E3 */
        self.addressView.layer.shadowOffset = CGSize(width: 0, height: 2)
        self.addressView.layer.shadowRadius = 7
        self.addressView.layer.shadowOpacity = 1
        
        self.addressView.layer.cornerRadius = 9
        self.addressView.layer.masksToBounds = true
        
        // Setup puratonCustomChhaLabel
        let puratonCustomChhaLabelAttrString = NSMutableAttributedString(string: "Puraton Custom, Chhatak", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.puratonCustomChhaLabel.attributedText = puratonCustomChhaLabelAttrString
        
        // Setup cEastRoadLabel
        let cEastRoadLabelAttrString = NSMutableAttributedString(string: "216/C East Road", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.cEastRoadLabel.attributedText = cEastRoadLabelAttrString
        
        // Setup labelLabel
        let labelLabelAttrString = NSMutableAttributedString(string: "+88 012 356 870", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.labelLabel.attributedText = labelLabelAttrString
        
        // Setup addressCopyView
        self.addressCopyView.layer.shadowColor = UIColor(red: 0.827, green: 0.851, blue: 0.89, alpha: 0.149).cgColor /* #D3D9E3 */
        self.addressCopyView.layer.shadowOffset = CGSize(width: 0, height: 2)
        self.addressCopyView.layer.shadowRadius = 7
        self.addressCopyView.layer.shadowOpacity = 1
        
        self.addressCopyView.layer.cornerRadius = 9
        self.addressCopyView.layer.masksToBounds = true
        
        // Setup thanaGhatRoadChhLabel
        let thanaGhatRoadChhLabelAttrString = NSMutableAttributedString(string: "Thana Ghat Road, Chhatak", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.thanaGhatRoadChhLabel.attributedText = thanaGhatRoadChhLabelAttrString
        
        // Setup cEastRoadTwoLabel
        let cEastRoadTwoLabelAttrString = NSMutableAttributedString(string: "216/C East Road", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.cEastRoadTwoLabel.attributedText = cEastRoadTwoLabelAttrString
        
        // Setup labelTwoLabel
        let labelTwoLabelAttrString = NSMutableAttributedString(string: "+88 012 356 870", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.labelTwoLabel.attributedText = labelTwoLabelAttrString
        
        // Setup addressCopy2View
        self.addressCopy2View.layer.shadowColor = UIColor(red: 0.827, green: 0.851, blue: 0.89, alpha: 0.149).cgColor /* #D3D9E3 */
        self.addressCopy2View.layer.shadowOffset = CGSize(width: 0, height: 2)
        self.addressCopy2View.layer.shadowRadius = 7
        self.addressCopy2View.layer.shadowOpacity = 1
        
        self.addressCopy2View.layer.cornerRadius = 9
        self.addressCopy2View.layer.masksToBounds = true
        
        // Setup dhakBanglaRoadChLabel
        let dhakBanglaRoadChLabelAttrString = NSMutableAttributedString(string: "Dhak Bangla Road, Chhatak", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.dhakBanglaRoadChLabel.attributedText = dhakBanglaRoadChLabelAttrString
        
        // Setup cEastRoadThreeLabel
        let cEastRoadThreeLabelAttrString = NSMutableAttributedString(string: "216/C East Road", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.cEastRoadThreeLabel.attributedText = cEastRoadThreeLabelAttrString
        
        // Setup labelThreeLabel
        let labelThreeLabelAttrString = NSMutableAttributedString(string: "+88 012 356 870", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.labelThreeLabel.attributedText = labelThreeLabelAttrString
        
        // Setup addressCopy3View
        self.addressCopy3View.layer.shadowColor = UIColor(red: 0.827, green: 0.851, blue: 0.89, alpha: 0.149).cgColor /* #D3D9E3 */
        self.addressCopy3View.layer.shadowOffset = CGSize(width: 0, height: 2)
        self.addressCopy3View.layer.shadowRadius = 7
        self.addressCopy3View.layer.shadowOpacity = 1
        
        self.addressCopy3View.layer.cornerRadius = 9
        self.addressCopy3View.layer.masksToBounds = true
        
        // Setup busStandChhatakLabel
        let busStandChhatakLabelAttrString = NSMutableAttributedString(string: "Bus Stand, Chhatak", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.busStandChhatakLabel.attributedText = busStandChhatakLabelAttrString
        
        // Setup cEastRoadFourLabel
        let cEastRoadFourLabelAttrString = NSMutableAttributedString(string: "216/C East Road", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.cEastRoadFourLabel.attributedText = cEastRoadFourLabelAttrString
        
        // Setup labelFourLabel
        let labelFourLabelAttrString = NSMutableAttributedString(string: "+88 012 356 870", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.labelFourLabel.attributedText = labelFourLabelAttrString
        
        // Setup addButtonButton
        self.addButtonButton.snImageTextSpacing = 10
        
    }

    private func setupUI()  {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    private func setupGestureRecognizers()  {
    
    }

    private func setupLocalization()  {
    
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Status Bar

    override public var prefersStatusBarHidden: Bool  {
        return false
    }

    override public var preferredStatusBarStyle: UIStatusBarStyle  {
        return .default
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Actions

    @IBAction public func onAddButtonPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Offer and promos", sender: nil)
    }
}
