//
//  EditDeliveryAddressViewController.swift
//  Food UI Kit
//
//  Created by [Author].
//  Copyright © 2018 [Company]. All rights reserved.
//

// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Import

import UIKit


// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Implementation

class EditDeliveryAddressViewController: UIViewController {


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Properties

    @IBOutlet var rectangleView: UIView!
    @IBOutlet var buttonButton: SupernovaButton!
    @IBOutlet var passswordLabel: SupernovaLabel!
    @IBOutlet var group16View: UIView!
    @IBOutlet var group16TwoView: UIView!
    @IBOutlet var passswordTwoLabel: SupernovaLabel!
    @IBOutlet var group16ThreeView: UIView!
    @IBOutlet var passswordThreeLabel: SupernovaLabel!
    @IBOutlet var group16FourView: UIView!
    @IBOutlet var makeDefaultShippinLabel: SupernovaLabel!


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Lifecycle

    override public func viewDidLoad()  {
        super.viewDidLoad()
        self.setupComponents()
        self.setupUI()
        self.setupGestureRecognizers()
        self.setupLocalization()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override public func viewWillAppear(_ animated: Bool)  {
        super.viewWillAppear(animated)
        
        // Navigation bar, if any
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Setup

    private func setupComponents()  {
        // Setup rectangleView
        self.rectangleView.layer.cornerRadius = 15
        self.rectangleView.layer.masksToBounds = true
        
        // Setup buttonButton
        self.buttonButton.layer.cornerRadius = 4
        self.buttonButton.layer.masksToBounds = true
        self.buttonButton.snImageTextSpacing = 10
        
        // Setup passswordLabel
        let passswordLabelAttrString = NSMutableAttributedString(string: "Full Name", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 12, paragraphSpacing: 0)
        ])
        self.passswordLabel.attributedText = passswordLabelAttrString
        
        // Setup group16View
        self.group16View.layer.borderColor = UIColor(red: 0.929, green: 0.941, blue: 0.949, alpha: 1).cgColor /* #EDF0F2 */
        self.group16View.layer.borderWidth = 1
        
        self.group16View.layer.cornerRadius = 7
        self.group16View.layer.masksToBounds = true
        
        // Setup group16TwoView
        self.group16TwoView.layer.borderColor = UIColor(red: 0.929, green: 0.941, blue: 0.949, alpha: 1).cgColor /* #EDF0F2 */
        self.group16TwoView.layer.borderWidth = 1
        
        self.group16TwoView.layer.cornerRadius = 7
        self.group16TwoView.layer.masksToBounds = true
        
        // Setup passswordTwoLabel
        let passswordTwoLabelAttrString = NSMutableAttributedString(string: "Address Line 1", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 12, paragraphSpacing: 0)
        ])
        self.passswordTwoLabel.attributedText = passswordTwoLabelAttrString
        
        // Setup group16ThreeView
        self.group16ThreeView.layer.borderColor = UIColor(red: 0.929, green: 0.941, blue: 0.949, alpha: 1).cgColor /* #EDF0F2 */
        self.group16ThreeView.layer.borderWidth = 1
        
        self.group16ThreeView.layer.cornerRadius = 7
        self.group16ThreeView.layer.masksToBounds = true
        
        // Setup passswordThreeLabel
        let passswordThreeLabelAttrString = NSMutableAttributedString(string: "Address Line 2", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 12, paragraphSpacing: 0)
        ])
        self.passswordThreeLabel.attributedText = passswordThreeLabelAttrString
        
        // Setup group16FourView
        self.group16FourView.layer.borderColor = UIColor(red: 0.929, green: 0.941, blue: 0.949, alpha: 1).cgColor /* #EDF0F2 */
        self.group16FourView.layer.borderWidth = 1
        
        self.group16FourView.layer.cornerRadius = 7
        self.group16FourView.layer.masksToBounds = true
        
        // Setup makeDefaultShippinLabel
        let makeDefaultShippinLabelAttrString = NSMutableAttributedString(string: "Make default shipping address", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.makeDefaultShippinLabel.attributedText = makeDefaultShippinLabelAttrString
        
    }

    private func setupUI()  {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    private func setupGestureRecognizers()  {
    
    }

    private func setupLocalization()  {
    
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Status Bar

    override public var prefersStatusBarHidden: Bool  {
        return false
    }

    override public var preferredStatusBarStyle: UIStatusBarStyle  {
        return .default
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Actions

    @IBAction public func onButtonPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Delivery Address", sender: nil)
    }
}
