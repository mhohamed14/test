//
//  BurgerCategoryPageViewController.swift
//  Food UI Kit
//
//  Created by [Author].
//  Copyright © 2018 [Company]. All rights reserved.
//

// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Import

import UIKit


// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Implementation

class BurgerCategoryPageViewController: UIViewController {


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Properties

    @IBOutlet var rectangleCopy4View: UIView!
    @IBOutlet var rectangleCopy4TwoView: UIView!
    @IBOutlet var labelLabel: SupernovaLabel!
    @IBOutlet var labelTwoLabel: SupernovaLabel!
    @IBOutlet var rectangleCopy4ThreeView: UIView!
    @IBOutlet var rectangleCopy4FourView: UIView!
    @IBOutlet var labelThreeLabel: SupernovaLabel!
    @IBOutlet var labelFourLabel: SupernovaLabel!
    @IBOutlet var rectangleCopy4FiveView: UIView!
    @IBOutlet var rectangleCopy4SixView: UIView!
    @IBOutlet var labelFiveLabel: SupernovaLabel!
    @IBOutlet var labelSixLabel: SupernovaLabel!
    @IBOutlet var rectangleCopy4SevenView: UIView!
    @IBOutlet var rectangleCopy4EightView: UIView!
    @IBOutlet var labelSevenLabel: SupernovaLabel!
    @IBOutlet var labelEightLabel: SupernovaLabel!
    @IBOutlet var rectangleCopy4NineView: UIView!
    @IBOutlet var rectangleCopy4TenView: UIView!
    @IBOutlet var labelNineLabel: SupernovaLabel!
    @IBOutlet var labelTenLabel: SupernovaLabel!
    @IBOutlet var rectangleCopy4ElevenView: UIView!
    @IBOutlet var rectangleCopy4TwelveView: UIView!
    @IBOutlet var labelElevenLabel: SupernovaLabel!
    @IBOutlet var labelTwelveLabel: SupernovaLabel!
    @IBOutlet var rectangleCopy4ThirteenView: UIView!
    @IBOutlet var rectangleCopy4FourteenView: UIView!
    @IBOutlet var labelThirteenLabel: SupernovaLabel!
    @IBOutlet var labelFourteenLabel: SupernovaLabel!
    @IBOutlet var rectangleCopy4FifteenView: UIView!
    @IBOutlet var rectangleCopy4SixteenView: UIView!
    @IBOutlet var labelFifteenLabel: SupernovaLabel!
    @IBOutlet var labelSixteenLabel: SupernovaLabel!
    @IBOutlet var backButton: SupernovaButton!
    @IBOutlet var cartButton: SupernovaButton!


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Lifecycle

    override public func viewDidLoad()  {
        super.viewDidLoad()
        self.setupComponents()
        self.setupUI()
        self.setupGestureRecognizers()
        self.setupLocalization()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override public func viewWillAppear(_ animated: Bool)  {
        super.viewWillAppear(animated)
        
        // Navigation bar, if any
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Setup

    private func setupComponents()  {
        // Setup rectangleCopy4View
        self.rectangleCopy4View.layer.cornerRadius = 14
        self.rectangleCopy4View.layer.masksToBounds = true
        
        // Setup rectangleCopy4TwoView
        self.rectangleCopy4TwoView.layer.cornerRadius = 14
        self.rectangleCopy4TwoView.layer.masksToBounds = true
        
        // Setup labelLabel
        let labelLabelAttrString = NSMutableAttributedString(string: "$35", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 12, paragraphSpacing: 0)
        ])
        self.labelLabel.attributedText = labelLabelAttrString
        
        // Setup labelTwoLabel
        let labelTwoLabelAttrString = NSMutableAttributedString(string: "3.3", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.labelTwoLabel.attributedText = labelTwoLabelAttrString
        
        // Setup rectangleCopy4ThreeView
        self.rectangleCopy4ThreeView.layer.cornerRadius = 14
        self.rectangleCopy4ThreeView.layer.masksToBounds = true
        
        // Setup rectangleCopy4FourView
        self.rectangleCopy4FourView.layer.cornerRadius = 14
        self.rectangleCopy4FourView.layer.masksToBounds = true
        
        // Setup labelThreeLabel
        let labelThreeLabelAttrString = NSMutableAttributedString(string: "$15", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 12, paragraphSpacing: 0)
        ])
        self.labelThreeLabel.attributedText = labelThreeLabelAttrString
        
        // Setup labelFourLabel
        let labelFourLabelAttrString = NSMutableAttributedString(string: "3.4", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.labelFourLabel.attributedText = labelFourLabelAttrString
        
        // Setup rectangleCopy4FiveView
        self.rectangleCopy4FiveView.layer.cornerRadius = 14
        self.rectangleCopy4FiveView.layer.masksToBounds = true
        
        // Setup rectangleCopy4SixView
        self.rectangleCopy4SixView.layer.cornerRadius = 14
        self.rectangleCopy4SixView.layer.masksToBounds = true
        
        // Setup labelFiveLabel
        let labelFiveLabelAttrString = NSMutableAttributedString(string: "$30", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 12, paragraphSpacing: 0)
        ])
        self.labelFiveLabel.attributedText = labelFiveLabelAttrString
        
        // Setup labelSixLabel
        let labelSixLabelAttrString = NSMutableAttributedString(string: "3.5", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.labelSixLabel.attributedText = labelSixLabelAttrString
        
        // Setup rectangleCopy4SevenView
        self.rectangleCopy4SevenView.layer.cornerRadius = 14
        self.rectangleCopy4SevenView.layer.masksToBounds = true
        
        // Setup rectangleCopy4EightView
        self.rectangleCopy4EightView.layer.cornerRadius = 14
        self.rectangleCopy4EightView.layer.masksToBounds = true
        
        // Setup labelSevenLabel
        let labelSevenLabelAttrString = NSMutableAttributedString(string: "$18", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 12, paragraphSpacing: 0)
        ])
        self.labelSevenLabel.attributedText = labelSevenLabelAttrString
        
        // Setup labelEightLabel
        let labelEightLabelAttrString = NSMutableAttributedString(string: "3.8", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.labelEightLabel.attributedText = labelEightLabelAttrString
        
        // Setup rectangleCopy4NineView
        self.rectangleCopy4NineView.layer.cornerRadius = 14
        self.rectangleCopy4NineView.layer.masksToBounds = true
        
        // Setup rectangleCopy4TenView
        self.rectangleCopy4TenView.layer.cornerRadius = 14
        self.rectangleCopy4TenView.layer.masksToBounds = true
        
        // Setup labelNineLabel
        let labelNineLabelAttrString = NSMutableAttributedString(string: "$25", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 12, paragraphSpacing: 0)
        ])
        self.labelNineLabel.attributedText = labelNineLabelAttrString
        
        // Setup labelTenLabel
        let labelTenLabelAttrString = NSMutableAttributedString(string: "3.9", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.labelTenLabel.attributedText = labelTenLabelAttrString
        
        // Setup rectangleCopy4ElevenView
        self.rectangleCopy4ElevenView.layer.cornerRadius = 14
        self.rectangleCopy4ElevenView.layer.masksToBounds = true
        
        // Setup rectangleCopy4TwelveView
        self.rectangleCopy4TwelveView.layer.cornerRadius = 14
        self.rectangleCopy4TwelveView.layer.masksToBounds = true
        
        // Setup labelElevenLabel
        let labelElevenLabelAttrString = NSMutableAttributedString(string: "$22", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 12, paragraphSpacing: 0)
        ])
        self.labelElevenLabel.attributedText = labelElevenLabelAttrString
        
        // Setup labelTwelveLabel
        let labelTwelveLabelAttrString = NSMutableAttributedString(string: "4.0", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.labelTwelveLabel.attributedText = labelTwelveLabelAttrString
        
        // Setup rectangleCopy4ThirteenView
        self.rectangleCopy4ThirteenView.layer.cornerRadius = 14
        self.rectangleCopy4ThirteenView.layer.masksToBounds = true
        
        // Setup rectangleCopy4FourteenView
        self.rectangleCopy4FourteenView.layer.cornerRadius = 14
        self.rectangleCopy4FourteenView.layer.masksToBounds = true
        
        // Setup labelThirteenLabel
        let labelThirteenLabelAttrString = NSMutableAttributedString(string: "$20", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 12, paragraphSpacing: 0)
        ])
        self.labelThirteenLabel.attributedText = labelThirteenLabelAttrString
        
        // Setup labelFourteenLabel
        let labelFourteenLabelAttrString = NSMutableAttributedString(string: "4.3", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.labelFourteenLabel.attributedText = labelFourteenLabelAttrString
        
        // Setup rectangleCopy4FifteenView
        self.rectangleCopy4FifteenView.layer.cornerRadius = 14
        self.rectangleCopy4FifteenView.layer.masksToBounds = true
        
        // Setup rectangleCopy4SixteenView
        self.rectangleCopy4SixteenView.layer.cornerRadius = 14
        self.rectangleCopy4SixteenView.layer.masksToBounds = true
        
        // Setup labelFifteenLabel
        let labelFifteenLabelAttrString = NSMutableAttributedString(string: "$14", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 12, paragraphSpacing: 0)
        ])
        self.labelFifteenLabel.attributedText = labelFifteenLabelAttrString
        
        // Setup labelSixteenLabel
        let labelSixteenLabelAttrString = NSMutableAttributedString(string: "4.5", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.labelSixteenLabel.attributedText = labelSixteenLabelAttrString
        
        // Setup backButton
        self.backButton.snImageTextSpacing = 10
        
        // Setup cartButton
        self.cartButton.snImageTextSpacing = 10
        
    }

    private func setupUI()  {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    private func setupGestureRecognizers()  {
    
    }

    private func setupLocalization()  {
    
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Status Bar

    override public var prefersStatusBarHidden: Bool  {
        return false
    }

    override public var preferredStatusBarStyle: UIStatusBarStyle  {
        return .default
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Actions

    @IBAction public func onBackPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Burger Order App Details", sender: nil)
    }

    @IBAction public func onCartPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Food Category", sender: nil)
    }
}
