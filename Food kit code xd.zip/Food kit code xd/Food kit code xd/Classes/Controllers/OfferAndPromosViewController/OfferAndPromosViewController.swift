//
//  OfferAndPromosViewController.swift
//  Food UI Kit
//
//  Created by [Author].
//  Copyright © 2018 [Company]. All rights reserved.
//

// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Import

import UIKit


// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Implementation

class OfferAndPromosViewController: UIViewController {


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Properties

    @IBOutlet var rectangleCopy7View: UIView!
    @IBOutlet var ovalCopyView: UIView!
    @IBOutlet var ovalCopy3View: UIView!
    @IBOutlet var ovalCopy2View: UIView!
    @IBOutlet var rectangleView: UIView!
    @IBOutlet var ovalView: UIView!
    @IBOutlet var burgerKingLabel: SupernovaLabel!
    @IBOutlet var offLabel: SupernovaLabel!
    @IBOutlet var validUntil20May2Label: SupernovaLabel!
    @IBOutlet var buttonButton: SupernovaButton!
    @IBOutlet var rectangleCopy7TwoView: UIView!
    @IBOutlet var ovalCopyTwoView: UIView!
    @IBOutlet var ovalCopy5View: UIView!
    @IBOutlet var ovalCopy4View: UIView!
    @IBOutlet var rectangleTwoView: UIView!
    @IBOutlet var ovalTwoView: UIView!
    @IBOutlet var grindersBurgerLabel: SupernovaLabel!
    @IBOutlet var offTwoLabel: SupernovaLabel!
    @IBOutlet var validUntil20May2TwoLabel: SupernovaLabel!
    @IBOutlet var buttonTwoButton: SupernovaButton!
    @IBOutlet var rectangleCopy7ThreeView: UIView!
    @IBOutlet var ovalCopyThreeView: UIView!
    @IBOutlet var ovalCopy7View: UIView!
    @IBOutlet var ovalCopy6View: UIView!
    @IBOutlet var rectangleThreeView: UIView!
    @IBOutlet var ovalThreeView: UIView!
    @IBOutlet var kfcLabel: SupernovaLabel!
    @IBOutlet var offThreeLabel: SupernovaLabel!
    @IBOutlet var validUntil20May2ThreeLabel: SupernovaLabel!
    @IBOutlet var buttonThreeButton: SupernovaButton!
    @IBOutlet var rectangleCopy7FourView: UIView!
    @IBOutlet var ovalCopyFourView: UIView!
    @IBOutlet var ovalCopy9View: UIView!
    @IBOutlet var ovalCopy8View: UIView!
    @IBOutlet var rectangleFourView: UIView!
    @IBOutlet var ovalFourView: UIView!
    @IBOutlet var burgerKingTwoLabel: SupernovaLabel!
    @IBOutlet var offFourLabel: SupernovaLabel!
    @IBOutlet var validUntil20May2FourLabel: SupernovaLabel!
    @IBOutlet var buttonFourButton: SupernovaButton!
    @IBOutlet var rectangleCopy7FiveView: UIView!
    @IBOutlet var ovalCopyFiveView: UIView!
    @IBOutlet var ovalCopy11View: UIView!
    @IBOutlet var ovalCopy10View: UIView!
    @IBOutlet var rectangleFiveView: UIView!
    @IBOutlet var ovalFiveView: UIView!
    @IBOutlet var burgerKingThreeLabel: SupernovaLabel!
    @IBOutlet var offFiveLabel: SupernovaLabel!
    @IBOutlet var validUntil20May2FiveLabel: SupernovaLabel!
    @IBOutlet var buttonFiveButton: SupernovaButton!
    @IBOutlet var userNameView: UIView!
    @IBOutlet var rectangleCopy8Button: SupernovaButton!
    @IBOutlet var currentLabel: SupernovaLabel!
    @IBOutlet var usedLabel: SupernovaLabel!
    @IBOutlet var backButton: SupernovaButton!


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Lifecycle

    override public func viewDidLoad()  {
        super.viewDidLoad()
        self.setupComponents()
        self.setupUI()
        self.setupGestureRecognizers()
        self.setupLocalization()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override public func viewWillAppear(_ animated: Bool)  {
        super.viewWillAppear(animated)
        
        // Navigation bar, if any
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Setup

    private func setupComponents()  {
        // Setup rectangleCopy7View
        self.rectangleCopy7View.layer.shadowColor = UIColor(red: 0.827, green: 0.851, blue: 0.89, alpha: 0.348).cgColor /* #D3D9E3 */
        self.rectangleCopy7View.layer.shadowOffset = CGSize(width: 0, height: 0)
        self.rectangleCopy7View.layer.shadowRadius = 7
        self.rectangleCopy7View.layer.shadowOpacity = 1
        
        self.rectangleCopy7View.layer.cornerRadius = 9
        self.rectangleCopy7View.layer.masksToBounds = true
        
        // Setup ovalCopyView
        self.ovalCopyView.layer.cornerRadius = 13
        self.ovalCopyView.layer.masksToBounds = true
        
        // Setup ovalCopy3View
        self.ovalCopy3View.layer.cornerRadius = 13
        self.ovalCopy3View.layer.masksToBounds = true
        
        // Setup ovalCopy2View
        self.ovalCopy2View.layer.cornerRadius = 13
        self.ovalCopy2View.layer.masksToBounds = true
        
        // Setup rectangleView
        self.rectangleView.layer.cornerRadius = 9
        self.rectangleView.layer.masksToBounds = true
        
        // Setup ovalView
        self.ovalView.layer.cornerRadius = 13
        self.ovalView.layer.masksToBounds = true
        
        // Setup burgerKingLabel
        let burgerKingLabelAttrString = NSMutableAttributedString(string: "Burger King", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.burgerKingLabel.attributedText = burgerKingLabelAttrString
        
        // Setup offLabel
        let offLabelAttrString = NSMutableAttributedString(string: "$10 Off", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 24)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 22, paragraphSpacing: 0)
        ])
        self.offLabel.attributedText = offLabelAttrString
        
        // Setup validUntil20May2Label
        let validUntil20May2LabelAttrString = NSMutableAttributedString(string: "Valid until 20 May 2020", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.validUntil20May2Label.attributedText = validUntil20May2LabelAttrString
        
        // Setup buttonButton
        self.buttonButton.layer.cornerRadius = 3
        self.buttonButton.layer.masksToBounds = true
        self.buttonButton.snImageTextSpacing = 10
        
        // Setup rectangleCopy7TwoView
        self.rectangleCopy7TwoView.layer.shadowColor = UIColor(red: 0.827, green: 0.851, blue: 0.89, alpha: 0.348).cgColor /* #D3D9E3 */
        self.rectangleCopy7TwoView.layer.shadowOffset = CGSize(width: 0, height: 0)
        self.rectangleCopy7TwoView.layer.shadowRadius = 7
        self.rectangleCopy7TwoView.layer.shadowOpacity = 1
        
        self.rectangleCopy7TwoView.layer.cornerRadius = 9
        self.rectangleCopy7TwoView.layer.masksToBounds = true
        
        // Setup ovalCopyTwoView
        self.ovalCopyTwoView.layer.cornerRadius = 13
        self.ovalCopyTwoView.layer.masksToBounds = true
        
        // Setup ovalCopy5View
        self.ovalCopy5View.layer.cornerRadius = 13
        self.ovalCopy5View.layer.masksToBounds = true
        
        // Setup ovalCopy4View
        self.ovalCopy4View.layer.cornerRadius = 13
        self.ovalCopy4View.layer.masksToBounds = true
        
        // Setup rectangleTwoView
        self.rectangleTwoView.layer.cornerRadius = 9
        self.rectangleTwoView.layer.masksToBounds = true
        
        // Setup ovalTwoView
        self.ovalTwoView.layer.cornerRadius = 13
        self.ovalTwoView.layer.masksToBounds = true
        
        // Setup grindersBurgerLabel
        let grindersBurgerLabelAttrString = NSMutableAttributedString(string: "Grinders Burger", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.grindersBurgerLabel.attributedText = grindersBurgerLabelAttrString
        
        // Setup offTwoLabel
        let offTwoLabelAttrString = NSMutableAttributedString(string: "30% Off", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 24)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 22, paragraphSpacing: 0)
        ])
        self.offTwoLabel.attributedText = offTwoLabelAttrString
        
        // Setup validUntil20May2TwoLabel
        let validUntil20May2TwoLabelAttrString = NSMutableAttributedString(string: "Valid until 20 May 2020", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.validUntil20May2TwoLabel.attributedText = validUntil20May2TwoLabelAttrString
        
        // Setup buttonTwoButton
        self.buttonTwoButton.layer.cornerRadius = 3
        self.buttonTwoButton.layer.masksToBounds = true
        self.buttonTwoButton.snImageTextSpacing = 10
        
        // Setup rectangleCopy7ThreeView
        self.rectangleCopy7ThreeView.layer.shadowColor = UIColor(red: 0.827, green: 0.851, blue: 0.89, alpha: 0.348).cgColor /* #D3D9E3 */
        self.rectangleCopy7ThreeView.layer.shadowOffset = CGSize(width: 0, height: 0)
        self.rectangleCopy7ThreeView.layer.shadowRadius = 7
        self.rectangleCopy7ThreeView.layer.shadowOpacity = 1
        
        self.rectangleCopy7ThreeView.layer.cornerRadius = 9
        self.rectangleCopy7ThreeView.layer.masksToBounds = true
        
        // Setup ovalCopyThreeView
        self.ovalCopyThreeView.layer.cornerRadius = 13
        self.ovalCopyThreeView.layer.masksToBounds = true
        
        // Setup ovalCopy7View
        self.ovalCopy7View.layer.cornerRadius = 13
        self.ovalCopy7View.layer.masksToBounds = true
        
        // Setup ovalCopy6View
        self.ovalCopy6View.layer.cornerRadius = 13
        self.ovalCopy6View.layer.masksToBounds = true
        
        // Setup rectangleThreeView
        self.rectangleThreeView.layer.cornerRadius = 9
        self.rectangleThreeView.layer.masksToBounds = true
        
        // Setup ovalThreeView
        self.ovalThreeView.layer.cornerRadius = 13
        self.ovalThreeView.layer.masksToBounds = true
        
        // Setup kfcLabel
        let kfcLabelAttrString = NSMutableAttributedString(string: "KFC", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.kfcLabel.attributedText = kfcLabelAttrString
        
        // Setup offThreeLabel
        let offThreeLabelAttrString = NSMutableAttributedString(string: "$20 Off", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 24)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 22, paragraphSpacing: 0)
        ])
        self.offThreeLabel.attributedText = offThreeLabelAttrString
        
        // Setup validUntil20May2ThreeLabel
        let validUntil20May2ThreeLabelAttrString = NSMutableAttributedString(string: "Valid until 20 May 2020", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.validUntil20May2ThreeLabel.attributedText = validUntil20May2ThreeLabelAttrString
        
        // Setup buttonThreeButton
        self.buttonThreeButton.layer.cornerRadius = 3
        self.buttonThreeButton.layer.masksToBounds = true
        self.buttonThreeButton.snImageTextSpacing = 10
        
        // Setup rectangleCopy7FourView
        self.rectangleCopy7FourView.layer.shadowColor = UIColor(red: 0.827, green: 0.851, blue: 0.89, alpha: 0.348).cgColor /* #D3D9E3 */
        self.rectangleCopy7FourView.layer.shadowOffset = CGSize(width: 0, height: 0)
        self.rectangleCopy7FourView.layer.shadowRadius = 7
        self.rectangleCopy7FourView.layer.shadowOpacity = 1
        
        self.rectangleCopy7FourView.layer.cornerRadius = 9
        self.rectangleCopy7FourView.layer.masksToBounds = true
        
        // Setup ovalCopyFourView
        self.ovalCopyFourView.layer.cornerRadius = 13
        self.ovalCopyFourView.layer.masksToBounds = true
        
        // Setup ovalCopy9View
        self.ovalCopy9View.layer.cornerRadius = 13
        self.ovalCopy9View.layer.masksToBounds = true
        
        // Setup ovalCopy8View
        self.ovalCopy8View.layer.cornerRadius = 13
        self.ovalCopy8View.layer.masksToBounds = true
        
        // Setup rectangleFourView
        self.rectangleFourView.layer.cornerRadius = 9
        self.rectangleFourView.layer.masksToBounds = true
        
        // Setup ovalFourView
        self.ovalFourView.layer.cornerRadius = 13
        self.ovalFourView.layer.masksToBounds = true
        
        // Setup burgerKingTwoLabel
        let burgerKingTwoLabelAttrString = NSMutableAttributedString(string: "Burger King", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.burgerKingTwoLabel.attributedText = burgerKingTwoLabelAttrString
        
        // Setup offFourLabel
        let offFourLabelAttrString = NSMutableAttributedString(string: "50% Off", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 24)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 22, paragraphSpacing: 0)
        ])
        self.offFourLabel.attributedText = offFourLabelAttrString
        
        // Setup validUntil20May2FourLabel
        let validUntil20May2FourLabelAttrString = NSMutableAttributedString(string: "Valid until 20 May 2020", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.validUntil20May2FourLabel.attributedText = validUntil20May2FourLabelAttrString
        
        // Setup buttonFourButton
        self.buttonFourButton.layer.cornerRadius = 3
        self.buttonFourButton.layer.masksToBounds = true
        self.buttonFourButton.snImageTextSpacing = 10
        
        // Setup rectangleCopy7FiveView
        self.rectangleCopy7FiveView.layer.shadowColor = UIColor(red: 0.827, green: 0.851, blue: 0.89, alpha: 0.348).cgColor /* #D3D9E3 */
        self.rectangleCopy7FiveView.layer.shadowOffset = CGSize(width: 0, height: 0)
        self.rectangleCopy7FiveView.layer.shadowRadius = 7
        self.rectangleCopy7FiveView.layer.shadowOpacity = 1
        
        self.rectangleCopy7FiveView.layer.cornerRadius = 9
        self.rectangleCopy7FiveView.layer.masksToBounds = true
        
        // Setup ovalCopyFiveView
        self.ovalCopyFiveView.layer.cornerRadius = 13
        self.ovalCopyFiveView.layer.masksToBounds = true
        
        // Setup ovalCopy11View
        self.ovalCopy11View.layer.cornerRadius = 13
        self.ovalCopy11View.layer.masksToBounds = true
        
        // Setup ovalCopy10View
        self.ovalCopy10View.layer.cornerRadius = 13
        self.ovalCopy10View.layer.masksToBounds = true
        
        // Setup rectangleFiveView
        self.rectangleFiveView.layer.cornerRadius = 9
        self.rectangleFiveView.layer.masksToBounds = true
        
        // Setup ovalFiveView
        self.ovalFiveView.layer.cornerRadius = 13
        self.ovalFiveView.layer.masksToBounds = true
        
        // Setup burgerKingThreeLabel
        let burgerKingThreeLabelAttrString = NSMutableAttributedString(string: "Burger King", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.burgerKingThreeLabel.attributedText = burgerKingThreeLabelAttrString
        
        // Setup offFiveLabel
        let offFiveLabelAttrString = NSMutableAttributedString(string: "$40 Off", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 24)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 22, paragraphSpacing: 0)
        ])
        self.offFiveLabel.attributedText = offFiveLabelAttrString
        
        // Setup validUntil20May2FiveLabel
        let validUntil20May2FiveLabelAttrString = NSMutableAttributedString(string: "Valid until 20 May 2020", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.validUntil20May2FiveLabel.attributedText = validUntil20May2FiveLabelAttrString
        
        // Setup buttonFiveButton
        self.buttonFiveButton.layer.cornerRadius = 3
        self.buttonFiveButton.layer.masksToBounds = true
        self.buttonFiveButton.snImageTextSpacing = 10
        
        // Setup userNameView
        self.userNameView.layer.cornerRadius = 5
        self.userNameView.layer.masksToBounds = true
        
        // Setup rectangleCopy8Button
        self.rectangleCopy8Button.layer.shadowColor = UIColor(red: 0.827, green: 0.851, blue: 0.89, alpha: 0.25).cgColor /* #D3D9E3 */
        self.rectangleCopy8Button.layer.shadowOffset = CGSize(width: 0, height: 2)
        self.rectangleCopy8Button.layer.shadowRadius = 7
        self.rectangleCopy8Button.layer.shadowOpacity = 1
        
        self.rectangleCopy8Button.layer.cornerRadius = 5
        self.rectangleCopy8Button.layer.masksToBounds = true
        self.rectangleCopy8Button.snImageTextSpacing = 10
        
        // Setup currentLabel
        let currentLabelAttrString = NSMutableAttributedString(string: "Current", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.currentLabel.attributedText = currentLabelAttrString
        
        // Setup usedLabel
        let usedLabelAttrString = NSMutableAttributedString(string: "Used", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.usedLabel.attributedText = usedLabelAttrString
        
        // Setup backButton
        self.backButton.snImageTextSpacing = 10
        
    }

    private func setupUI()  {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    private func setupGestureRecognizers()  {
    
    }

    private func setupLocalization()  {
    
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Status Bar

    override public var prefersStatusBarHidden: Bool  {
        return false
    }

    override public var preferredStatusBarStyle: UIStatusBarStyle  {
        return .default
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Actions

    @IBAction public func onButtonPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push My Previous Order", sender: nil)
    }

    @IBAction public func onButtonTwoPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push My Previous Order Two", sender: nil)
    }

    @IBAction public func onButtonThreePressed(_ sender: UIButton)  {
    
    }

    @IBAction public func onButtonFourPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push My Previous Order Three", sender: nil)
    }

    @IBAction public func onButtonFivePressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push My Previous Order Four", sender: nil)
    }

    @IBAction public func onRectangleCopy8Pressed(_ sender: UIButton)  {
    
    }

    @IBAction public func onBackPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Delivery Address", sender: nil)
    }
}
