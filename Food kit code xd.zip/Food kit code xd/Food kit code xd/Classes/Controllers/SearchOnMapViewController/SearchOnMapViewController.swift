//
//  SearchOnMapViewController.swift
//  Food UI Kit
//
//  Created by [Author].
//  Copyright © 2018 [Company]. All rights reserved.
//

// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Import

import UIKit
import MapKit


// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Implementation

class SearchOnMapViewController: UIViewController {


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Properties

    @IBOutlet var restaurentNameView: UIView!
    @IBOutlet var italianoRestaurantLabel: SupernovaLabel!
    @IBOutlet var nayasharak14KmLabel: SupernovaLabel!
    @IBOutlet var restaurentNameTwoView: UIView!
    @IBOutlet var italianoRestaurantTwoLabel: SupernovaLabel!
    @IBOutlet var nayasharak14KmTwoLabel: SupernovaLabel!
    @IBOutlet var headerView: UIView!
    @IBOutlet var rectangleView: UIView!
    @IBOutlet var dinnerLabel: SupernovaLabel!
    @IBOutlet var breakfastLabel: SupernovaLabel!
    @IBOutlet var lunchLabel: SupernovaLabel!
    @IBOutlet var fastFoodButton: SupernovaButton!
    @IBOutlet var searchView: UIView!
    @IBOutlet var mapsAndFlagsMapView: MKMapView!
    @IBOutlet var filterView: UIView!
    @IBOutlet var seeOnMapButton: SupernovaButton!


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Lifecycle

    override public func viewDidLoad()  {
        super.viewDidLoad()
        self.setupComponents()
        self.setupUI()
        self.setupGestureRecognizers()
        self.setupLocalization()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override public func viewWillAppear(_ animated: Bool)  {
        super.viewWillAppear(animated)
        
        // Navigation bar, if any
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Setup

    private func setupComponents()  {
        // Setup restaurentNameView
        self.restaurentNameView.layer.shadowColor = UIColor(red: 0.663, green: 0.79, blue: 0.918, alpha: 0.2).cgColor /* #A9CAEA */
        self.restaurentNameView.layer.shadowOffset = CGSize(width: 0, height: 0)
        self.restaurentNameView.layer.shadowRadius = 14
        self.restaurentNameView.layer.shadowOpacity = 1
        
        self.restaurentNameView.layer.cornerRadius = 10
        self.restaurentNameView.layer.masksToBounds = true
        
        // Setup italianoRestaurantLabel
        let italianoRestaurantLabelAttrString = NSMutableAttributedString(string: "Italiano Restaurant", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 16)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 16, paragraphSpacing: 0)
        ])
        self.italianoRestaurantLabel.attributedText = italianoRestaurantLabelAttrString
        
        // Setup nayasharak14KmLabel
        let nayasharak14KmLabelAttrString = NSMutableAttributedString(string: "Nayasharak - 14 KM", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.nayasharak14KmLabel.attributedText = nayasharak14KmLabelAttrString
        
        // Setup restaurentNameTwoView
        self.restaurentNameTwoView.layer.shadowColor = UIColor(red: 0.663, green: 0.79, blue: 0.918, alpha: 0.2).cgColor /* #A9CAEA */
        self.restaurentNameTwoView.layer.shadowOffset = CGSize(width: 0, height: 0)
        self.restaurentNameTwoView.layer.shadowRadius = 14
        self.restaurentNameTwoView.layer.shadowOpacity = 1
        
        self.restaurentNameTwoView.layer.cornerRadius = 10
        self.restaurentNameTwoView.layer.masksToBounds = true
        
        // Setup italianoRestaurantTwoLabel
        let italianoRestaurantTwoLabelAttrString = NSMutableAttributedString(string: "Italiano Restaurant", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 16)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 16, paragraphSpacing: 0)
        ])
        self.italianoRestaurantTwoLabel.attributedText = italianoRestaurantTwoLabelAttrString
        
        // Setup nayasharak14KmTwoLabel
        let nayasharak14KmTwoLabelAttrString = NSMutableAttributedString(string: "Nayasharak - 14 KM", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.nayasharak14KmTwoLabel.attributedText = nayasharak14KmTwoLabelAttrString
        
        // Setup headerView
        self.headerView.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.05).cgColor /* #000000 */
        self.headerView.layer.shadowOffset = CGSize(width: 0, height: -1)
        self.headerView.layer.shadowRadius = 3
        self.headerView.layer.shadowOpacity = 1
        
        
        // Setup rectangleView
        self.rectangleView.layer.cornerRadius = 1.5
        self.rectangleView.layer.masksToBounds = true
        
        // Setup dinnerLabel
        let dinnerLabelAttrString = NSMutableAttributedString(string: "Dinner", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.dinnerLabel.attributedText = dinnerLabelAttrString
        
        // Setup breakfastLabel
        let breakfastLabelAttrString = NSMutableAttributedString(string: "Breakfast", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.breakfastLabel.attributedText = breakfastLabelAttrString
        
        // Setup lunchLabel
        let lunchLabelAttrString = NSMutableAttributedString(string: "Lunch", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.lunchLabel.attributedText = lunchLabelAttrString
        
        // Setup fastFoodButton
        self.fastFoodButton.snImageTextSpacing = 10
        
        // Setup searchView
        self.searchView.layer.cornerRadius = 7
        self.searchView.layer.masksToBounds = true
        
        // Setup mapsAndFlagsMapView
        self.mapsAndFlagsMapView.camera = MKMapCamera(lookingAtCenter: CLLocationCoordinate2D(latitude: 0, longitude: 0), fromDistance: 10000, pitch: 0, heading: 0)
        
        // Setup filterView
        self.filterView.layer.cornerRadius = 7
        self.filterView.layer.masksToBounds = true
        
        // Setup seeOnMapButton
        self.seeOnMapButton.snImageTextSpacing = 10
        
    }

    private func setupUI()  {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    private func setupGestureRecognizers()  {
    
    }

    private func setupLocalization()  {
    
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Status Bar

    override public var prefersStatusBarHidden: Bool  {
        return false
    }

    override public var preferredStatusBarStyle: UIStatusBarStyle  {
        return .default
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Actions

    @IBAction public func onFastFoodPressed(_ sender: UIButton)  {
    
    }

    @IBAction public func onSeeOnMapPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Order Done", sender: nil)
    }
}


// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Extension SearchOnMapViewController

extension SearchOnMapViewController: MKMapViewDelegate  {


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Methods
    public func mapViewWillStartLoadingMap(_ mapView: MKMapView)  {
    
    }

    public func mapViewDidFinishLoadingMap(_ mapView: MKMapView)  {
    
    }

    public func mapViewDidFailLoadingMap(_ mapView: MKMapView, withError error: Error)  {
    
    }

    public func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView)  {
    
    }
}
