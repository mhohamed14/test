//
//  OrderFailViewController.swift
//  Food UI Kit
//
//  Created by [Author].
//  Copyright © 2018 [Company]. All rights reserved.
//

// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Import

import UIKit


// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Implementation

class OrderFailViewController: UIViewController {


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Properties

    @IBOutlet var backButton: SupernovaButton!
    @IBOutlet var group6View: UIView!
    @IBOutlet var rectangleCopy7View: UIView!
    @IBOutlet var eastCustomChLabel: SupernovaLabel!
    @IBOutlet var homeLabel: SupernovaLabel!
    @IBOutlet var visaView: UIView!
    @IBOutlet var rectangleCopy7TwoView: UIView!
    @IBOutlet var labelLabel: SupernovaLabel!
    @IBOutlet var visaCardLabel: SupernovaLabel!
    @IBOutlet var paypalView: UIView!
    @IBOutlet var rectangleCopy7ThreeView: UIView!
    @IBOutlet var shakib402PaypalLabel: SupernovaLabel!
    @IBOutlet var paypalLabel: SupernovaLabel!
    @IBOutlet var appleView: UIView!
    @IBOutlet var rectangleCopy7FourView: UIView!
    @IBOutlet var shakib402ApplePayLabel: SupernovaLabel!
    @IBOutlet var applePayLabel: SupernovaLabel!
    @IBOutlet var codView: UIView!
    @IBOutlet var rectangleCopy7FiveView: UIView!
    @IBOutlet var payAfterReciveDelLabel: SupernovaLabel!
    @IBOutlet var cashOnDeliveryLabel: SupernovaLabel!
    @IBOutlet var buttonView: UIView!
    @IBOutlet var payNowLabel: SupernovaLabel!
    @IBOutlet var rectangleCopy8View: UIView!
    @IBOutlet var buttonButton: SupernovaButton!
    @IBOutlet var sorryYourOrderHaLabel: UILabel!
    @IBOutlet var sorrySomethingsWeLabel: UILabel!


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Lifecycle

    override public func viewDidLoad()  {
        super.viewDidLoad()
        self.setupComponents()
        self.setupUI()
        self.setupGestureRecognizers()
        self.setupLocalization()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override public func viewWillAppear(_ animated: Bool)  {
        super.viewWillAppear(animated)
        
        // Navigation bar, if any
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Setup

    private func setupComponents()  {
        // Setup backButton
        self.backButton.snImageTextSpacing = 10
        
        // Setup group6View
        self.group6View.layer.shadowColor = UIColor(red: 0.827, green: 0.851, blue: 0.89, alpha: 0.149).cgColor /* #D3D9E3 */
        self.group6View.layer.shadowOffset = CGSize(width: 0, height: 2)
        self.group6View.layer.shadowRadius = 7
        self.group6View.layer.shadowOpacity = 1
        
        self.group6View.layer.cornerRadius = 12
        self.group6View.layer.masksToBounds = true
        
        // Setup rectangleCopy7View
        self.rectangleCopy7View.layer.borderColor = UIColor(red: 1, green: 0.824, blue: 0.306, alpha: 1).cgColor /* #FFD24E */
        self.rectangleCopy7View.layer.borderWidth = 1
        
        self.rectangleCopy7View.layer.cornerRadius = 7
        self.rectangleCopy7View.layer.masksToBounds = true
        
        // Setup eastCustomChLabel
        let eastCustomChLabelAttrString = NSMutableAttributedString(string: "216/ East Custom, Chhatak", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.eastCustomChLabel.attributedText = eastCustomChLabelAttrString
        
        // Setup homeLabel
        let homeLabelAttrString = NSMutableAttributedString(string: "Home", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.homeLabel.attributedText = homeLabelAttrString
        
        // Setup visaView
        self.visaView.layer.borderColor = UIColor(red: 0.953, green: 0.953, blue: 0.953, alpha: 1).cgColor /* #F3F3F3 */
        self.visaView.layer.borderWidth = 1
        
        self.visaView.layer.cornerRadius = 7
        self.visaView.layer.masksToBounds = true
        
        // Setup rectangleCopy7TwoView
        self.rectangleCopy7TwoView.layer.cornerRadius = 7
        self.rectangleCopy7TwoView.layer.masksToBounds = true
        
        // Setup labelLabel
        let labelLabelAttrString = NSMutableAttributedString(string: "**** **** **** 5162", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.labelLabel.attributedText = labelLabelAttrString
        
        // Setup visaCardLabel
        let visaCardLabelAttrString = NSMutableAttributedString(string: "Visa Card", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.visaCardLabel.attributedText = visaCardLabelAttrString
        
        // Setup paypalView
        self.paypalView.layer.borderColor = UIColor(red: 0.953, green: 0.953, blue: 0.953, alpha: 1).cgColor /* #F3F3F3 */
        self.paypalView.layer.borderWidth = 1
        
        self.paypalView.layer.cornerRadius = 7
        self.paypalView.layer.masksToBounds = true
        
        // Setup rectangleCopy7ThreeView
        self.rectangleCopy7ThreeView.layer.cornerRadius = 7
        self.rectangleCopy7ThreeView.layer.masksToBounds = true
        
        // Setup shakib402PaypalLabel
        let shakib402PaypalLabelAttrString = NSMutableAttributedString(string: "shakib402@paypal", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.shakib402PaypalLabel.attributedText = shakib402PaypalLabelAttrString
        
        // Setup paypalLabel
        let paypalLabelAttrString = NSMutableAttributedString(string: "Paypal", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.paypalLabel.attributedText = paypalLabelAttrString
        
        // Setup appleView
        self.appleView.layer.borderColor = UIColor(red: 0.953, green: 0.953, blue: 0.953, alpha: 1).cgColor /* #F3F3F3 */
        self.appleView.layer.borderWidth = 1
        
        self.appleView.layer.cornerRadius = 7
        self.appleView.layer.masksToBounds = true
        
        // Setup rectangleCopy7FourView
        self.rectangleCopy7FourView.layer.cornerRadius = 7
        self.rectangleCopy7FourView.layer.masksToBounds = true
        
        // Setup shakib402ApplePayLabel
        let shakib402ApplePayLabelAttrString = NSMutableAttributedString(string: "shakib402@apple.pay", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.shakib402ApplePayLabel.attributedText = shakib402ApplePayLabelAttrString
        
        // Setup applePayLabel
        let applePayLabelAttrString = NSMutableAttributedString(string: "Apple Pay", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.applePayLabel.attributedText = applePayLabelAttrString
        
        // Setup codView
        self.codView.layer.borderColor = UIColor(red: 1, green: 0.824, blue: 0.306, alpha: 1).cgColor /* #FFD24E */
        self.codView.layer.borderWidth = 1
        
        self.codView.layer.cornerRadius = 7
        self.codView.layer.masksToBounds = true
        
        // Setup rectangleCopy7FiveView
        self.rectangleCopy7FiveView.layer.cornerRadius = 7
        self.rectangleCopy7FiveView.layer.masksToBounds = true
        
        // Setup payAfterReciveDelLabel
        let payAfterReciveDelLabelAttrString = NSMutableAttributedString(string: "Pay after recive delivery", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.payAfterReciveDelLabel.attributedText = payAfterReciveDelLabelAttrString
        
        // Setup cashOnDeliveryLabel
        let cashOnDeliveryLabelAttrString = NSMutableAttributedString(string: "Cash On Delivery", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.cashOnDeliveryLabel.attributedText = cashOnDeliveryLabelAttrString
        
        // Setup buttonView
        self.buttonView.layer.cornerRadius = 9
        self.buttonView.layer.masksToBounds = true
        
        // Setup payNowLabel
        let payNowLabelAttrString = NSMutableAttributedString(string: "Pay Now", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.payNowLabel.attributedText = payNowLabelAttrString
        
        // Setup rectangleCopy8View
        self.rectangleCopy8View.layer.shadowColor = UIColor(red: 0.827, green: 0.851, blue: 0.89, alpha: 0.149).cgColor /* #D3D9E3 */
        self.rectangleCopy8View.layer.shadowOffset = CGSize(width: 0, height: 2)
        self.rectangleCopy8View.layer.shadowRadius = 7
        self.rectangleCopy8View.layer.shadowOpacity = 1
        
        self.rectangleCopy8View.layer.cornerRadius = 30
        self.rectangleCopy8View.layer.masksToBounds = true
        
        // Setup buttonButton
        self.buttonButton.layer.cornerRadius = 4
        self.buttonButton.layer.masksToBounds = true
        self.buttonButton.snImageTextSpacing = 10
        
        // Setup sorryYourOrderHaLabel
        let sorryYourOrderHaLabelAttrString = NSMutableAttributedString(string: "Sorry, Your Order has Failed", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 24)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 34, paragraphSpacing: 0)
        ])
        self.sorryYourOrderHaLabel.attributedText = sorryYourOrderHaLabelAttrString
        
        // Setup sorrySomethingsWeLabel
        let sorrySomethingsWeLabelAttrString = NSMutableAttributedString(string: "Sorry, somethings went wrong. \nPlease try again to continue your order.  ", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 21, paragraphSpacing: 0)
        ])
        self.sorrySomethingsWeLabel.attributedText = sorrySomethingsWeLabelAttrString
        
    }

    private func setupUI()  {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    private func setupGestureRecognizers()  {
    
    }

    private func setupLocalization()  {
    
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Status Bar

    override public var prefersStatusBarHidden: Bool  {
        return false
    }

    override public var preferredStatusBarStyle: UIStatusBarStyle  {
        return .default
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Actions

    @IBAction public func onBackPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Empty Cart", sender: nil)
    }

    @IBAction public func onButtonPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Order Done", sender: nil)
    }
}
