//
//  CartDeleteViewController.swift
//  Food UI Kit
//
//  Created by [Author].
//  Copyright © 2018 [Company]. All rights reserved.
//

// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Import

import UIKit


// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Implementation

class CartDeleteViewController: UIViewController {


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Properties

    @IBOutlet var rectangleCopy5View: UIView!
    @IBOutlet var rectangleCopy4View: UIView!
    @IBOutlet var group3Button: SupernovaButton!
    @IBOutlet var group3CopyButton: SupernovaButton!
    @IBOutlet var labelLabel: SupernovaLabel!
    @IBOutlet var labelTwoLabel: SupernovaLabel!
    @IBOutlet var rectangleCopy6View: UIView!
    @IBOutlet var rectangleCopy4TwoView: UIView!
    @IBOutlet var group3View: UIView!
    @IBOutlet var group8Button: SupernovaButton!
    @IBOutlet var group3CopyView: UIView!
    @IBOutlet var group8TwoButton: SupernovaButton!
    @IBOutlet var labelThreeLabel: SupernovaLabel!
    @IBOutlet var labelFourLabel: SupernovaLabel!
    @IBOutlet var rectangleCopy7View: UIView!
    @IBOutlet var rectangleCopy4ThreeView: UIView!
    @IBOutlet var group3TwoView: UIView!
    @IBOutlet var group8ThreeButton: SupernovaButton!
    @IBOutlet var group3CopyTwoView: UIView!
    @IBOutlet var group8FourButton: SupernovaButton!
    @IBOutlet var labelFiveLabel: SupernovaLabel!
    @IBOutlet var labelSixLabel: SupernovaLabel!
    @IBOutlet var deleteButton: SupernovaButton!
    @IBOutlet var rectangleCopy4FourView: UIView!
    @IBOutlet var group3ThreeView: UIView!
    @IBOutlet var group3CopyThreeView: UIView!
    @IBOutlet var labelSevenLabel: SupernovaLabel!
    @IBOutlet var labelEightLabel: SupernovaLabel!
    @IBOutlet var promoCodeView: UIView!
    @IBOutlet var enterPromoView: UIView!
    @IBOutlet var enterPromoCodeLabel: SupernovaLabel!
    @IBOutlet var buttonButton: SupernovaButton!
    @IBOutlet var subtotalLabel: SupernovaLabel!
    @IBOutlet var deliveryLabel: SupernovaLabel!
    @IBOutlet var labelNineLabel: SupernovaLabel!
    @IBOutlet var labelTenLabel: SupernovaLabel!
    @IBOutlet var discountLabel: SupernovaLabel!
    @IBOutlet var labelElevenLabel: SupernovaLabel!
    @IBOutlet var selectAllLabel: SupernovaLabel!
    @IBOutlet var rectangleView: UIView!
    @IBOutlet var buttonView: UIView!
    @IBOutlet var groupButton: SupernovaButton!
    @IBOutlet var groupCopyView: UIView!
    @IBOutlet var totalLabel: SupernovaLabel!
    @IBOutlet var labelTwelveLabel: SupernovaLabel!


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Lifecycle

    override public func viewDidLoad()  {
        super.viewDidLoad()
        self.setupComponents()
        self.setupUI()
        self.setupGestureRecognizers()
        self.setupLocalization()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override public func viewWillAppear(_ animated: Bool)  {
        super.viewWillAppear(animated)
        
        // Navigation bar, if any
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Setup

    private func setupComponents()  {
        // Setup rectangleCopy5View
        self.rectangleCopy5View.layer.cornerRadius = 0.5
        self.rectangleCopy5View.layer.masksToBounds = true
        
        // Setup rectangleCopy4View
        self.rectangleCopy4View.layer.cornerRadius = 22
        self.rectangleCopy4View.layer.masksToBounds = true
        
        // Setup group3Button
        self.group3Button.layer.borderColor = UIColor(red: 0.952, green: 0.952, blue: 0.952, alpha: 1).cgColor /* #F3F3F3 */
        self.group3Button.layer.borderWidth = 1
        
        self.group3Button.layer.cornerRadius = 10
        self.group3Button.layer.masksToBounds = true
        self.group3Button.snImageTextSpacing = 10
        
        // Setup group3CopyButton
        self.group3CopyButton.layer.borderColor = UIColor(red: 0.952, green: 0.952, blue: 0.952, alpha: 1).cgColor /* #F3F3F3 */
        self.group3CopyButton.layer.borderWidth = 1
        
        self.group3CopyButton.layer.cornerRadius = 10
        self.group3CopyButton.layer.masksToBounds = true
        self.group3CopyButton.snImageTextSpacing = 10
        
        // Setup labelLabel
        let labelLabelAttrString = NSMutableAttributedString(string: "2", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 16)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 16, paragraphSpacing: 0)
        ])
        self.labelLabel.attributedText = labelLabelAttrString
        
        // Setup labelTwoLabel
        let labelTwoLabelAttrString = NSMutableAttributedString(string: "$25.30", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 18)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 16, paragraphSpacing: 0)
        ])
        self.labelTwoLabel.attributedText = labelTwoLabelAttrString
        
        // Setup rectangleCopy6View
        self.rectangleCopy6View.layer.cornerRadius = 0.5
        self.rectangleCopy6View.layer.masksToBounds = true
        
        // Setup rectangleCopy4TwoView
        self.rectangleCopy4TwoView.layer.cornerRadius = 22
        self.rectangleCopy4TwoView.layer.masksToBounds = true
        
        // Setup group3View
        self.group3View.layer.borderColor = UIColor(red: 0.952, green: 0.952, blue: 0.952, alpha: 1).cgColor /* #F3F3F3 */
        self.group3View.layer.borderWidth = 1
        
        self.group3View.layer.cornerRadius = 10
        self.group3View.layer.masksToBounds = true
        
        // Setup group8Button
        self.group8Button.snImageTextSpacing = 10
        
        // Setup group3CopyView
        self.group3CopyView.layer.borderColor = UIColor(red: 0.952, green: 0.952, blue: 0.952, alpha: 1).cgColor /* #F3F3F3 */
        self.group3CopyView.layer.borderWidth = 1
        
        self.group3CopyView.layer.cornerRadius = 10
        self.group3CopyView.layer.masksToBounds = true
        
        // Setup group8TwoButton
        self.group8TwoButton.snImageTextSpacing = 10
        
        // Setup labelThreeLabel
        let labelThreeLabelAttrString = NSMutableAttributedString(string: "2", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 16)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 16, paragraphSpacing: 0)
        ])
        self.labelThreeLabel.attributedText = labelThreeLabelAttrString
        
        // Setup labelFourLabel
        let labelFourLabelAttrString = NSMutableAttributedString(string: "$25.30", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 18)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 16, paragraphSpacing: 0)
        ])
        self.labelFourLabel.attributedText = labelFourLabelAttrString
        
        // Setup rectangleCopy7View
        self.rectangleCopy7View.layer.cornerRadius = 0.5
        self.rectangleCopy7View.layer.masksToBounds = true
        
        // Setup rectangleCopy4ThreeView
        self.rectangleCopy4ThreeView.layer.cornerRadius = 22
        self.rectangleCopy4ThreeView.layer.masksToBounds = true
        
        // Setup group3TwoView
        self.group3TwoView.layer.borderColor = UIColor(red: 0.952, green: 0.952, blue: 0.952, alpha: 1).cgColor /* #F3F3F3 */
        self.group3TwoView.layer.borderWidth = 1
        
        self.group3TwoView.layer.cornerRadius = 10
        self.group3TwoView.layer.masksToBounds = true
        
        // Setup group8ThreeButton
        self.group8ThreeButton.snImageTextSpacing = 10
        
        // Setup group3CopyTwoView
        self.group3CopyTwoView.layer.borderColor = UIColor(red: 0.952, green: 0.952, blue: 0.952, alpha: 1).cgColor /* #F3F3F3 */
        self.group3CopyTwoView.layer.borderWidth = 1
        
        self.group3CopyTwoView.layer.cornerRadius = 10
        self.group3CopyTwoView.layer.masksToBounds = true
        
        // Setup group8FourButton
        self.group8FourButton.snImageTextSpacing = 10
        
        // Setup labelFiveLabel
        let labelFiveLabelAttrString = NSMutableAttributedString(string: "2", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 16)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 16, paragraphSpacing: 0)
        ])
        self.labelFiveLabel.attributedText = labelFiveLabelAttrString
        
        // Setup labelSixLabel
        let labelSixLabelAttrString = NSMutableAttributedString(string: "$55.35", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 18)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 16, paragraphSpacing: 0)
        ])
        self.labelSixLabel.attributedText = labelSixLabelAttrString
        
        // Setup deleteButton
        self.deleteButton.layer.cornerRadius = 11
        self.deleteButton.layer.masksToBounds = true
        self.deleteButton.snImageTextSpacing = 10
        
        // Setup rectangleCopy4FourView
        self.rectangleCopy4FourView.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.05).cgColor /* #000000 */
        self.rectangleCopy4FourView.layer.shadowOffset = CGSize(width: 0, height: -1)
        self.rectangleCopy4FourView.layer.shadowRadius = 3
        self.rectangleCopy4FourView.layer.shadowOpacity = 1
        
        self.rectangleCopy4FourView.layer.cornerRadius = 22
        self.rectangleCopy4FourView.layer.masksToBounds = true
        
        // Setup group3ThreeView
        self.group3ThreeView.layer.borderColor = UIColor(red: 0.952, green: 0.952, blue: 0.952, alpha: 1).cgColor /* #F3F3F3 */
        self.group3ThreeView.layer.borderWidth = 1
        
        self.group3ThreeView.layer.cornerRadius = 10
        self.group3ThreeView.layer.masksToBounds = true
        
        // Setup group3CopyThreeView
        self.group3CopyThreeView.layer.borderColor = UIColor(red: 0.952, green: 0.952, blue: 0.952, alpha: 1).cgColor /* #F3F3F3 */
        self.group3CopyThreeView.layer.borderWidth = 1
        
        self.group3CopyThreeView.layer.cornerRadius = 10
        self.group3CopyThreeView.layer.masksToBounds = true
        
        // Setup labelSevenLabel
        let labelSevenLabelAttrString = NSMutableAttributedString(string: "2", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 16)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 16, paragraphSpacing: 0)
        ])
        self.labelSevenLabel.attributedText = labelSevenLabelAttrString
        
        // Setup labelEightLabel
        let labelEightLabelAttrString = NSMutableAttributedString(string: "$20.60", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 18)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 16, paragraphSpacing: 0)
        ])
        self.labelEightLabel.attributedText = labelEightLabelAttrString
        
        // Setup promoCodeView
        self.promoCodeView.layer.cornerRadius = 20
        self.promoCodeView.layer.masksToBounds = true
        
        // Setup enterPromoView
        self.enterPromoView.layer.cornerRadius = 6
        self.enterPromoView.layer.masksToBounds = true
        
        // Setup enterPromoCodeLabel
        let enterPromoCodeLabelAttrString = NSMutableAttributedString(string: "Enter Promo Code", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.enterPromoCodeLabel.attributedText = enterPromoCodeLabelAttrString
        
        // Setup buttonButton
        self.buttonButton.layer.cornerRadius = 4
        self.buttonButton.layer.masksToBounds = true
        self.buttonButton.snImageTextSpacing = 10
        
        // Setup subtotalLabel
        let subtotalLabelAttrString = NSMutableAttributedString(string: "Subtotal :", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.subtotalLabel.attributedText = subtotalLabelAttrString
        
        // Setup deliveryLabel
        let deliveryLabelAttrString = NSMutableAttributedString(string: "Delivery :", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.deliveryLabel.attributedText = deliveryLabelAttrString
        
        // Setup labelNineLabel
        let labelNineLabelAttrString = NSMutableAttributedString(string: "$306.35", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.labelNineLabel.attributedText = labelNineLabelAttrString
        
        // Setup labelTenLabel
        let labelTenLabelAttrString = NSMutableAttributedString(string: "$10.00", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.labelTenLabel.attributedText = labelTenLabelAttrString
        
        // Setup discountLabel
        let discountLabelAttrString = NSMutableAttributedString(string: "Discount :", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.discountLabel.attributedText = discountLabelAttrString
        
        // Setup labelElevenLabel
        let labelElevenLabelAttrString = NSMutableAttributedString(string: "$12.00", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.labelElevenLabel.attributedText = labelElevenLabelAttrString
        
        // Setup selectAllLabel
        let selectAllLabelAttrString = NSMutableAttributedString(string: "Select all", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.selectAllLabel.attributedText = selectAllLabelAttrString
        
        // Setup rectangleView
        self.rectangleView.layer.borderColor = UIColor(red: 1, green: 0.824, blue: 0.306, alpha: 1).cgColor /* #FFD24E */
        self.rectangleView.layer.borderWidth = 1.5
        
        self.rectangleView.layer.cornerRadius = 8
        self.rectangleView.layer.masksToBounds = true
        
        // Setup buttonView
        self.buttonView.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.05).cgColor /* #000000 */
        self.buttonView.layer.shadowOffset = CGSize(width: 0, height: -1)
        self.buttonView.layer.shadowRadius = 3
        self.buttonView.layer.shadowOpacity = 1
        
        self.buttonView.layer.cornerRadius = 12
        self.buttonView.layer.masksToBounds = true
        
        // Setup groupButton
        self.groupButton.layer.cornerRadius = 4
        self.groupButton.layer.masksToBounds = true
        self.groupButton.snImageTextSpacing = 10
        
        // Setup groupCopyView
        self.groupCopyView.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.02).cgColor /* #000000 */
        self.groupCopyView.layer.shadowOffset = CGSize(width: 0, height: 2)
        self.groupCopyView.layer.shadowRadius = 8
        self.groupCopyView.layer.shadowOpacity = 1
        
        self.groupCopyView.layer.cornerRadius = 4
        self.groupCopyView.layer.masksToBounds = true
        
        // Setup totalLabel
        let totalLabelAttrString = NSMutableAttributedString(string: "Total", attributes: [
            .font : UIFont(name: "Avenir-Book", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 12, paragraphSpacing: 0)
        ])
        self.totalLabel.attributedText = totalLabelAttrString
        
        // Setup labelTwelveLabel
        let labelTwelveLabelAttrString = NSMutableAttributedString(string: "$306.35", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.labelTwelveLabel.attributedText = labelTwelveLabelAttrString
        
    }

    private func setupUI()  {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    private func setupGestureRecognizers()  {
    
    }

    private func setupLocalization()  {
    
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Status Bar

    override public var prefersStatusBarHidden: Bool  {
        return false
    }

    override public var preferredStatusBarStyle: UIStatusBarStyle  {
        return .default
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Actions

    @IBAction public func onGroup3Pressed(_ sender: UIButton)  {
    
    }

    @IBAction public func onGroup3CopyPressed(_ sender: UIButton)  {
    
    }

    @IBAction public func onGroup8Pressed(_ sender: UIButton)  {
    
    }

    @IBAction public func onGroup8TwoPressed(_ sender: UIButton)  {
    
    }

    @IBAction public func onGroup8ThreePressed(_ sender: UIButton)  {
    
    }

    @IBAction public func onGroup8FourPressed(_ sender: UIButton)  {
    
    }

    @IBAction public func onDeletePressed(_ sender: UIButton)  {
    
    }

    @IBAction public func onButtonPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Burger Order App Cart", sender: nil)
    }

    @IBAction public func onGroupPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Burger Order App Cart Two", sender: nil)
    }
}
