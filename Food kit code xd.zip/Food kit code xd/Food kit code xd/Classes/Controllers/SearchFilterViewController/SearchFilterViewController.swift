//
//  SearchFilterViewController.swift
//  Food UI Kit
//
//  Created by [Author].
//  Copyright © 2018 [Company]. All rights reserved.
//

// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Import

import UIKit


// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Implementation

class SearchFilterViewController: UIViewController {


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Properties

    @IBOutlet var backButton: SupernovaButton!
    @IBOutlet var priceLabel: SupernovaLabel!
    @IBOutlet var rectangleView: UIView!
    @IBOutlet var rectangleTwoView: UIView!
    @IBOutlet var labelLabel: SupernovaLabel!
    @IBOutlet var ovalView: UIView!
    @IBOutlet var labelTwoLabel: SupernovaLabel!
    @IBOutlet var ovalCopyView: UIView!
    @IBOutlet var ratingStarLabel: SupernovaLabel!
    @IBOutlet var topRatedLabel: SupernovaLabel!
    @IBOutlet var priceHighToLowLabel: SupernovaLabel!
    @IBOutlet var priceLowToHighLabel: SupernovaLabel!
    @IBOutlet var sortByLabel: SupernovaLabel!
    @IBOutlet var groupView: UIView!
    @IBOutlet var minLabel: SupernovaLabel!
    @IBOutlet var groupCopyView: UIView!
    @IBOutlet var minTwoLabel: SupernovaLabel!
    @IBOutlet var groupCopy2View: UIView!
    @IBOutlet var minThreeLabel: SupernovaLabel!
    @IBOutlet var deliveryTimeLabel: SupernovaLabel!
    @IBOutlet var distanceLabel: SupernovaLabel!
    @IBOutlet var rectangleThreeView: UIView!
    @IBOutlet var rectangleFourView: UIView!
    @IBOutlet var kmLabel: SupernovaLabel!
    @IBOutlet var ovalTwoView: UIView!
    @IBOutlet var kmTwoLabel: SupernovaLabel!
    @IBOutlet var ovalCopyTwoView: UIView!
    @IBOutlet var buttonButton: SupernovaButton!
    @IBOutlet var clearFilterLabel: SupernovaLabel!


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Lifecycle

    override public func viewDidLoad()  {
        super.viewDidLoad()
        self.setupComponents()
        self.setupUI()
        self.setupGestureRecognizers()
        self.setupLocalization()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override public func viewWillAppear(_ animated: Bool)  {
        super.viewWillAppear(animated)
        
        // Navigation bar, if any
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Setup

    private func setupComponents()  {
        // Setup backButton
        self.backButton.snImageTextSpacing = 10
        
        // Setup priceLabel
        let priceLabelAttrString = NSMutableAttributedString(string: "Price", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 16)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 16, paragraphSpacing: 0)
        ])
        self.priceLabel.attributedText = priceLabelAttrString
        
        // Setup rectangleView
        self.rectangleView.layer.cornerRadius = 4.5
        self.rectangleView.layer.masksToBounds = true
        
        // Setup rectangleTwoView
        self.rectangleTwoView.layer.cornerRadius = 4.5
        self.rectangleTwoView.layer.masksToBounds = true
        
        // Setup labelLabel
        let labelLabelAttrString = NSMutableAttributedString(string: "$10", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.labelLabel.attributedText = labelLabelAttrString
        
        // Setup ovalView
        self.ovalView.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.096).cgColor /* #000000 */
        self.ovalView.layer.shadowOffset = CGSize(width: 0, height: 1)
        self.ovalView.layer.shadowRadius = 3
        self.ovalView.layer.shadowOpacity = 1
        
        self.ovalView.layer.borderColor = UIColor(red: 1, green: 1, blue: 1, alpha: 1).cgColor /* #FFFFFF */
        self.ovalView.layer.borderWidth = 2
        
        self.ovalView.layer.cornerRadius = 7.5
        self.ovalView.layer.masksToBounds = true
        
        // Setup labelTwoLabel
        let labelTwoLabelAttrString = NSMutableAttributedString(string: "$50", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.labelTwoLabel.attributedText = labelTwoLabelAttrString
        
        // Setup ovalCopyView
        self.ovalCopyView.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.096).cgColor /* #000000 */
        self.ovalCopyView.layer.shadowOffset = CGSize(width: 0, height: 1)
        self.ovalCopyView.layer.shadowRadius = 3
        self.ovalCopyView.layer.shadowOpacity = 1
        
        self.ovalCopyView.layer.borderColor = UIColor(red: 1, green: 1, blue: 1, alpha: 1).cgColor /* #FFFFFF */
        self.ovalCopyView.layer.borderWidth = 2
        
        self.ovalCopyView.layer.cornerRadius = 7.5
        self.ovalCopyView.layer.masksToBounds = true
        
        // Setup ratingStarLabel
        let ratingStarLabelAttrString = NSMutableAttributedString(string: "Rating Star", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 16)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 16, paragraphSpacing: 0)
        ])
        self.ratingStarLabel.attributedText = ratingStarLabelAttrString
        
        // Setup topRatedLabel
        let topRatedLabelAttrString = NSMutableAttributedString(string: "Top Rated", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 14)!,
            .foregroundColor : UIColor(red: 1, green: 0.82, blue: 0.31, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.topRatedLabel.attributedText = topRatedLabelAttrString
        
        // Setup priceHighToLowLabel
        let priceHighToLowLabelAttrString = NSMutableAttributedString(string: "Price High to Low", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.priceHighToLowLabel.attributedText = priceHighToLowLabelAttrString
        
        // Setup priceLowToHighLabel
        let priceLowToHighLabelAttrString = NSMutableAttributedString(string: "Price Low to High", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.priceLowToHighLabel.attributedText = priceLowToHighLabelAttrString
        
        // Setup sortByLabel
        let sortByLabelAttrString = NSMutableAttributedString(string: "Sort By", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 16)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 16, paragraphSpacing: 0)
        ])
        self.sortByLabel.attributedText = sortByLabelAttrString
        
        // Setup groupView
        self.groupView.layer.cornerRadius = 17
        self.groupView.layer.masksToBounds = true
        
        // Setup minLabel
        let minLabelAttrString = NSMutableAttributedString(string: "20 Min", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.minLabel.attributedText = minLabelAttrString
        
        // Setup groupCopyView
        self.groupCopyView.layer.cornerRadius = 17
        self.groupCopyView.layer.masksToBounds = true
        
        // Setup minTwoLabel
        let minTwoLabelAttrString = NSMutableAttributedString(string: "30 Min", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.minTwoLabel.attributedText = minTwoLabelAttrString
        
        // Setup groupCopy2View
        self.groupCopy2View.layer.cornerRadius = 17
        self.groupCopy2View.layer.masksToBounds = true
        
        // Setup minThreeLabel
        let minThreeLabelAttrString = NSMutableAttributedString(string: "40 Min", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.minThreeLabel.attributedText = minThreeLabelAttrString
        
        // Setup deliveryTimeLabel
        let deliveryTimeLabelAttrString = NSMutableAttributedString(string: "Delivery Time", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 16)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 16, paragraphSpacing: 0)
        ])
        self.deliveryTimeLabel.attributedText = deliveryTimeLabelAttrString
        
        // Setup distanceLabel
        let distanceLabelAttrString = NSMutableAttributedString(string: "Distance", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 16)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 16, paragraphSpacing: 0)
        ])
        self.distanceLabel.attributedText = distanceLabelAttrString
        
        // Setup rectangleThreeView
        self.rectangleThreeView.layer.cornerRadius = 4.5
        self.rectangleThreeView.layer.masksToBounds = true
        
        // Setup rectangleFourView
        self.rectangleFourView.layer.cornerRadius = 4.5
        self.rectangleFourView.layer.masksToBounds = true
        
        // Setup kmLabel
        let kmLabelAttrString = NSMutableAttributedString(string: "0 km", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.kmLabel.attributedText = kmLabelAttrString
        
        // Setup ovalTwoView
        self.ovalTwoView.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.096).cgColor /* #000000 */
        self.ovalTwoView.layer.shadowOffset = CGSize(width: 0, height: 1)
        self.ovalTwoView.layer.shadowRadius = 3
        self.ovalTwoView.layer.shadowOpacity = 1
        
        self.ovalTwoView.layer.borderColor = UIColor(red: 1, green: 1, blue: 1, alpha: 1).cgColor /* #FFFFFF */
        self.ovalTwoView.layer.borderWidth = 2
        
        self.ovalTwoView.layer.cornerRadius = 7.5
        self.ovalTwoView.layer.masksToBounds = true
        
        // Setup kmTwoLabel
        let kmTwoLabelAttrString = NSMutableAttributedString(string: "10 km", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.kmTwoLabel.attributedText = kmTwoLabelAttrString
        
        // Setup ovalCopyTwoView
        self.ovalCopyTwoView.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.096).cgColor /* #000000 */
        self.ovalCopyTwoView.layer.shadowOffset = CGSize(width: 0, height: 1)
        self.ovalCopyTwoView.layer.shadowRadius = 3
        self.ovalCopyTwoView.layer.shadowOpacity = 1
        
        self.ovalCopyTwoView.layer.borderColor = UIColor(red: 1, green: 1, blue: 1, alpha: 1).cgColor /* #FFFFFF */
        self.ovalCopyTwoView.layer.borderWidth = 2
        
        self.ovalCopyTwoView.layer.cornerRadius = 7.5
        self.ovalCopyTwoView.layer.masksToBounds = true
        
        // Setup buttonButton
        self.buttonButton.layer.cornerRadius = 4
        self.buttonButton.layer.masksToBounds = true
        self.buttonButton.snImageTextSpacing = 10
        
        // Setup clearFilterLabel
        let clearFilterLabelAttrString = NSMutableAttributedString(string: "Clear Filter", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 14)!,
            .foregroundColor : UIColor(red: 1, green: 0.82, blue: 0.31, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.clearFilterLabel.attributedText = clearFilterLabelAttrString
        
    }

    private func setupUI()  {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    private func setupGestureRecognizers()  {
    
    }

    private func setupLocalization()  {
    
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Status Bar

    override public var prefersStatusBarHidden: Bool  {
        return false
    }

    override public var preferredStatusBarStyle: UIStatusBarStyle  {
        return .default
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Actions

    @IBAction public func onBackPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Payment Method", sender: nil)
    }

    @IBAction public func onButtonPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Search On List", sender: nil)
    }
}
