//
//  AppDrawer2ViewController.swift
//  Food UI Kit
//
//  Created by [Author].
//  Copyright © 2018 [Company]. All rights reserved.
//

// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Import

import UIKit


// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Implementation

class AppDrawer2ViewController: UIViewController {


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Properties

    @IBOutlet var shakibulIslamLabel: SupernovaLabel!
    @IBOutlet var userId10023Label: SupernovaLabel!
    @IBOutlet var helpCenterButton: SupernovaButton!
    @IBOutlet var privacyPolicyButton: SupernovaButton!
    @IBOutlet var privacyPolicyCopyButton: SupernovaButton!
    @IBOutlet var aboutUsButton: SupernovaButton!
    @IBOutlet var invitation1Button: SupernovaButton!
    @IBOutlet var aboutUsCopyButton: SupernovaButton!
    @IBOutlet var logoutLabel: SupernovaLabel!
    @IBOutlet var exitButton: SupernovaButton!
    @IBOutlet var homeButton: SupernovaButton!


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Lifecycle

    override public func viewDidLoad()  {
        super.viewDidLoad()
        self.setupComponents()
        self.setupUI()
        self.setupGestureRecognizers()
        self.setupLocalization()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override public func viewWillAppear(_ animated: Bool)  {
        super.viewWillAppear(animated)
        
        // Navigation bar, if any
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Setup

    private func setupComponents()  {
        // Setup shakibulIslamLabel
        let shakibulIslamLabelAttrString = NSMutableAttributedString(string: "Shakibul Islam", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.shakibulIslamLabel.attributedText = shakibulIslamLabelAttrString
        
        // Setup userId10023Label
        let userId10023LabelAttrString = NSMutableAttributedString(string: "User ID: 10023", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.userId10023Label.attributedText = userId10023LabelAttrString
        
        // Setup helpCenterButton
        self.helpCenterButton.snImageTextSpacing = 10
        
        // Setup privacyPolicyButton
        self.privacyPolicyButton.snImageTextSpacing = 10
        
        // Setup privacyPolicyCopyButton
        self.privacyPolicyCopyButton.snImageTextSpacing = 10
        
        // Setup aboutUsButton
        self.aboutUsButton.snImageTextSpacing = 10
        
        // Setup invitation1Button
        self.invitation1Button.snImageTextSpacing = 10
        
        // Setup aboutUsCopyButton
        self.aboutUsCopyButton.snImageTextSpacing = 10
        
        // Setup logoutLabel
        let logoutLabelAttrString = NSMutableAttributedString(string: "Logout", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.logoutLabel.attributedText = logoutLabelAttrString
        
        // Setup exitButton
        self.exitButton.snImageTextSpacing = 10
        
        // Setup homeButton
        self.homeButton.snImageTextSpacing = 10
        
    }

    private func setupUI()  {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    private func setupGestureRecognizers()  {
    
    }

    private func setupLocalization()  {
    
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Status Bar

    override public var prefersStatusBarHidden: Bool  {
        return false
    }

    override public var preferredStatusBarStyle: UIStatusBarStyle  {
        return .default
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Actions

    @IBAction public func onHelpCenterPressed(_ sender: UIButton)  {
    
    }

    @IBAction public func onPrivacyPolicyPressed(_ sender: UIButton)  {
    
    }

    @IBAction public func onPrivacyPolicyCopyPressed(_ sender: UIButton)  {
    
    }

    @IBAction public func onAboutUsPressed(_ sender: UIButton)  {
    
    }

    @IBAction public func onInvitation1Pressed(_ sender: UIButton)  {
    
    }

    @IBAction public func onAboutUsCopyPressed(_ sender: UIButton)  {
    
    }

    @IBAction public func onExitPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Add Card", sender: nil)
    }

    @IBAction public func onHomePressed(_ sender: UIButton)  {
    
    }
}
