//
//  UserProfileViewController.swift
//  Food UI Kit
//
//  Created by [Author].
//  Copyright © 2018 [Company]. All rights reserved.
//

// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Import

import UIKit


// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Implementation

class UserProfileViewController: UIViewController {


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Properties

    @IBOutlet var rectangleView: UIView!
    @IBOutlet var group7View: UIView!
    @IBOutlet var offerPromosLabel: SupernovaLabel!
    @IBOutlet var group14View: UIView!
    @IBOutlet var deliveryAddressLabel: SupernovaLabel!
    @IBOutlet var group14CopyView: UIView!
    @IBOutlet var myAllOrderLabel: SupernovaLabel!
    @IBOutlet var group13View: UIView!
    @IBOutlet var shakibulIslamLabel: SupernovaLabel!
    @IBOutlet var userId10023Label: SupernovaLabel!
    @IBOutlet var group6View: UIView!
    @IBOutlet var chevronRight1Button: SupernovaButton!
    @IBOutlet var myProfileLabel: SupernovaLabel!
    @IBOutlet var rectangleTwoView: UIView!
    @IBOutlet var rectangleCopy7View: UIView!
    @IBOutlet var chevronRight1TwoButton: SupernovaButton!
    @IBOutlet var notificaionLabel: SupernovaLabel!
    @IBOutlet var rectangleThreeView: UIView!
    @IBOutlet var rectangleCopy7TwoView: UIView!
    @IBOutlet var chevronRight1ThreeButton: SupernovaButton!
    @IBOutlet var settingsLabel: SupernovaLabel!
    @IBOutlet var rectangleFourView: UIView!
    @IBOutlet var rectangleCopy7ThreeView: UIView!
    @IBOutlet var paymentLabel: SupernovaLabel!
    @IBOutlet var rectangleFiveView: UIView!
    @IBOutlet var rectangleCopy7FourView: UIView!
    @IBOutlet var chevronRight1FourButton: SupernovaButton!
    @IBOutlet var logOutLabel: SupernovaLabel!
    @IBOutlet var rectangleSixView: UIView!
    @IBOutlet var tapBarCopy3View: UIView!
    @IBOutlet var userButton: SupernovaButton!
    @IBOutlet var favouriteLabel: SupernovaLabel!
    @IBOutlet var categoryLabel: SupernovaLabel!


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Lifecycle

    override public func viewDidLoad()  {
        super.viewDidLoad()
        self.setupComponents()
        self.setupUI()
        self.setupGestureRecognizers()
        self.setupLocalization()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override public func viewWillAppear(_ animated: Bool)  {
        super.viewWillAppear(animated)
        
        // Navigation bar, if any
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Setup

    private func setupComponents()  {
        // Setup rectangleView
        self.rectangleView.layer.cornerRadius = 12
        self.rectangleView.layer.masksToBounds = true
        
        // Setup group7View
        self.group7View.layer.shadowColor = UIColor(red: 0.827, green: 0.851, blue: 0.89, alpha: 0.149).cgColor /* #D3D9E3 */
        self.group7View.layer.shadowOffset = CGSize(width: 0, height: 2)
        self.group7View.layer.shadowRadius = 7
        self.group7View.layer.shadowOpacity = 1
        
        self.group7View.layer.cornerRadius = 14
        self.group7View.layer.masksToBounds = true
        
        // Setup offerPromosLabel
        let offerPromosLabelAttrString = NSMutableAttributedString(string: "Offer & \nPromos", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 18, paragraphSpacing: 0)
        ])
        self.offerPromosLabel.attributedText = offerPromosLabelAttrString
        
        // Setup group14View
        self.group14View.layer.cornerRadius = 18
        self.group14View.layer.masksToBounds = true
        
        // Setup deliveryAddressLabel
        let deliveryAddressLabelAttrString = NSMutableAttributedString(string: "Delivery\nAddress", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 18, paragraphSpacing: 0)
        ])
        self.deliveryAddressLabel.attributedText = deliveryAddressLabelAttrString
        
        // Setup group14CopyView
        self.group14CopyView.layer.cornerRadius = 18
        self.group14CopyView.layer.masksToBounds = true
        
        // Setup myAllOrderLabel
        let myAllOrderLabelAttrString = NSMutableAttributedString(string: "My All Order", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 18, paragraphSpacing: 0)
        ])
        self.myAllOrderLabel.attributedText = myAllOrderLabelAttrString
        
        // Setup group13View
        self.group13View.layer.cornerRadius = 18
        self.group13View.layer.masksToBounds = true
        
        // Setup shakibulIslamLabel
        let shakibulIslamLabelAttrString = NSMutableAttributedString(string: "Shakibul Islam", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.shakibulIslamLabel.attributedText = shakibulIslamLabelAttrString
        
        // Setup userId10023Label
        let userId10023LabelAttrString = NSMutableAttributedString(string: "User ID: 10023", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.userId10023Label.attributedText = userId10023LabelAttrString
        
        // Setup group6View
        self.group6View.layer.shadowColor = UIColor(red: 0.827, green: 0.851, blue: 0.89, alpha: 0.149).cgColor /* #D3D9E3 */
        self.group6View.layer.shadowOffset = CGSize(width: 0, height: 2)
        self.group6View.layer.shadowRadius = 7
        self.group6View.layer.shadowOpacity = 1
        
        self.group6View.layer.cornerRadius = 12
        self.group6View.layer.masksToBounds = true
        
        // Setup chevronRight1Button
        self.chevronRight1Button.snImageTextSpacing = 10
        
        // Setup myProfileLabel
        let myProfileLabelAttrString = NSMutableAttributedString(string: "My Profile", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.myProfileLabel.attributedText = myProfileLabelAttrString
        
        // Setup rectangleTwoView
        self.rectangleTwoView.layer.cornerRadius = 6
        self.rectangleTwoView.layer.masksToBounds = true
        
        // Setup rectangleCopy7View
        self.rectangleCopy7View.layer.cornerRadius = 0.5
        self.rectangleCopy7View.layer.masksToBounds = true
        
        // Setup chevronRight1TwoButton
        self.chevronRight1TwoButton.snImageTextSpacing = 10
        
        // Setup notificaionLabel
        let notificaionLabelAttrString = NSMutableAttributedString(string: "Notificaion", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.notificaionLabel.attributedText = notificaionLabelAttrString
        
        // Setup rectangleThreeView
        self.rectangleThreeView.layer.cornerRadius = 6
        self.rectangleThreeView.layer.masksToBounds = true
        
        // Setup rectangleCopy7TwoView
        self.rectangleCopy7TwoView.layer.cornerRadius = 0.5
        self.rectangleCopy7TwoView.layer.masksToBounds = true
        
        // Setup chevronRight1ThreeButton
        self.chevronRight1ThreeButton.snImageTextSpacing = 10
        
        // Setup settingsLabel
        let settingsLabelAttrString = NSMutableAttributedString(string: "Settings", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.settingsLabel.attributedText = settingsLabelAttrString
        
        // Setup rectangleFourView
        self.rectangleFourView.layer.cornerRadius = 6
        self.rectangleFourView.layer.masksToBounds = true
        
        // Setup rectangleCopy7ThreeView
        self.rectangleCopy7ThreeView.layer.cornerRadius = 0.5
        self.rectangleCopy7ThreeView.layer.masksToBounds = true
        
        // Setup paymentLabel
        let paymentLabelAttrString = NSMutableAttributedString(string: "Payment", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.paymentLabel.attributedText = paymentLabelAttrString
        
        // Setup rectangleFiveView
        self.rectangleFiveView.layer.cornerRadius = 6
        self.rectangleFiveView.layer.masksToBounds = true
        
        // Setup rectangleCopy7FourView
        self.rectangleCopy7FourView.layer.cornerRadius = 0.5
        self.rectangleCopy7FourView.layer.masksToBounds = true
        
        // Setup chevronRight1FourButton
        self.chevronRight1FourButton.snImageTextSpacing = 10
        
        // Setup logOutLabel
        let logOutLabelAttrString = NSMutableAttributedString(string: "Log Out", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.logOutLabel.attributedText = logOutLabelAttrString
        
        // Setup rectangleSixView
        self.rectangleSixView.layer.cornerRadius = 6
        self.rectangleSixView.layer.masksToBounds = true
        
        // Setup tapBarCopy3View
        self.tapBarCopy3View.layer.shadowColor = UIColor(red: 0.536, green: 0.657, blue: 0.794, alpha: 0.104).cgColor /* #89A8CA */
        self.tapBarCopy3View.layer.shadowOffset = CGSize(width: 0, height: -1)
        self.tapBarCopy3View.layer.shadowRadius = 3
        self.tapBarCopy3View.layer.shadowOpacity = 1
        
        self.tapBarCopy3View.layer.cornerRadius = 16
        self.tapBarCopy3View.layer.masksToBounds = true
        
        // Setup userButton
        self.userButton.snImageTextSpacing = 10
        
        // Setup favouriteLabel
        let favouriteLabelAttrString = NSMutableAttributedString(string: "Favourite", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.78, green: 0.81, blue: 0.86, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 12, paragraphSpacing: 0)
        ])
        self.favouriteLabel.attributedText = favouriteLabelAttrString
        
        // Setup categoryLabel
        let categoryLabelAttrString = NSMutableAttributedString(string: "Category", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.78, green: 0.81, blue: 0.86, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 12, paragraphSpacing: 0)
        ])
        self.categoryLabel.attributedText = categoryLabelAttrString
        
    }

    private func setupUI()  {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    private func setupGestureRecognizers()  {
    
    }

    private func setupLocalization()  {
    
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Status Bar

    override public var prefersStatusBarHidden: Bool  {
        return false
    }

    override public var preferredStatusBarStyle: UIStatusBarStyle  {
        return .default
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Actions

    @IBAction public func onChevronRight1Pressed(_ sender: UIButton)  {
    
    }

    @IBAction public func onChevronRight1ThreePressed(_ sender: UIButton)  {
    
    }

    @IBAction public func onChevronRight1TwoPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Setting", sender: nil)
    }

    @IBAction public func onChevronRight1FourPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Splash", sender: nil)
    }

    @IBAction public func onUserPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Edit profile", sender: nil)
    }
}
