//
//  SettingViewController.swift
//  Food UI Kit
//
//  Created by [Author].
//  Copyright © 2018 [Company]. All rights reserved.
//

// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Import

import UIKit


// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Implementation

class SettingViewController: UIViewController {


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Properties

    @IBOutlet var backButton: SupernovaButton!
    @IBOutlet var group6View: UIView!
    @IBOutlet var englishUsaLabel: SupernovaLabel!
    @IBOutlet var languageLabel: SupernovaLabel!
    @IBOutlet var rectangleCopy7View: UIView!
    @IBOutlet var labelLabel: SupernovaLabel!
    @IBOutlet var changeLabel: SupernovaLabel!
    @IBOutlet var changePasswordLabel: SupernovaLabel!
    @IBOutlet var rectangleCopy7TwoView: UIView!
    @IBOutlet var abcGmailComLabel: SupernovaLabel!
    @IBOutlet var changeTwoLabel: SupernovaLabel!
    @IBOutlet var updateEmailLabel: SupernovaLabel!
    @IBOutlet var rectangleCopy7ThreeView: UIView!


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Lifecycle

    override public func viewDidLoad()  {
        super.viewDidLoad()
        self.setupComponents()
        self.setupUI()
        self.setupGestureRecognizers()
        self.setupLocalization()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override public func viewWillAppear(_ animated: Bool)  {
        super.viewWillAppear(animated)
        
        // Navigation bar, if any
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Setup

    private func setupComponents()  {
        // Setup backButton
        self.backButton.snImageTextSpacing = 10
        
        // Setup group6View
        self.group6View.layer.shadowColor = UIColor(red: 0.827, green: 0.851, blue: 0.89, alpha: 0.149).cgColor /* #D3D9E3 */
        self.group6View.layer.shadowOffset = CGSize(width: 0, height: 2)
        self.group6View.layer.shadowRadius = 7
        self.group6View.layer.shadowOpacity = 1
        
        self.group6View.layer.cornerRadius = 12
        self.group6View.layer.masksToBounds = true
        
        // Setup englishUsaLabel
        let englishUsaLabelAttrString = NSMutableAttributedString(string: "English (USA)", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.englishUsaLabel.attributedText = englishUsaLabelAttrString
        
        // Setup languageLabel
        let languageLabelAttrString = NSMutableAttributedString(string: "Language", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.languageLabel.attributedText = languageLabelAttrString
        
        // Setup rectangleCopy7View
        self.rectangleCopy7View.layer.cornerRadius = 0.5
        self.rectangleCopy7View.layer.masksToBounds = true
        
        // Setup labelLabel
        let labelLabelAttrString = NSMutableAttributedString(string: "************", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.labelLabel.attributedText = labelLabelAttrString
        
        // Setup changeLabel
        let changeLabelAttrString = NSMutableAttributedString(string: "Change", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 14)!,
            .foregroundColor : UIColor(red: 1, green: 0.82, blue: 0.31, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .right, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.changeLabel.attributedText = changeLabelAttrString
        
        // Setup changePasswordLabel
        let changePasswordLabelAttrString = NSMutableAttributedString(string: "Change Password", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.changePasswordLabel.attributedText = changePasswordLabelAttrString
        
        // Setup rectangleCopy7TwoView
        self.rectangleCopy7TwoView.layer.cornerRadius = 0.5
        self.rectangleCopy7TwoView.layer.masksToBounds = true
        
        // Setup abcGmailComLabel
        let abcGmailComLabelAttrString = NSMutableAttributedString(string: "abc@gmail.com", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.abcGmailComLabel.attributedText = abcGmailComLabelAttrString
        
        // Setup changeTwoLabel
        let changeTwoLabelAttrString = NSMutableAttributedString(string: "Change", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 14)!,
            .foregroundColor : UIColor(red: 1, green: 0.82, blue: 0.31, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .right, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.changeTwoLabel.attributedText = changeTwoLabelAttrString
        
        // Setup updateEmailLabel
        let updateEmailLabelAttrString = NSMutableAttributedString(string: "Update Email", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.updateEmailLabel.attributedText = updateEmailLabelAttrString
        
        // Setup rectangleCopy7ThreeView
        self.rectangleCopy7ThreeView.layer.cornerRadius = 0.5
        self.rectangleCopy7ThreeView.layer.masksToBounds = true
        
    }

    private func setupUI()  {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    private func setupGestureRecognizers()  {
    
    }

    private func setupLocalization()  {
    
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Status Bar

    override public var prefersStatusBarHidden: Bool  {
        return false
    }

    override public var preferredStatusBarStyle: UIStatusBarStyle  {
        return .default
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Actions

    @IBAction public func onBackPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Edit profile", sender: nil)
    }
}
