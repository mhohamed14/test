//
//  OfferAndPromosExpiredViewController.swift
//  Food UI Kit
//
//  Created by [Author].
//  Copyright © 2018 [Company]. All rights reserved.
//

// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Import

import UIKit


// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Implementation

class OfferAndPromosExpiredViewController: UIViewController {


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Properties

    @IBOutlet var backButton: SupernovaButton!
    @IBOutlet var rectangleCopy7View: UIView!
    @IBOutlet var group14Button: SupernovaButton!
    @IBOutlet var ovalCopyView: UIView!
    @IBOutlet var ovalCopy9View: UIView!
    @IBOutlet var ovalCopy8View: UIView!
    @IBOutlet var ovalView: UIView!
    @IBOutlet var ovalCopy3View: UIView!
    @IBOutlet var ovalCopy2View: UIView!
    @IBOutlet var labelLabel: SupernovaLabel!
    @IBOutlet var youDonTHaveAnyULabel: SupernovaLabel!


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Lifecycle

    override public func viewDidLoad()  {
        super.viewDidLoad()
        self.setupComponents()
        self.setupUI()
        self.setupGestureRecognizers()
        self.setupLocalization()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override public func viewWillAppear(_ animated: Bool)  {
        super.viewWillAppear(animated)
        
        // Navigation bar, if any
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Setup

    private func setupComponents()  {
        // Setup backButton
        self.backButton.snImageTextSpacing = 10
        
        // Setup rectangleCopy7View
        self.rectangleCopy7View.layer.shadowColor = UIColor(red: 0.827, green: 0.851, blue: 0.89, alpha: 0.149).cgColor /* #D3D9E3 */
        self.rectangleCopy7View.layer.shadowOffset = CGSize(width: 0, height: 2)
        self.rectangleCopy7View.layer.shadowRadius = 7
        self.rectangleCopy7View.layer.shadowOpacity = 1
        
        self.rectangleCopy7View.layer.cornerRadius = 9
        self.rectangleCopy7View.layer.masksToBounds = true
        
        // Setup group14Button
        self.group14Button.layer.cornerRadius = 8
        self.group14Button.layer.masksToBounds = true
        self.group14Button.snImageTextSpacing = 10
        
        // Setup ovalCopyView
        self.ovalCopyView.layer.cornerRadius = 13
        self.ovalCopyView.layer.masksToBounds = true
        
        // Setup ovalCopy9View
        self.ovalCopy9View.layer.cornerRadius = 13
        self.ovalCopy9View.layer.masksToBounds = true
        
        // Setup ovalCopy8View
        self.ovalCopy8View.layer.cornerRadius = 13
        self.ovalCopy8View.layer.masksToBounds = true
        
        // Setup ovalView
        self.ovalView.layer.cornerRadius = 13
        self.ovalView.layer.masksToBounds = true
        
        // Setup ovalCopy3View
        self.ovalCopy3View.layer.cornerRadius = 13
        self.ovalCopy3View.layer.masksToBounds = true
        
        // Setup ovalCopy2View
        self.ovalCopy2View.layer.cornerRadius = 13
        self.ovalCopy2View.layer.masksToBounds = true
        
        // Setup labelLabel
        let labelLabelAttrString = NSMutableAttributedString(string: "%", attributes: [
            .font : UIFont(name: "Avenir-Black", size: 75)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 58, paragraphSpacing: 0)
        ])
        self.labelLabel.attributedText = labelLabelAttrString
        
        // Setup youDonTHaveAnyULabel
        let youDonTHaveAnyULabelAttrString = NSMutableAttributedString(string: "You don’t have any Used Promo yet", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.youDonTHaveAnyULabel.attributedText = youDonTHaveAnyULabelAttrString
        
    }

    private func setupUI()  {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    private func setupGestureRecognizers()  {
    
    }

    private func setupLocalization()  {
    
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Status Bar

    override public var prefersStatusBarHidden: Bool  {
        return false
    }

    override public var preferredStatusBarStyle: UIStatusBarStyle  {
        return .default
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Actions

    @IBAction public func onBackPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Edit Delivery Address Two", sender: nil)
    }

    @IBAction public func onGroup14Pressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Edit Delivery Address", sender: nil)
    }
}
