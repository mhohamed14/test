//
//  MyOrderViewController.swift
//  Food UI Kit
//
//  Created by [Author].
//  Copyright © 2018 [Company]. All rights reserved.
//

// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Import

import UIKit


// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Implementation

class MyOrderViewController: UIViewController {


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Properties

    @IBOutlet var orderView: UIView!
    @IBOutlet var labelLabel: SupernovaLabel!
    @IBOutlet var orderIdLabel: SupernovaLabel!
    @IBOutlet var onTheWayLabel: SupernovaLabel!
    @IBOutlet var statusLabel: SupernovaLabel!
    @IBOutlet var mayLabel: SupernovaLabel!
    @IBOutlet var group14View: UIView!
    @IBOutlet var orderCopyView: UIView!
    @IBOutlet var labelTwoLabel: SupernovaLabel!
    @IBOutlet var orderIdTwoLabel: SupernovaLabel!
    @IBOutlet var processingLabel: SupernovaLabel!
    @IBOutlet var statusTwoLabel: SupernovaLabel!
    @IBOutlet var mayTwoLabel: SupernovaLabel!
    @IBOutlet var group14TwoView: UIView!
    @IBOutlet var orderCopy2View: UIView!
    @IBOutlet var labelThreeLabel: SupernovaLabel!
    @IBOutlet var orderIdThreeLabel: SupernovaLabel!
    @IBOutlet var cancelledLabel: SupernovaLabel!
    @IBOutlet var statusThreeLabel: SupernovaLabel!
    @IBOutlet var mayThreeLabel: SupernovaLabel!
    @IBOutlet var group14ThreeView: UIView!
    @IBOutlet var orderCopy3View: UIView!
    @IBOutlet var labelFourLabel: SupernovaLabel!
    @IBOutlet var orderIdFourLabel: SupernovaLabel!
    @IBOutlet var processingTwoLabel: SupernovaLabel!
    @IBOutlet var statusFourLabel: SupernovaLabel!
    @IBOutlet var mayFourLabel: SupernovaLabel!
    @IBOutlet var group14FourView: UIView!
    @IBOutlet var orderCopy4View: UIView!
    @IBOutlet var labelFiveLabel: SupernovaLabel!
    @IBOutlet var orderIdFiveLabel: SupernovaLabel!
    @IBOutlet var cancelledTwoLabel: SupernovaLabel!
    @IBOutlet var statusFiveLabel: SupernovaLabel!
    @IBOutlet var mayFiveLabel: SupernovaLabel!
    @IBOutlet var group14FiveView: UIView!
    @IBOutlet var orderCopy5View: UIView!
    @IBOutlet var labelSixLabel: SupernovaLabel!
    @IBOutlet var orderIdSixLabel: SupernovaLabel!
    @IBOutlet var onTheWayTwoLabel: SupernovaLabel!
    @IBOutlet var statusSixLabel: SupernovaLabel!
    @IBOutlet var maySixLabel: SupernovaLabel!
    @IBOutlet var group14SixView: UIView!
    @IBOutlet var orderCopy6View: UIView!
    @IBOutlet var labelSevenLabel: SupernovaLabel!
    @IBOutlet var orderIdSevenLabel: SupernovaLabel!
    @IBOutlet var canelledLabel: SupernovaLabel!
    @IBOutlet var statusSevenLabel: SupernovaLabel!
    @IBOutlet var maySevenLabel: SupernovaLabel!
    @IBOutlet var group14SevenView: UIView!
    @IBOutlet var userNameView: UIView!
    @IBOutlet var rectangleCopy8Button: SupernovaButton!
    @IBOutlet var currentLabel: SupernovaLabel!
    @IBOutlet var previousLabel: SupernovaLabel!
    @IBOutlet var backButton: SupernovaButton!


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Lifecycle

    override public func viewDidLoad()  {
        super.viewDidLoad()
        self.setupComponents()
        self.setupUI()
        self.setupGestureRecognizers()
        self.setupLocalization()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override public func viewWillAppear(_ animated: Bool)  {
        super.viewWillAppear(animated)
        
        // Navigation bar, if any
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Setup

    private func setupComponents()  {
        // Setup orderView
        self.orderView.layer.shadowColor = UIColor(red: 0.827, green: 0.851, blue: 0.89, alpha: 0.149).cgColor /* #D3D9E3 */
        self.orderView.layer.shadowOffset = CGSize(width: 0, height: 2)
        self.orderView.layer.shadowRadius = 7
        self.orderView.layer.shadowOpacity = 1
        
        self.orderView.layer.cornerRadius = 7
        self.orderView.layer.masksToBounds = true
        
        // Setup labelLabel
        let labelLabelAttrString = NSMutableAttributedString(string: "1252502680", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.labelLabel.attributedText = labelLabelAttrString
        
        // Setup orderIdLabel
        let orderIdLabelAttrString = NSMutableAttributedString(string: "Order ID:", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.orderIdLabel.attributedText = orderIdLabelAttrString
        
        // Setup onTheWayLabel
        let onTheWayLabelAttrString = NSMutableAttributedString(string: "On The Way", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.97, green: 0.77, blue: 0.19, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.onTheWayLabel.attributedText = onTheWayLabelAttrString
        
        // Setup statusLabel
        let statusLabelAttrString = NSMutableAttributedString(string: "Status:", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.statusLabel.attributedText = statusLabelAttrString
        
        // Setup mayLabel
        let mayLabelAttrString = NSMutableAttributedString(string: "20 May", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.mayLabel.attributedText = mayLabelAttrString
        
        // Setup group14View
        self.group14View.layer.cornerRadius = 8
        self.group14View.layer.masksToBounds = true
        
        // Setup orderCopyView
        self.orderCopyView.layer.shadowColor = UIColor(red: 0.827, green: 0.851, blue: 0.89, alpha: 0.149).cgColor /* #D3D9E3 */
        self.orderCopyView.layer.shadowOffset = CGSize(width: 0, height: 2)
        self.orderCopyView.layer.shadowRadius = 7
        self.orderCopyView.layer.shadowOpacity = 1
        
        self.orderCopyView.layer.cornerRadius = 7
        self.orderCopyView.layer.masksToBounds = true
        
        // Setup labelTwoLabel
        let labelTwoLabelAttrString = NSMutableAttributedString(string: "1252502680", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.labelTwoLabel.attributedText = labelTwoLabelAttrString
        
        // Setup orderIdTwoLabel
        let orderIdTwoLabelAttrString = NSMutableAttributedString(string: "Order ID:", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.orderIdTwoLabel.attributedText = orderIdTwoLabelAttrString
        
        // Setup processingLabel
        let processingLabelAttrString = NSMutableAttributedString(string: "Processing", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.97, green: 0.77, blue: 0.19, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.processingLabel.attributedText = processingLabelAttrString
        
        // Setup statusTwoLabel
        let statusTwoLabelAttrString = NSMutableAttributedString(string: "Status:", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.statusTwoLabel.attributedText = statusTwoLabelAttrString
        
        // Setup mayTwoLabel
        let mayTwoLabelAttrString = NSMutableAttributedString(string: "20 May", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.mayTwoLabel.attributedText = mayTwoLabelAttrString
        
        // Setup group14TwoView
        self.group14TwoView.layer.cornerRadius = 8
        self.group14TwoView.layer.masksToBounds = true
        
        // Setup orderCopy2View
        self.orderCopy2View.layer.shadowColor = UIColor(red: 0.827, green: 0.851, blue: 0.89, alpha: 0.149).cgColor /* #D3D9E3 */
        self.orderCopy2View.layer.shadowOffset = CGSize(width: 0, height: 2)
        self.orderCopy2View.layer.shadowRadius = 7
        self.orderCopy2View.layer.shadowOpacity = 1
        
        self.orderCopy2View.layer.cornerRadius = 7
        self.orderCopy2View.layer.masksToBounds = true
        
        // Setup labelThreeLabel
        let labelThreeLabelAttrString = NSMutableAttributedString(string: "1252502680", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.labelThreeLabel.attributedText = labelThreeLabelAttrString
        
        // Setup orderIdThreeLabel
        let orderIdThreeLabelAttrString = NSMutableAttributedString(string: "Order ID:", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.orderIdThreeLabel.attributedText = orderIdThreeLabelAttrString
        
        // Setup cancelledLabel
        let cancelledLabelAttrString = NSMutableAttributedString(string: "Cancelled", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.91, green: 0.24, blue: 0.24, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.cancelledLabel.attributedText = cancelledLabelAttrString
        
        // Setup statusThreeLabel
        let statusThreeLabelAttrString = NSMutableAttributedString(string: "Status:", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.statusThreeLabel.attributedText = statusThreeLabelAttrString
        
        // Setup mayThreeLabel
        let mayThreeLabelAttrString = NSMutableAttributedString(string: "20 May", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.mayThreeLabel.attributedText = mayThreeLabelAttrString
        
        // Setup group14ThreeView
        self.group14ThreeView.layer.cornerRadius = 8
        self.group14ThreeView.layer.masksToBounds = true
        
        // Setup orderCopy3View
        self.orderCopy3View.layer.shadowColor = UIColor(red: 0.827, green: 0.851, blue: 0.89, alpha: 0.149).cgColor /* #D3D9E3 */
        self.orderCopy3View.layer.shadowOffset = CGSize(width: 0, height: 2)
        self.orderCopy3View.layer.shadowRadius = 7
        self.orderCopy3View.layer.shadowOpacity = 1
        
        self.orderCopy3View.layer.cornerRadius = 7
        self.orderCopy3View.layer.masksToBounds = true
        
        // Setup labelFourLabel
        let labelFourLabelAttrString = NSMutableAttributedString(string: "1252502680", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.labelFourLabel.attributedText = labelFourLabelAttrString
        
        // Setup orderIdFourLabel
        let orderIdFourLabelAttrString = NSMutableAttributedString(string: "Order ID:", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.orderIdFourLabel.attributedText = orderIdFourLabelAttrString
        
        // Setup processingTwoLabel
        let processingTwoLabelAttrString = NSMutableAttributedString(string: "Processing", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.97, green: 0.77, blue: 0.19, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.processingTwoLabel.attributedText = processingTwoLabelAttrString
        
        // Setup statusFourLabel
        let statusFourLabelAttrString = NSMutableAttributedString(string: "Status:", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.statusFourLabel.attributedText = statusFourLabelAttrString
        
        // Setup mayFourLabel
        let mayFourLabelAttrString = NSMutableAttributedString(string: "20 May", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.mayFourLabel.attributedText = mayFourLabelAttrString
        
        // Setup group14FourView
        self.group14FourView.layer.cornerRadius = 8
        self.group14FourView.layer.masksToBounds = true
        
        // Setup orderCopy4View
        self.orderCopy4View.layer.shadowColor = UIColor(red: 0.827, green: 0.851, blue: 0.89, alpha: 0.149).cgColor /* #D3D9E3 */
        self.orderCopy4View.layer.shadowOffset = CGSize(width: 0, height: 2)
        self.orderCopy4View.layer.shadowRadius = 7
        self.orderCopy4View.layer.shadowOpacity = 1
        
        self.orderCopy4View.layer.cornerRadius = 7
        self.orderCopy4View.layer.masksToBounds = true
        
        // Setup labelFiveLabel
        let labelFiveLabelAttrString = NSMutableAttributedString(string: "1252502680", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.labelFiveLabel.attributedText = labelFiveLabelAttrString
        
        // Setup orderIdFiveLabel
        let orderIdFiveLabelAttrString = NSMutableAttributedString(string: "Order ID:", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.orderIdFiveLabel.attributedText = orderIdFiveLabelAttrString
        
        // Setup cancelledTwoLabel
        let cancelledTwoLabelAttrString = NSMutableAttributedString(string: "Cancelled", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.91, green: 0.24, blue: 0.24, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.cancelledTwoLabel.attributedText = cancelledTwoLabelAttrString
        
        // Setup statusFiveLabel
        let statusFiveLabelAttrString = NSMutableAttributedString(string: "Status:", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.statusFiveLabel.attributedText = statusFiveLabelAttrString
        
        // Setup mayFiveLabel
        let mayFiveLabelAttrString = NSMutableAttributedString(string: "20 May", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.mayFiveLabel.attributedText = mayFiveLabelAttrString
        
        // Setup group14FiveView
        self.group14FiveView.layer.cornerRadius = 8
        self.group14FiveView.layer.masksToBounds = true
        
        // Setup orderCopy5View
        self.orderCopy5View.layer.shadowColor = UIColor(red: 0.827, green: 0.851, blue: 0.89, alpha: 0.149).cgColor /* #D3D9E3 */
        self.orderCopy5View.layer.shadowOffset = CGSize(width: 0, height: 2)
        self.orderCopy5View.layer.shadowRadius = 7
        self.orderCopy5View.layer.shadowOpacity = 1
        
        self.orderCopy5View.layer.cornerRadius = 7
        self.orderCopy5View.layer.masksToBounds = true
        
        // Setup labelSixLabel
        let labelSixLabelAttrString = NSMutableAttributedString(string: "1252502680", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.labelSixLabel.attributedText = labelSixLabelAttrString
        
        // Setup orderIdSixLabel
        let orderIdSixLabelAttrString = NSMutableAttributedString(string: "Order ID:", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.orderIdSixLabel.attributedText = orderIdSixLabelAttrString
        
        // Setup onTheWayTwoLabel
        let onTheWayTwoLabelAttrString = NSMutableAttributedString(string: "On The Way", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.97, green: 0.77, blue: 0.19, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.onTheWayTwoLabel.attributedText = onTheWayTwoLabelAttrString
        
        // Setup statusSixLabel
        let statusSixLabelAttrString = NSMutableAttributedString(string: "Status:", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.statusSixLabel.attributedText = statusSixLabelAttrString
        
        // Setup maySixLabel
        let maySixLabelAttrString = NSMutableAttributedString(string: "20 May", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.maySixLabel.attributedText = maySixLabelAttrString
        
        // Setup group14SixView
        self.group14SixView.layer.cornerRadius = 8
        self.group14SixView.layer.masksToBounds = true
        
        // Setup orderCopy6View
        self.orderCopy6View.layer.shadowColor = UIColor(red: 0.827, green: 0.851, blue: 0.89, alpha: 0.149).cgColor /* #D3D9E3 */
        self.orderCopy6View.layer.shadowOffset = CGSize(width: 0, height: 2)
        self.orderCopy6View.layer.shadowRadius = 7
        self.orderCopy6View.layer.shadowOpacity = 1
        
        self.orderCopy6View.layer.cornerRadius = 7
        self.orderCopy6View.layer.masksToBounds = true
        
        // Setup labelSevenLabel
        let labelSevenLabelAttrString = NSMutableAttributedString(string: "1252502680", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.labelSevenLabel.attributedText = labelSevenLabelAttrString
        
        // Setup orderIdSevenLabel
        let orderIdSevenLabelAttrString = NSMutableAttributedString(string: "Order ID:", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.orderIdSevenLabel.attributedText = orderIdSevenLabelAttrString
        
        // Setup canelledLabel
        let canelledLabelAttrString = NSMutableAttributedString(string: "Canelled", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.91, green: 0.24, blue: 0.24, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.canelledLabel.attributedText = canelledLabelAttrString
        
        // Setup statusSevenLabel
        let statusSevenLabelAttrString = NSMutableAttributedString(string: "Status:", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.statusSevenLabel.attributedText = statusSevenLabelAttrString
        
        // Setup maySevenLabel
        let maySevenLabelAttrString = NSMutableAttributedString(string: "20 May", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.maySevenLabel.attributedText = maySevenLabelAttrString
        
        // Setup group14SevenView
        self.group14SevenView.layer.cornerRadius = 8
        self.group14SevenView.layer.masksToBounds = true
        
        // Setup userNameView
        self.userNameView.layer.cornerRadius = 5
        self.userNameView.layer.masksToBounds = true
        
        // Setup rectangleCopy8Button
        self.rectangleCopy8Button.layer.shadowColor = UIColor(red: 0.827, green: 0.851, blue: 0.89, alpha: 0.25).cgColor /* #D3D9E3 */
        self.rectangleCopy8Button.layer.shadowOffset = CGSize(width: 0, height: 2)
        self.rectangleCopy8Button.layer.shadowRadius = 7
        self.rectangleCopy8Button.layer.shadowOpacity = 1
        
        self.rectangleCopy8Button.layer.cornerRadius = 5
        self.rectangleCopy8Button.layer.masksToBounds = true
        self.rectangleCopy8Button.snImageTextSpacing = 10
        
        // Setup currentLabel
        let currentLabelAttrString = NSMutableAttributedString(string: "Current", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.currentLabel.attributedText = currentLabelAttrString
        
        // Setup previousLabel
        let previousLabelAttrString = NSMutableAttributedString(string: "Previous", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.previousLabel.attributedText = previousLabelAttrString
        
        // Setup backButton
        self.backButton.snImageTextSpacing = 10
        
    }

    private func setupUI()  {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    private func setupGestureRecognizers()  {
    
    }

    private func setupLocalization()  {
    
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Status Bar

    override public var prefersStatusBarHidden: Bool  {
        return false
    }

    override public var preferredStatusBarStyle: UIStatusBarStyle  {
        return .default
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Actions

    @IBAction public func onRectangleCopy8Pressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push User Profile", sender: nil)
    }

    @IBAction public func onBackPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push My Previous Order", sender: nil)
    }
}
