//
//  IngerdientsViewController.swift
//  Food UI Kit
//
//  Created by [Author].
//  Copyright © 2018 [Company]. All rights reserved.
//

// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Import

import UIKit


// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Implementation

class IngerdientsViewController: UIViewController {


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Properties

    @IBOutlet var rectangleView: UIView!
    @IBOutlet var chickenBurgerLabel: SupernovaLabel!
    @IBOutlet var minLabel: SupernovaLabel!
    @IBOutlet var kmLabel: SupernovaLabel!
    @IBOutlet var labelLabel: SupernovaLabel!
    @IBOutlet var chickenLabel: SupernovaLabel!
    @IBOutlet var pcsLabel: SupernovaLabel!
    @IBOutlet var rectangleTwoView: UIView!
    @IBOutlet var cabbageLabel: SupernovaLabel!
    @IBOutlet var gmLabel: SupernovaLabel!
    @IBOutlet var rectangleThreeView: UIView!
    @IBOutlet var chilliLabel: SupernovaLabel!
    @IBOutlet var gmTwoLabel: SupernovaLabel!
    @IBOutlet var rectangleFourView: UIView!
    @IBOutlet var onionLabel: SupernovaLabel!
    @IBOutlet var gmThreeLabel: SupernovaLabel!
    @IBOutlet var rectangleFiveView: UIView!
    @IBOutlet var carrotLabel: SupernovaLabel!
    @IBOutlet var gmFourLabel: SupernovaLabel!
    @IBOutlet var rectangleSixView: UIView!
    @IBOutlet var tomatoLabel: SupernovaLabel!
    @IBOutlet var gmFiveLabel: SupernovaLabel!
    @IBOutlet var rectangleSevenView: UIView!
    @IBOutlet var addToCartView: UIView!
    @IBOutlet var addToCartButtonButton: SupernovaButton!
    @IBOutlet var numberView: UIView!
    @IBOutlet var group4View: UIView!
    @IBOutlet var group3Button: SupernovaButton!
    @IBOutlet var group4CopyView: UIView!
    @IBOutlet var group3TwoButton: SupernovaButton!
    @IBOutlet var labelTwoLabel: SupernovaLabel!


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Lifecycle

    override public func viewDidLoad()  {
        super.viewDidLoad()
        self.setupComponents()
        self.setupUI()
        self.setupGestureRecognizers()
        self.setupLocalization()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override public func viewWillAppear(_ animated: Bool)  {
        super.viewWillAppear(animated)
        
        // Navigation bar, if any
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Setup

    private func setupComponents()  {
        // Setup rectangleView
        self.rectangleView.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.05).cgColor /* #000000 */
        self.rectangleView.layer.shadowOffset = CGSize(width: 0, height: -1)
        self.rectangleView.layer.shadowRadius = 3
        self.rectangleView.layer.shadowOpacity = 1
        
        self.rectangleView.layer.cornerRadius = 50
        self.rectangleView.layer.masksToBounds = true
        
        // Setup chickenBurgerLabel
        let chickenBurgerLabelAttrString = NSMutableAttributedString(string: "Chicken Burger", attributes: [
            .font : UIFont(name: "Avenir-Heavy", size: 24)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 22, paragraphSpacing: 0)
        ])
        self.chickenBurgerLabel.attributedText = chickenBurgerLabelAttrString
        
        // Setup minLabel
        let minLabelAttrString = NSMutableAttributedString(string: "30 min", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.minLabel.attributedText = minLabelAttrString
        
        // Setup kmLabel
        let kmLabelAttrString = NSMutableAttributedString(string: "1.4 km", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.kmLabel.attributedText = kmLabelAttrString
        
        // Setup labelLabel
        let labelLabelAttrString = NSMutableAttributedString(string: "4.3 (132)", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.labelLabel.attributedText = labelLabelAttrString
        
        // Setup chickenLabel
        let chickenLabelAttrString = NSMutableAttributedString(string: "Chicken :", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.chickenLabel.attributedText = chickenLabelAttrString
        
        // Setup pcsLabel
        let pcsLabelAttrString = NSMutableAttributedString(string: "02 Pcs", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.pcsLabel.attributedText = pcsLabelAttrString
        
        // Setup rectangleTwoView
        self.rectangleTwoView.layer.cornerRadius = 0.5
        self.rectangleTwoView.layer.masksToBounds = true
        
        // Setup cabbageLabel
        let cabbageLabelAttrString = NSMutableAttributedString(string: "Cabbage :", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.cabbageLabel.attributedText = cabbageLabelAttrString
        
        // Setup gmLabel
        let gmLabelAttrString = NSMutableAttributedString(string: "500 Gm", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.gmLabel.attributedText = gmLabelAttrString
        
        // Setup rectangleThreeView
        self.rectangleThreeView.layer.cornerRadius = 0.5
        self.rectangleThreeView.layer.masksToBounds = true
        
        // Setup chilliLabel
        let chilliLabelAttrString = NSMutableAttributedString(string: "Chilli :", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.chilliLabel.attributedText = chilliLabelAttrString
        
        // Setup gmTwoLabel
        let gmTwoLabelAttrString = NSMutableAttributedString(string: "50 Gm", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.gmTwoLabel.attributedText = gmTwoLabelAttrString
        
        // Setup rectangleFourView
        self.rectangleFourView.layer.cornerRadius = 0.5
        self.rectangleFourView.layer.masksToBounds = true
        
        // Setup onionLabel
        let onionLabelAttrString = NSMutableAttributedString(string: "Onion :", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.onionLabel.attributedText = onionLabelAttrString
        
        // Setup gmThreeLabel
        let gmThreeLabelAttrString = NSMutableAttributedString(string: "200 Gm", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.gmThreeLabel.attributedText = gmThreeLabelAttrString
        
        // Setup rectangleFiveView
        self.rectangleFiveView.layer.cornerRadius = 0.5
        self.rectangleFiveView.layer.masksToBounds = true
        
        // Setup carrotLabel
        let carrotLabelAttrString = NSMutableAttributedString(string: "Carrot :", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.carrotLabel.attributedText = carrotLabelAttrString
        
        // Setup gmFourLabel
        let gmFourLabelAttrString = NSMutableAttributedString(string: "200 Gm", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.gmFourLabel.attributedText = gmFourLabelAttrString
        
        // Setup rectangleSixView
        self.rectangleSixView.layer.cornerRadius = 0.5
        self.rectangleSixView.layer.masksToBounds = true
        
        // Setup tomatoLabel
        let tomatoLabelAttrString = NSMutableAttributedString(string: "Tomato :", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.tomatoLabel.attributedText = tomatoLabelAttrString
        
        // Setup gmFiveLabel
        let gmFiveLabelAttrString = NSMutableAttributedString(string: "100 Gm", attributes: [
            .font : UIFont(name: "Avenir-Roman", size: 12)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.gmFiveLabel.attributedText = gmFiveLabelAttrString
        
        // Setup rectangleSevenView
        self.rectangleSevenView.layer.cornerRadius = 0.5
        self.rectangleSevenView.layer.masksToBounds = true
        
        // Setup addToCartView
        self.addToCartView.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.05).cgColor /* #000000 */
        self.addToCartView.layer.shadowOffset = CGSize(width: 0, height: -1)
        self.addToCartView.layer.shadowRadius = 3
        self.addToCartView.layer.shadowOpacity = 1
        
        self.addToCartView.layer.cornerRadius = 12
        self.addToCartView.layer.masksToBounds = true
        
        // Setup addToCartButtonButton
        self.addToCartButtonButton.layer.shadowColor = UIColor(red: 1, green: 0.824, blue: 0.306, alpha: 0.204).cgColor /* #FFD24E */
        self.addToCartButtonButton.layer.shadowOffset = CGSize(width: 0, height: 3)
        self.addToCartButtonButton.layer.shadowRadius = 8
        self.addToCartButtonButton.layer.shadowOpacity = 1
        
        self.addToCartButtonButton.layer.cornerRadius = 4
        self.addToCartButtonButton.layer.masksToBounds = true
        self.addToCartButtonButton.snImageTextSpacing = 10
        
        // Setup numberView
        self.numberView.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.02).cgColor /* #000000 */
        self.numberView.layer.shadowOffset = CGSize(width: 0, height: 2)
        self.numberView.layer.shadowRadius = 8
        self.numberView.layer.shadowOpacity = 1
        
        self.numberView.layer.cornerRadius = 4
        self.numberView.layer.masksToBounds = true
        
        // Setup group4View
        self.group4View.layer.cornerRadius = 8
        self.group4View.layer.masksToBounds = true
        
        // Setup group3Button
        self.group3Button.snImageTextSpacing = 10
        
        // Setup group4CopyView
        self.group4CopyView.layer.cornerRadius = 8
        self.group4CopyView.layer.masksToBounds = true
        
        // Setup group3TwoButton
        self.group3TwoButton.snImageTextSpacing = 10
        
        // Setup labelTwoLabel
        let labelTwoLabelAttrString = NSMutableAttributedString(string: "2", attributes: [
            .font : UIFont(name: "Avenir-Medium", size: 14)!,
            .foregroundColor : UIColor(red: 0.26, green: 0.31, blue: 0.38, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 14, paragraphSpacing: 0)
        ])
        self.labelTwoLabel.attributedText = labelTwoLabelAttrString
        
    }

    private func setupUI()  {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    private func setupGestureRecognizers()  {
    
    }

    private func setupLocalization()  {
    
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Status Bar

    override public var prefersStatusBarHidden: Bool  {
        return false
    }

    override public var preferredStatusBarStyle: UIStatusBarStyle  {
        return .default
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Actions

    @IBAction public func onAddToCartButtonPressed(_ sender: UIButton)  {
    
    }

    @IBAction public func onGroup3TwoPressed(_ sender: UIButton)  {
    
    }

    @IBAction public func onGroup3Pressed(_ sender: UIButton)  {
    
    }
}
