/*
*  nearest_restaurant_widget.dart
*  Food UI Kit
*
*  Created by [Author].
*  Copyright © 2018 [Company]. All rights reserved.
    */

import 'package:flutter/material.dart';
import 'package:food_ui_kit/free_delivery_widget/free_delivery_widget.dart';
import 'package:food_ui_kit/values/values.dart';


class NearestRestaurantWidget extends StatelessWidget {
  
  void onNextPressed(BuildContext context) => Navigator.push(context, MaterialPageRoute(builder: (context) => FreeDeliveryWidget()));
  
  @override
  Widget build(BuildContext context) {
  
    return Scaffold(
      body: Container(
        constraints: BoxConstraints.expand(),
        decoration: BoxDecoration(
          color: Color.fromARGB(255, 255, 255, 255),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Align(
              alignment: Alignment.topLeft,
              child: Container(
                margin: EdgeInsets.only(left: 24, top: 103),
                child: Text(
                  "Order From Your\nNearest Rastaurent",
                  textAlign: TextAlign.left,
                  style: TextStyle(
                    color: AppColors.primaryText,
                    fontFamily: "Avenir",
                    fontWeight: FontWeight.w800,
                    fontSize: 24,
                    height: 1.41667,
                  ),
                ),
              ),
            ),
            Container(
              height: 314,
              margin: EdgeInsets.only(top: 44),
              child: Stack(
                alignment: Alignment.topRight,
                children: [
                  Positioned(
                    left: 1,
                    top: 0,
                    right: 1,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Align(
                          alignment: Alignment.topLeft,
                          child: Container(
                            width: 147,
                            height: 163,
                            margin: EdgeInsets.only(top: 10),
                            child: Image.asset(
                              "assets/images/shape-9.png",
                              fit: BoxFit.none,
                            ),
                          ),
                        ),
                        Spacer(),
                        Align(
                          alignment: Alignment.topLeft,
                          child: Container(
                            width: 148,
                            height: 163,
                            child: Image.asset(
                              "assets/images/group-copy.png",
                              fit: BoxFit.none,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Positioned(
                    left: 74,
                    top: 34,
                    child: Image.asset(
                      "assets/images/o-6.png",
                      fit: BoxFit.cover,
                    ),
                  ),
                  Positioned(
                    top: 96,
                    right: 101,
                    child: Image.asset(
                      "assets/images/search-2.png",
                      fit: BoxFit.none,
                    ),
                  ),
                  Positioned(
                    top: 131,
                    right: 182,
                    child: Image.asset(
                      "assets/images/restaurant.png",
                      fit: BoxFit.none,
                    ),
                  ),
                ],
              ),
            ),
            Spacer(),
            Align(
              alignment: Alignment.topCenter,
              child: Container(
                width: 327,
                height: 46,
                margin: EdgeInsets.only(bottom: 128),
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    Positioned(
                      left: 0,
                      right: 0,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Align(
                            alignment: Alignment.centerLeft,
                            child: Text(
                              "Skeep",
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: AppColors.primaryText,
                                fontFamily: "Avenir",
                                fontWeight: FontWeight.w800,
                                fontSize: 14,
                                height: 1,
                              ),
                            ),
                          ),
                          Spacer(),
                          Align(
                            alignment: Alignment.centerLeft,
                            child: Container(
                              width: 44,
                              height: 46,
                              child: FlatButton(
                                onPressed: () => this.onNextPressed(context),
                                color: Color.fromARGB(0, 0, 0, 0),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.all(Radius.circular(0)),
                                ),
                                textColor: Color.fromARGB(255, 0, 0, 0),
                                padding: EdgeInsets.all(0),
                                child: Text(
                                  "",
                                  textAlign: TextAlign.left,
                                  style: TextStyle(
                                    color: Color.fromARGB(255, 0, 0, 0),
                                    fontWeight: FontWeight.w400,
                                    fontSize: 12,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Positioned(
                      child: Image.asset(
                        "assets/images/group-3-6.png",
                        fit: BoxFit.none,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}