/*
*  offer_and_promos_widget.dart
*  Food UI Kit
*
*  Created by [Author].
*  Copyright © 2018 [Company]. All rights reserved.
    */

import 'package:flutter/material.dart';
import 'package:food_ui_kit/delivery_address_widget/delivery_address_widget.dart';
import 'package:food_ui_kit/my_previous_order_widget/my_previous_order_widget.dart';
import 'package:food_ui_kit/values/values.dart';


class OfferAndPromosWidget extends StatelessWidget {
  
  void onButtonPressed(BuildContext context) => Navigator.push(context, MaterialPageRoute(builder: (context) => MyPreviousOrderWidget()));
  
  void onButtonTwoPressed(BuildContext context) => Navigator.push(context, MaterialPageRoute(builder: (context) => MyPreviousOrderWidget()));
  
  void onButtonThreePressed(BuildContext context) => Navigator.push(context, MaterialPageRoute(builder: (context) => MyPreviousOrderWidget()));
  
  void onButtonFourPressed(BuildContext context) => Navigator.push(context, MaterialPageRoute(builder: (context) => MyPreviousOrderWidget()));
  
  void onButtonFivePressed(BuildContext context) => Navigator.push(context, MaterialPageRoute(builder: (context) => MyPreviousOrderWidget()));
  
  void onRectangleCopy8Pressed(BuildContext context) {
  
  }
  
  void onBackPressed(BuildContext context) => Navigator.push(context, MaterialPageRoute(builder: (context) => DeliveryAddressWidget()));
  
  @override
  Widget build(BuildContext context) {
  
    return Scaffold(
      body: Container(
        constraints: BoxConstraints.expand(),
        decoration: BoxDecoration(
          color: Color.fromARGB(255, 250, 250, 250),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              height: 81,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.end,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 129,
                    height: 22,
                    margin: EdgeInsets.only(left: 16),
                    child: Row(
                      children: [
                        Container(
                          width: 13,
                          height: 19,
                          child: FlatButton(
                            onPressed: () => this.onBackPressed(context),
                            color: Color.fromARGB(0, 0, 0, 0),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.all(Radius.circular(0)),
                            ),
                            textColor: Color.fromARGB(255, 0, 0, 0),
                            padding: EdgeInsets.all(0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Image.asset("assets/images/back-3.png",),
                                SizedBox(
                                  width: 10,
                                ),
                                Text(
                                  "",
                                  textAlign: TextAlign.left,
                                  style: TextStyle(
                                    color: Color.fromARGB(255, 0, 0, 0),
                                    fontWeight: FontWeight.w400,
                                    fontSize: 12,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Spacer(),
                        Text(
                          "My Coupon",
                          textAlign: TextAlign.left,
                          style: TextStyle(
                            color: AppColors.primaryText,
                            fontFamily: "Avenir",
                            fontWeight: FontWeight.w800,
                            fontSize: 16,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              height: 48,
              margin: EdgeInsets.only(left: 20, top: 38, right: 20),
              decoration: BoxDecoration(
                color: AppColors.secondaryElement,
                borderRadius: BorderRadius.all(Radius.circular(5)),
              ),
              child: Row(
                children: [
                  Container(
                    width: 167,
                    height: 48,
                    margin: EdgeInsets.only(left: 1),
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        Positioned(
                          left: 0,
                          child: FlatButton(
                            onPressed: () => this.onRectangleCopy8Pressed(context),
                            color: AppColors.primaryElement,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.all(Radius.circular(5)),
                            ),
                            textColor: Color.fromARGB(255, 0, 0, 0),
                            padding: EdgeInsets.all(0),
                            child: Text(
                              "",
                              textAlign: TextAlign.left,
                              style: TextStyle(
                                color: Color.fromARGB(255, 0, 0, 0),
                                fontWeight: FontWeight.w400,
                                fontSize: 12,
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          left: 57,
                          child: Text(
                            "Current",
                            textAlign: TextAlign.left,
                            style: TextStyle(
                              color: AppColors.primaryText,
                              fontFamily: "Avenir",
                              fontWeight: FontWeight.w800,
                              fontSize: 14,
                              height: 1,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Spacer(),
                  Container(
                    margin: EdgeInsets.only(right: 67),
                    child: Text(
                      "Used",
                      textAlign: TextAlign.left,
                      style: TextStyle(
                        color: AppColors.primaryText,
                        fontFamily: "Avenir",
                        fontWeight: FontWeight.w500,
                        fontSize: 14,
                        height: 1,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              height: 112,
              margin: EdgeInsets.only(top: 30, right: 6),
              child: Stack(
                alignment: Alignment.centerRight,
                children: [
                  Positioned(
                    left: 0,
                    top: 0,
                    right: 0,
                    bottom: 0,
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        Positioned(
                          left: 17,
                          right: 17,
                          child: Container(
                            height: 112,
                            decoration: BoxDecoration(
                              color: AppColors.primaryBackground,
                              boxShadow: [
                                BoxShadow(
                                  color: Color.fromARGB(89, 211, 217, 227),
                                  offset: Offset(0, 0),
                                  blurRadius: 7,
                                ),
                              ],
                              borderRadius: BorderRadius.all(Radius.circular(9)),
                            ),
                            child: Container(),
                          ),
                        ),
                        Positioned(
                          left: 17,
                          top: 0,
                          right: 0,
                          bottom: 0,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Align(
                                alignment: Alignment.centerLeft,
                                child: Container(
                                  width: 124,
                                  height: 112,
                                  decoration: BoxDecoration(
                                    color: Color.fromARGB(255, 255, 245, 176),
                                    borderRadius: BorderRadius.all(Radius.circular(9)),
                                  ),
                                  child: Container(),
                                ),
                              ),
                              Spacer(),
                              Align(
                                alignment: Alignment.topLeft,
                                child: Container(
                                  width: 126,
                                  height: 79,
                                  margin: EdgeInsets.only(top: 11, right: 32),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.stretch,
                                    children: [
                                      Align(
                                        alignment: Alignment.topRight,
                                        child: Container(
                                          margin: EdgeInsets.only(right: 50),
                                          child: Text(
                                            "Burger King",
                                            textAlign: TextAlign.left,
                                            style: TextStyle(
                                              color: AppColors.primaryText,
                                              fontFamily: "Avenir",
                                              fontWeight: FontWeight.w500,
                                              fontSize: 14,
                                              height: 1,
                                            ),
                                          ),
                                        ),
                                      ),
                                      Align(
                                        alignment: Alignment.topRight,
                                        child: Container(
                                          margin: EdgeInsets.only(top: 4, right: 39),
                                          child: Text(
                                            "\$10 Off",
                                            textAlign: TextAlign.left,
                                            style: TextStyle(
                                              color: AppColors.primaryText,
                                              fontFamily: "Avenir",
                                              fontWeight: FontWeight.w800,
                                              fontSize: 24,
                                              height: 0.91667,
                                            ),
                                          ),
                                        ),
                                      ),
                                      Align(
                                        alignment: Alignment.topRight,
                                        child: Container(
                                          margin: EdgeInsets.only(top: 5),
                                          child: Opacity(
                                            opacity: 0.59961,
                                            child: Text(
                                              "Valid until 20 May 2020",
                                              textAlign: TextAlign.left,
                                              style: TextStyle(
                                                color: AppColors.primaryText,
                                                fontFamily: "Avenir",
                                                fontWeight: FontWeight.w400,
                                                fontSize: 12,
                                                height: 1.16667,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Container(
                                width: 26,
                                margin: EdgeInsets.symmetric(vertical: 10),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.stretch,
                                  children: [
                                    Align(
                                      alignment: Alignment.topRight,
                                      child: Container(
                                        width: 26,
                                        height: 26,
                                        decoration: BoxDecoration(
                                          color: AppColors.accentElement,
                                          borderRadius: BorderRadius.all(Radius.circular(13)),
                                        ),
                                        child: Container(),
                                      ),
                                    ),
                                    Spacer(),
                                    Align(
                                      alignment: Alignment.topRight,
                                      child: Container(
                                        width: 26,
                                        height: 26,
                                        decoration: BoxDecoration(
                                          color: AppColors.accentElement,
                                          borderRadius: BorderRadius.all(Radius.circular(13)),
                                        ),
                                        child: Container(),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        Positioned(
                          left: 0,
                          child: Container(
                            width: 26,
                            height: 26,
                            decoration: BoxDecoration(
                              color: AppColors.accentElement,
                              borderRadius: BorderRadius.all(Radius.circular(13)),
                            ),
                            child: Container(),
                          ),
                        ),
                        Positioned(
                          left: 41,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Container(
                                height: 44,
                                margin: EdgeInsets.symmetric(horizontal: 18),
                                child: Image.asset(
                                  "assets/images/logo-4.png",
                                  fit: BoxFit.none,
                                ),
                              ),
                              Spacer(),
                              Container(
                                height: 24,
                                child: FlatButton(
                                  onPressed: () => this.onButtonPressed(context),
                                  color: AppColors.primaryElement,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.all(Radius.circular(3)),
                                  ),
                                  textColor: Color.fromARGB(255, 66, 80, 96),
                                  padding: EdgeInsets.all(0),
                                  child: Text(
                                    "Collect",
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      color: Color.fromARGB(255, 66, 80, 96),
                                      fontFamily: "Avenir",
                                      fontWeight: FontWeight.w800,
                                      fontSize: 12,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Positioned(
                    right: 0,
                    child: Container(
                      width: 26,
                      height: 26,
                      decoration: BoxDecoration(
                        color: AppColors.accentElement,
                        borderRadius: BorderRadius.all(Radius.circular(13)),
                      ),
                      child: Container(),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              height: 112,
              margin: EdgeInsets.only(left: 3, top: 15, right: 3),
              child: Stack(
                alignment: Alignment.centerRight,
                children: [
                  Positioned(
                    left: 0,
                    top: 0,
                    right: 0,
                    bottom: 0,
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        Positioned(
                          left: 17,
                          right: 17,
                          child: Container(
                            height: 112,
                            decoration: BoxDecoration(
                              color: AppColors.primaryBackground,
                              boxShadow: [
                                BoxShadow(
                                  color: Color.fromARGB(89, 211, 217, 227),
                                  offset: Offset(0, 0),
                                  blurRadius: 7,
                                ),
                              ],
                              borderRadius: BorderRadius.all(Radius.circular(9)),
                            ),
                            child: Container(),
                          ),
                        ),
                        Positioned(
                          left: 17,
                          top: 0,
                          right: 0,
                          bottom: 0,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Align(
                                alignment: Alignment.centerLeft,
                                child: Container(
                                  width: 124,
                                  height: 112,
                                  decoration: BoxDecoration(
                                    color: Color.fromARGB(255, 255, 245, 176),
                                    borderRadius: BorderRadius.all(Radius.circular(9)),
                                  ),
                                  child: Container(),
                                ),
                              ),
                              Spacer(),
                              Align(
                                alignment: Alignment.topLeft,
                                child: Container(
                                  width: 126,
                                  height: 79,
                                  margin: EdgeInsets.only(top: 11, right: 32),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.stretch,
                                    children: [
                                      Align(
                                        alignment: Alignment.topRight,
                                        child: Container(
                                          margin: EdgeInsets.only(right: 24),
                                          child: Text(
                                            "Grinders Burger",
                                            textAlign: TextAlign.left,
                                            style: TextStyle(
                                              color: AppColors.primaryText,
                                              fontFamily: "Avenir",
                                              fontWeight: FontWeight.w500,
                                              fontSize: 14,
                                              height: 1,
                                            ),
                                          ),
                                        ),
                                      ),
                                      Align(
                                        alignment: Alignment.topRight,
                                        child: Container(
                                          margin: EdgeInsets.only(top: 4, right: 32),
                                          child: Text(
                                            "30% Off",
                                            textAlign: TextAlign.left,
                                            style: TextStyle(
                                              color: AppColors.primaryText,
                                              fontFamily: "Avenir",
                                              fontWeight: FontWeight.w800,
                                              fontSize: 24,
                                              height: 0.91667,
                                            ),
                                          ),
                                        ),
                                      ),
                                      Align(
                                        alignment: Alignment.topRight,
                                        child: Container(
                                          margin: EdgeInsets.only(top: 5),
                                          child: Opacity(
                                            opacity: 0.59961,
                                            child: Text(
                                              "Valid until 20 May 2020",
                                              textAlign: TextAlign.left,
                                              style: TextStyle(
                                                color: AppColors.primaryText,
                                                fontFamily: "Avenir",
                                                fontWeight: FontWeight.w400,
                                                fontSize: 12,
                                                height: 1.16667,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Container(
                                width: 26,
                                margin: EdgeInsets.symmetric(vertical: 10),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.stretch,
                                  children: [
                                    Align(
                                      alignment: Alignment.topRight,
                                      child: Container(
                                        width: 26,
                                        height: 26,
                                        decoration: BoxDecoration(
                                          color: AppColors.accentElement,
                                          borderRadius: BorderRadius.all(Radius.circular(13)),
                                        ),
                                        child: Container(),
                                      ),
                                    ),
                                    Spacer(),
                                    Align(
                                      alignment: Alignment.topRight,
                                      child: Container(
                                        width: 26,
                                        height: 26,
                                        decoration: BoxDecoration(
                                          color: AppColors.accentElement,
                                          borderRadius: BorderRadius.all(Radius.circular(13)),
                                        ),
                                        child: Container(),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        Positioned(
                          left: 0,
                          child: Container(
                            width: 26,
                            height: 26,
                            decoration: BoxDecoration(
                              color: AppColors.accentElement,
                              borderRadius: BorderRadius.all(Radius.circular(13)),
                            ),
                            child: Container(),
                          ),
                        ),
                        Positioned(
                          left: 41,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Container(
                                height: 44,
                                margin: EdgeInsets.symmetric(horizontal: 18),
                                child: Image.asset(
                                  "assets/images/logo-5.png",
                                  fit: BoxFit.none,
                                ),
                              ),
                              Spacer(),
                              Container(
                                height: 24,
                                child: FlatButton(
                                  onPressed: () => this.onButtonTwoPressed(context),
                                  color: AppColors.primaryElement,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.all(Radius.circular(3)),
                                  ),
                                  textColor: Color.fromARGB(255, 66, 80, 96),
                                  padding: EdgeInsets.all(0),
                                  child: Text(
                                    "Collect",
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      color: Color.fromARGB(255, 66, 80, 96),
                                      fontFamily: "Avenir",
                                      fontWeight: FontWeight.w800,
                                      fontSize: 12,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Positioned(
                    right: 0,
                    child: Container(
                      width: 26,
                      height: 26,
                      decoration: BoxDecoration(
                        color: AppColors.accentElement,
                        borderRadius: BorderRadius.all(Radius.circular(13)),
                      ),
                      child: Container(),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              height: 112,
              margin: EdgeInsets.only(left: 3, top: 15, right: 3),
              child: Stack(
                alignment: Alignment.centerRight,
                children: [
                  Positioned(
                    left: 0,
                    top: 0,
                    right: 0,
                    bottom: 0,
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        Positioned(
                          left: 17,
                          right: 17,
                          child: Container(
                            height: 112,
                            decoration: BoxDecoration(
                              color: AppColors.primaryBackground,
                              boxShadow: [
                                BoxShadow(
                                  color: Color.fromARGB(89, 211, 217, 227),
                                  offset: Offset(0, 0),
                                  blurRadius: 7,
                                ),
                              ],
                              borderRadius: BorderRadius.all(Radius.circular(9)),
                            ),
                            child: Container(),
                          ),
                        ),
                        Positioned(
                          left: 17,
                          top: 0,
                          right: 0,
                          bottom: 0,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Align(
                                alignment: Alignment.centerLeft,
                                child: Container(
                                  width: 124,
                                  height: 112,
                                  decoration: BoxDecoration(
                                    color: Color.fromARGB(255, 255, 245, 176),
                                    borderRadius: BorderRadius.all(Radius.circular(9)),
                                  ),
                                  child: Container(),
                                ),
                              ),
                              Spacer(),
                              Align(
                                alignment: Alignment.topLeft,
                                child: Container(
                                  width: 126,
                                  height: 79,
                                  margin: EdgeInsets.only(top: 11, right: 32),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.stretch,
                                    children: [
                                      Align(
                                        alignment: Alignment.topRight,
                                        child: Container(
                                          margin: EdgeInsets.only(right: 99),
                                          child: Text(
                                            "KFC",
                                            textAlign: TextAlign.left,
                                            style: TextStyle(
                                              color: AppColors.primaryText,
                                              fontFamily: "Avenir",
                                              fontWeight: FontWeight.w500,
                                              fontSize: 14,
                                              height: 1,
                                            ),
                                          ),
                                        ),
                                      ),
                                      Align(
                                        alignment: Alignment.topRight,
                                        child: Container(
                                          margin: EdgeInsets.only(top: 4, right: 39),
                                          child: Text(
                                            "\$20 Off",
                                            textAlign: TextAlign.left,
                                            style: TextStyle(
                                              color: AppColors.primaryText,
                                              fontFamily: "Avenir",
                                              fontWeight: FontWeight.w800,
                                              fontSize: 24,
                                              height: 0.91667,
                                            ),
                                          ),
                                        ),
                                      ),
                                      Align(
                                        alignment: Alignment.topRight,
                                        child: Container(
                                          margin: EdgeInsets.only(top: 5),
                                          child: Opacity(
                                            opacity: 0.59961,
                                            child: Text(
                                              "Valid until 20 May 2020",
                                              textAlign: TextAlign.left,
                                              style: TextStyle(
                                                color: AppColors.primaryText,
                                                fontFamily: "Avenir",
                                                fontWeight: FontWeight.w400,
                                                fontSize: 12,
                                                height: 1.16667,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Container(
                                width: 26,
                                margin: EdgeInsets.symmetric(vertical: 10),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.stretch,
                                  children: [
                                    Align(
                                      alignment: Alignment.topRight,
                                      child: Container(
                                        width: 26,
                                        height: 26,
                                        decoration: BoxDecoration(
                                          color: AppColors.accentElement,
                                          borderRadius: BorderRadius.all(Radius.circular(13)),
                                        ),
                                        child: Container(),
                                      ),
                                    ),
                                    Spacer(),
                                    Align(
                                      alignment: Alignment.topRight,
                                      child: Container(
                                        width: 26,
                                        height: 26,
                                        decoration: BoxDecoration(
                                          color: AppColors.accentElement,
                                          borderRadius: BorderRadius.all(Radius.circular(13)),
                                        ),
                                        child: Container(),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        Positioned(
                          left: 0,
                          child: Container(
                            width: 26,
                            height: 26,
                            decoration: BoxDecoration(
                              color: AppColors.accentElement,
                              borderRadius: BorderRadius.all(Radius.circular(13)),
                            ),
                            child: Container(),
                          ),
                        ),
                        Positioned(
                          left: 41,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Container(
                                height: 44,
                                margin: EdgeInsets.symmetric(horizontal: 18),
                                child: Image.asset(
                                  "assets/images/logo-2.png",
                                  fit: BoxFit.none,
                                ),
                              ),
                              Spacer(),
                              Container(
                                height: 24,
                                child: FlatButton(
                                  onPressed: () => this.onButtonThreePressed(context),
                                  color: AppColors.primaryElement,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.all(Radius.circular(3)),
                                  ),
                                  textColor: Color.fromARGB(255, 66, 80, 96),
                                  padding: EdgeInsets.all(0),
                                  child: Text(
                                    "Collect",
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      color: Color.fromARGB(255, 66, 80, 96),
                                      fontFamily: "Avenir",
                                      fontWeight: FontWeight.w800,
                                      fontSize: 12,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Positioned(
                    right: 0,
                    child: Container(
                      width: 26,
                      height: 26,
                      decoration: BoxDecoration(
                        color: AppColors.accentElement,
                        borderRadius: BorderRadius.all(Radius.circular(13)),
                      ),
                      child: Container(),
                    ),
                  ),
                ],
              ),
            ),
            Spacer(),
            Container(
              height: 112,
              margin: EdgeInsets.only(left: 3, right: 3, bottom: 15),
              child: Stack(
                alignment: Alignment.centerRight,
                children: [
                  Positioned(
                    left: 0,
                    top: 0,
                    right: 0,
                    bottom: 0,
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        Positioned(
                          left: 17,
                          right: 17,
                          child: Container(
                            height: 112,
                            decoration: BoxDecoration(
                              color: AppColors.primaryBackground,
                              boxShadow: [
                                BoxShadow(
                                  color: Color.fromARGB(89, 211, 217, 227),
                                  offset: Offset(0, 0),
                                  blurRadius: 7,
                                ),
                              ],
                              borderRadius: BorderRadius.all(Radius.circular(9)),
                            ),
                            child: Container(),
                          ),
                        ),
                        Positioned(
                          left: 17,
                          top: 0,
                          right: 0,
                          bottom: 0,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Align(
                                alignment: Alignment.centerLeft,
                                child: Container(
                                  width: 124,
                                  height: 112,
                                  decoration: BoxDecoration(
                                    color: Color.fromARGB(255, 255, 245, 176),
                                    borderRadius: BorderRadius.all(Radius.circular(9)),
                                  ),
                                  child: Container(),
                                ),
                              ),
                              Spacer(),
                              Align(
                                alignment: Alignment.topLeft,
                                child: Container(
                                  width: 126,
                                  height: 79,
                                  margin: EdgeInsets.only(top: 11, right: 32),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.stretch,
                                    children: [
                                      Align(
                                        alignment: Alignment.topRight,
                                        child: Container(
                                          margin: EdgeInsets.only(right: 50),
                                          child: Text(
                                            "Burger King",
                                            textAlign: TextAlign.left,
                                            style: TextStyle(
                                              color: AppColors.primaryText,
                                              fontFamily: "Avenir",
                                              fontWeight: FontWeight.w500,
                                              fontSize: 14,
                                              height: 1,
                                            ),
                                          ),
                                        ),
                                      ),
                                      Align(
                                        alignment: Alignment.topRight,
                                        child: Container(
                                          margin: EdgeInsets.only(top: 4, right: 32),
                                          child: Text(
                                            "50% Off",
                                            textAlign: TextAlign.left,
                                            style: TextStyle(
                                              color: AppColors.primaryText,
                                              fontFamily: "Avenir",
                                              fontWeight: FontWeight.w800,
                                              fontSize: 24,
                                              height: 0.91667,
                                            ),
                                          ),
                                        ),
                                      ),
                                      Align(
                                        alignment: Alignment.topRight,
                                        child: Container(
                                          margin: EdgeInsets.only(top: 5),
                                          child: Opacity(
                                            opacity: 0.59961,
                                            child: Text(
                                              "Valid until 20 May 2020",
                                              textAlign: TextAlign.left,
                                              style: TextStyle(
                                                color: AppColors.primaryText,
                                                fontFamily: "Avenir",
                                                fontWeight: FontWeight.w400,
                                                fontSize: 12,
                                                height: 1.16667,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Container(
                                width: 26,
                                margin: EdgeInsets.symmetric(vertical: 10),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.stretch,
                                  children: [
                                    Align(
                                      alignment: Alignment.topRight,
                                      child: Container(
                                        width: 26,
                                        height: 26,
                                        decoration: BoxDecoration(
                                          color: AppColors.accentElement,
                                          borderRadius: BorderRadius.all(Radius.circular(13)),
                                        ),
                                        child: Container(),
                                      ),
                                    ),
                                    Spacer(),
                                    Align(
                                      alignment: Alignment.topRight,
                                      child: Container(
                                        width: 26,
                                        height: 26,
                                        decoration: BoxDecoration(
                                          color: AppColors.accentElement,
                                          borderRadius: BorderRadius.all(Radius.circular(13)),
                                        ),
                                        child: Container(),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        Positioned(
                          left: 0,
                          child: Container(
                            width: 26,
                            height: 26,
                            decoration: BoxDecoration(
                              color: AppColors.accentElement,
                              borderRadius: BorderRadius.all(Radius.circular(13)),
                            ),
                            child: Container(),
                          ),
                        ),
                        Positioned(
                          left: 41,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Container(
                                height: 44,
                                margin: EdgeInsets.symmetric(horizontal: 18),
                                child: Image.asset(
                                  "assets/images/logo.png",
                                  fit: BoxFit.none,
                                ),
                              ),
                              Spacer(),
                              Container(
                                height: 24,
                                child: FlatButton(
                                  onPressed: () => this.onButtonFourPressed(context),
                                  color: AppColors.primaryElement,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.all(Radius.circular(3)),
                                  ),
                                  textColor: Color.fromARGB(255, 66, 80, 96),
                                  padding: EdgeInsets.all(0),
                                  child: Text(
                                    "Collect",
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      color: Color.fromARGB(255, 66, 80, 96),
                                      fontFamily: "Avenir",
                                      fontWeight: FontWeight.w800,
                                      fontSize: 12,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Positioned(
                    right: 0,
                    child: Container(
                      width: 26,
                      height: 26,
                      decoration: BoxDecoration(
                        color: AppColors.accentElement,
                        borderRadius: BorderRadius.all(Radius.circular(13)),
                      ),
                      child: Container(),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              height: 112,
              margin: EdgeInsets.symmetric(horizontal: 3),
              child: Stack(
                alignment: Alignment.centerRight,
                children: [
                  Positioned(
                    left: 0,
                    top: 0,
                    right: 0,
                    bottom: 0,
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        Positioned(
                          left: 17,
                          right: 17,
                          child: Container(
                            height: 112,
                            decoration: BoxDecoration(
                              color: AppColors.primaryBackground,
                              boxShadow: [
                                BoxShadow(
                                  color: Color.fromARGB(89, 211, 217, 227),
                                  offset: Offset(0, 0),
                                  blurRadius: 7,
                                ),
                              ],
                              borderRadius: BorderRadius.all(Radius.circular(9)),
                            ),
                            child: Container(),
                          ),
                        ),
                        Positioned(
                          left: 17,
                          top: 0,
                          right: 0,
                          bottom: 0,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Align(
                                alignment: Alignment.centerLeft,
                                child: Container(
                                  width: 124,
                                  height: 112,
                                  decoration: BoxDecoration(
                                    color: Color.fromARGB(255, 255, 245, 176),
                                    borderRadius: BorderRadius.all(Radius.circular(9)),
                                  ),
                                  child: Container(),
                                ),
                              ),
                              Spacer(),
                              Align(
                                alignment: Alignment.topLeft,
                                child: Container(
                                  width: 126,
                                  height: 79,
                                  margin: EdgeInsets.only(top: 11, right: 32),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.stretch,
                                    children: [
                                      Align(
                                        alignment: Alignment.topRight,
                                        child: Container(
                                          margin: EdgeInsets.only(right: 50),
                                          child: Text(
                                            "Burger King",
                                            textAlign: TextAlign.left,
                                            style: TextStyle(
                                              color: AppColors.primaryText,
                                              fontFamily: "Avenir",
                                              fontWeight: FontWeight.w500,
                                              fontSize: 14,
                                              height: 1,
                                            ),
                                          ),
                                        ),
                                      ),
                                      Align(
                                        alignment: Alignment.topRight,
                                        child: Container(
                                          margin: EdgeInsets.only(top: 4, right: 39),
                                          child: Text(
                                            "\$40 Off",
                                            textAlign: TextAlign.left,
                                            style: TextStyle(
                                              color: AppColors.primaryText,
                                              fontFamily: "Avenir",
                                              fontWeight: FontWeight.w800,
                                              fontSize: 24,
                                              height: 0.91667,
                                            ),
                                          ),
                                        ),
                                      ),
                                      Align(
                                        alignment: Alignment.topRight,
                                        child: Container(
                                          margin: EdgeInsets.only(top: 5),
                                          child: Opacity(
                                            opacity: 0.59961,
                                            child: Text(
                                              "Valid until 20 May 2020",
                                              textAlign: TextAlign.left,
                                              style: TextStyle(
                                                color: AppColors.primaryText,
                                                fontFamily: "Avenir",
                                                fontWeight: FontWeight.w400,
                                                fontSize: 12,
                                                height: 1.16667,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Container(
                                width: 26,
                                margin: EdgeInsets.symmetric(vertical: 10),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.stretch,
                                  children: [
                                    Align(
                                      alignment: Alignment.topRight,
                                      child: Container(
                                        width: 26,
                                        height: 26,
                                        decoration: BoxDecoration(
                                          color: AppColors.accentElement,
                                          borderRadius: BorderRadius.all(Radius.circular(13)),
                                        ),
                                        child: Container(),
                                      ),
                                    ),
                                    Spacer(),
                                    Align(
                                      alignment: Alignment.topRight,
                                      child: Container(
                                        width: 26,
                                        height: 26,
                                        decoration: BoxDecoration(
                                          color: AppColors.accentElement,
                                          borderRadius: BorderRadius.all(Radius.circular(13)),
                                        ),
                                        child: Container(),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        Positioned(
                          left: 0,
                          child: Container(
                            width: 26,
                            height: 26,
                            decoration: BoxDecoration(
                              color: AppColors.accentElement,
                              borderRadius: BorderRadius.all(Radius.circular(13)),
                            ),
                            child: Container(),
                          ),
                        ),
                        Positioned(
                          left: 41,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Container(
                                height: 44,
                                margin: EdgeInsets.symmetric(horizontal: 18),
                                child: Image.asset(
                                  "assets/images/logo-3.png",
                                  fit: BoxFit.none,
                                ),
                              ),
                              Spacer(),
                              Container(
                                height: 24,
                                child: FlatButton(
                                  onPressed: () => this.onButtonFivePressed(context),
                                  color: AppColors.primaryElement,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.all(Radius.circular(3)),
                                  ),
                                  textColor: Color.fromARGB(255, 66, 80, 96),
                                  padding: EdgeInsets.all(0),
                                  child: Text(
                                    "Collect",
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      color: Color.fromARGB(255, 66, 80, 96),
                                      fontFamily: "Avenir",
                                      fontWeight: FontWeight.w800,
                                      fontSize: 12,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Positioned(
                    right: 0,
                    child: Container(
                      width: 26,
                      height: 26,
                      decoration: BoxDecoration(
                        color: AppColors.accentElement,
                        borderRadius: BorderRadius.all(Radius.circular(13)),
                      ),
                      child: Container(),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}