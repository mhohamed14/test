/*
*  burger_order_app_cart_widget.dart
*  Food UI Kit
*
*  Created by [Author].
*  Copyright © 2018 [Company]. All rights reserved.
    */

import 'package:flutter/material.dart';
import 'package:food_ui_kit/cart_delete_widget/cart_delete_widget.dart';
import 'package:food_ui_kit/user_review_widget/user_review_widget.dart';
import 'package:food_ui_kit/values/values.dart';


class BurgerOrderAppCartWidget extends StatelessWidget {
  
  void onGroup8Pressed(BuildContext context) {
  
  }
  
  void onGroup8TwoPressed(BuildContext context) {
  
  }
  
  void onNextPressed(BuildContext context) => Navigator.push(context, MaterialPageRoute(builder: (context) => CartDeleteWidget()));
  
  void onGroupPressed(BuildContext context) => Navigator.push(context, MaterialPageRoute(builder: (context) => UserReviewWidget()));
  
  @override
  Widget build(BuildContext context) {
  
    return Scaffold(
      body: Container(
        constraints: BoxConstraints.expand(),
        decoration: BoxDecoration(
          color: Color.fromARGB(255, 255, 255, 255),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              height: 81,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.end,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    height: 22,
                    margin: EdgeInsets.symmetric(horizontal: 16),
                    child: Row(
                      children: [
                        Container(
                          width: 11,
                          height: 17,
                          child: FlatButton(
                            onPressed: () => this.onNextPressed(context),
                            color: Color.fromARGB(0, 0, 0, 0),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.all(Radius.circular(0)),
                            ),
                            textColor: Color.fromARGB(255, 0, 0, 0),
                            padding: EdgeInsets.all(0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Image.asset("assets/images/back-2.png",),
                                SizedBox(
                                  width: 10,
                                ),
                                Text(
                                  "",
                                  textAlign: TextAlign.left,
                                  style: TextStyle(
                                    color: Color.fromARGB(255, 0, 0, 0),
                                    fontWeight: FontWeight.w400,
                                    fontSize: 12,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.only(left: 30),
                          child: Text(
                            "My Cart List",
                            textAlign: TextAlign.left,
                            style: TextStyle(
                              color: AppColors.primaryText,
                              fontFamily: "Avenir",
                              fontWeight: FontWeight.w800,
                              fontSize: 16,
                            ),
                          ),
                        ),
                        Spacer(),
                        Container(
                          width: 4,
                          height: 17,
                          child: Image.asset(
                            "assets/images/group-6-2.png",
                            fit: BoxFit.none,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              height: 574,
              margin: EdgeInsets.only(top: 30),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    height: 106,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Container(
                          height: 90,
                          margin: EdgeInsets.only(left: 16, right: 18),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Align(
                                alignment: Alignment.topLeft,
                                child: Container(
                                  width: 105,
                                  height: 90,
                                  child: Stack(
                                    alignment: Alignment.center,
                                    children: [
                                      Positioned(
                                        left: 0,
                                        top: 0,
                                        child: Container(
                                          width: 84,
                                          height: 90,
                                          decoration: BoxDecoration(
                                            color: Color.fromARGB(255, 243, 243, 243),
                                            borderRadius: BorderRadius.all(Radius.circular(22)),
                                          ),
                                          child: Container(),
                                        ),
                                      ),
                                      Positioned(
                                        left: 15,
                                        top: 11,
                                        child: Image.asset(
                                          "assets/images/burger-10956-4.png",
                                          fit: BoxFit.none,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Spacer(),
                              Align(
                                alignment: Alignment.topLeft,
                                child: Container(
                                  width: 217,
                                  height: 57,
                                  margin: EdgeInsets.only(top: 15),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.stretch,
                                    children: [
                                      Align(
                                        alignment: Alignment.topLeft,
                                        child: Text(
                                          "Mushroom Burgers",
                                          textAlign: TextAlign.left,
                                          style: TextStyle(
                                            color: AppColors.primaryText,
                                            fontFamily: "Avenir",
                                            fontWeight: FontWeight.w800,
                                            fontSize: 14,
                                          ),
                                        ),
                                      ),
                                      Spacer(),
                                      Container(
                                        height: 25,
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.stretch,
                                          children: [
                                            Align(
                                              alignment: Alignment.bottomLeft,
                                              child: Container(
                                                width: 80,
                                                height: 20,
                                                margin: EdgeInsets.only(bottom: 2),
                                                child: Stack(
                                                  alignment: Alignment.center,
                                                  children: [
                                                    Positioned(
                                                      left: 0,
                                                      right: 0,
                                                      child: Row(
                                                        crossAxisAlignment: CrossAxisAlignment.stretch,
                                                        children: [
                                                          Align(
                                                            alignment: Alignment.centerLeft,
                                                            child: Container(
                                                              width: 20,
                                                              height: 20,
                                                              decoration: BoxDecoration(
                                                                border: Border.fromBorderSide(Borders.secondaryBorder),
                                                                borderRadius: BorderRadius.all(Radius.circular(10)),
                                                              ),
                                                              child: Column(
                                                                mainAxisAlignment: MainAxisAlignment.center,
                                                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                                                children: [
                                                                  Container(
                                                                    height: 2,
                                                                    margin: EdgeInsets.symmetric(horizontal: 5),
                                                                    child: Image.asset(
                                                                      "assets/images/group-8-2.png",
                                                                      fit: BoxFit.none,
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                          Spacer(),
                                                          Align(
                                                            alignment: Alignment.centerLeft,
                                                            child: Container(
                                                              width: 20,
                                                              height: 20,
                                                              decoration: BoxDecoration(
                                                                border: Border.all(
                                                                  width: 1,
                                                                  color: Color.fromARGB(255, 243, 243, 243),
                                                                ),
                                                                borderRadius: BorderRadius.all(Radius.circular(10)),
                                                              ),
                                                              child: Column(
                                                                mainAxisAlignment: MainAxisAlignment.center,
                                                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                                                children: [
                                                                  Container(
                                                                    height: 11,
                                                                    margin: EdgeInsets.symmetric(horizontal: 5),
                                                                    child: Image.asset(
                                                                      "assets/images/group-8-3.png",
                                                                      fit: BoxFit.none,
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    Positioned(
                                                      child: Text(
                                                        "3",
                                                        textAlign: TextAlign.center,
                                                        style: TextStyle(
                                                          color: AppColors.primaryText,
                                                          fontFamily: "Avenir",
                                                          fontWeight: FontWeight.w800,
                                                          fontSize: 16,
                                                          height: 1,
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                            Spacer(),
                                            Align(
                                              alignment: Alignment.bottomLeft,
                                              child: Text(
                                                "\$30.20",
                                                textAlign: TextAlign.left,
                                                style: TextStyle(
                                                  color: AppColors.primaryText,
                                                  fontFamily: "Avenir",
                                                  fontWeight: FontWeight.w800,
                                                  fontSize: 18,
                                                  height: 0.88889,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Spacer(),
                        Container(
                          height: 1,
                          decoration: BoxDecoration(
                            color: Color.fromARGB(255, 243, 243, 243),
                            borderRadius: BorderRadius.all(Radius.circular(0.5)),
                          ),
                          child: Container(),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    height: 106,
                    margin: EdgeInsets.only(top: 15),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Container(
                          height: 90,
                          margin: EdgeInsets.only(left: 16, right: 24),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Align(
                                alignment: Alignment.topLeft,
                                child: Container(
                                  width: 99,
                                  height: 90,
                                  child: Stack(
                                    alignment: Alignment.center,
                                    children: [
                                      Positioned(
                                        left: 0,
                                        top: 0,
                                        child: Container(
                                          width: 84,
                                          height: 90,
                                          decoration: BoxDecoration(
                                            color: Color.fromARGB(255, 243, 243, 243),
                                            borderRadius: BorderRadius.all(Radius.circular(22)),
                                          ),
                                          child: Container(),
                                        ),
                                      ),
                                      Positioned(
                                        left: 10,
                                        top: 15,
                                        child: Image.asset(
                                          "assets/images/burger-10917.png",
                                          fit: BoxFit.none,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Expanded(
                                flex: 1,
                                child: Align(
                                  alignment: Alignment.topLeft,
                                  child: Container(
                                    height: 59,
                                    margin: EdgeInsets.only(left: 25, top: 15),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.stretch,
                                      children: [
                                        Align(
                                          alignment: Alignment.topRight,
                                          child: Container(
                                            margin: EdgeInsets.only(right: 108),
                                            child: Text(
                                              "Salmon Burgers",
                                              textAlign: TextAlign.left,
                                              style: TextStyle(
                                                color: AppColors.primaryText,
                                                fontFamily: "Avenir",
                                                fontWeight: FontWeight.w800,
                                                fontSize: 14,
                                              ),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          height: 25,
                                          margin: EdgeInsets.only(top: 15),
                                          child: Row(
                                            crossAxisAlignment: CrossAxisAlignment.stretch,
                                            children: [
                                              Align(
                                                alignment: Alignment.topLeft,
                                                child: Container(
                                                  width: 80,
                                                  height: 20,
                                                  margin: EdgeInsets.only(top: 3),
                                                  child: Stack(
                                                    alignment: Alignment.center,
                                                    children: [
                                                      Positioned(
                                                        left: 0,
                                                        right: 0,
                                                        child: Row(
                                                          crossAxisAlignment: CrossAxisAlignment.stretch,
                                                          children: [
                                                            Align(
                                                              alignment: Alignment.centerLeft,
                                                              child: Container(
                                                                width: 20,
                                                                height: 20,
                                                                decoration: BoxDecoration(
                                                                  border: Border.fromBorderSide(Borders.secondaryBorder),
                                                                  borderRadius: BorderRadius.all(Radius.circular(10)),
                                                                ),
                                                                child: Column(
                                                                  mainAxisAlignment: MainAxisAlignment.center,
                                                                  crossAxisAlignment: CrossAxisAlignment.stretch,
                                                                  children: [
                                                                    Container(
                                                                      height: 2,
                                                                      margin: EdgeInsets.symmetric(horizontal: 5),
                                                                      child: FlatButton(
                                                                        onPressed: () => this.onGroup8TwoPressed(context),
                                                                        color: Color.fromARGB(0, 0, 0, 0),
                                                                        shape: RoundedRectangleBorder(
                                                                          borderRadius: BorderRadius.all(Radius.circular(0)),
                                                                        ),
                                                                        textColor: Color.fromARGB(255, 0, 0, 0),
                                                                        padding: EdgeInsets.all(0),
                                                                        child: Row(
                                                                          mainAxisAlignment: MainAxisAlignment.center,
                                                                          children: [
                                                                            Image.asset("assets/images/group-8-2.png",),
                                                                            SizedBox(
                                                                              width: 10,
                                                                            ),
                                                                            Text(
                                                                              "",
                                                                              textAlign: TextAlign.left,
                                                                              style: TextStyle(
                                                                                color: Color.fromARGB(255, 0, 0, 0),
                                                                                fontWeight: FontWeight.w400,
                                                                                fontSize: 12,
                                                                              ),
                                                                            ),
                                                                          ],
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ),
                                                            ),
                                                            Spacer(),
                                                            Align(
                                                              alignment: Alignment.centerLeft,
                                                              child: Container(
                                                                width: 20,
                                                                height: 20,
                                                                decoration: BoxDecoration(
                                                                  border: Border.fromBorderSide(Borders.secondaryBorder),
                                                                  borderRadius: BorderRadius.all(Radius.circular(10)),
                                                                ),
                                                                child: Column(
                                                                  mainAxisAlignment: MainAxisAlignment.center,
                                                                  crossAxisAlignment: CrossAxisAlignment.stretch,
                                                                  children: [
                                                                    Container(
                                                                      height: 11,
                                                                      margin: EdgeInsets.symmetric(horizontal: 5),
                                                                      child: FlatButton(
                                                                        onPressed: () => this.onGroup8Pressed(context),
                                                                        color: Color.fromARGB(0, 0, 0, 0),
                                                                        shape: RoundedRectangleBorder(
                                                                          borderRadius: BorderRadius.all(Radius.circular(0)),
                                                                        ),
                                                                        textColor: Color.fromARGB(255, 0, 0, 0),
                                                                        padding: EdgeInsets.all(0),
                                                                        child: Row(
                                                                          mainAxisAlignment: MainAxisAlignment.center,
                                                                          children: [
                                                                            Image.asset("assets/images/group-8-3.png",),
                                                                            SizedBox(
                                                                              width: 10,
                                                                            ),
                                                                            Text(
                                                                              "",
                                                                              textAlign: TextAlign.left,
                                                                              style: TextStyle(
                                                                                color: Color.fromARGB(255, 0, 0, 0),
                                                                                fontWeight: FontWeight.w400,
                                                                                fontSize: 12,
                                                                              ),
                                                                            ),
                                                                          ],
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                      Positioned(
                                                        child: Text(
                                                          "2",
                                                          textAlign: TextAlign.center,
                                                          style: TextStyle(
                                                            color: AppColors.primaryText,
                                                            fontFamily: "Avenir",
                                                            fontWeight: FontWeight.w800,
                                                            fontSize: 16,
                                                            height: 1,
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Spacer(),
                                              Align(
                                                alignment: Alignment.topLeft,
                                                child: Text(
                                                  "\$25.30",
                                                  textAlign: TextAlign.left,
                                                  style: TextStyle(
                                                    color: AppColors.primaryText,
                                                    fontFamily: "Avenir",
                                                    fontWeight: FontWeight.w800,
                                                    fontSize: 18,
                                                    height: 0.88889,
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Spacer(),
                        Container(
                          height: 1,
                          decoration: BoxDecoration(
                            color: Color.fromARGB(255, 243, 243, 243),
                            borderRadius: BorderRadius.all(Radius.circular(0.5)),
                          ),
                          child: Container(),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    height: 106,
                    margin: EdgeInsets.only(top: 15),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Container(
                          height: 90,
                          margin: EdgeInsets.only(left: 16, right: 18),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Align(
                                alignment: Alignment.topLeft,
                                child: Container(
                                  width: 102,
                                  height: 90,
                                  child: Stack(
                                    alignment: Alignment.center,
                                    children: [
                                      Positioned(
                                        left: 0,
                                        top: 0,
                                        child: Container(
                                          width: 84,
                                          height: 90,
                                          decoration: BoxDecoration(
                                            color: Color.fromARGB(255, 243, 243, 243),
                                            borderRadius: BorderRadius.all(Radius.circular(22)),
                                          ),
                                          child: Container(),
                                        ),
                                      ),
                                      Positioned(
                                        left: 12,
                                        top: 12,
                                        child: Image.asset(
                                          "assets/images/http-pluspngcom-img-png-png-hd-pizza-download-1356-2.png",
                                          fit: BoxFit.none,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Spacer(),
                              Align(
                                alignment: Alignment.topLeft,
                                child: Container(
                                  width: 217,
                                  height: 57,
                                  margin: EdgeInsets.only(top: 15),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.stretch,
                                    children: [
                                      Align(
                                        alignment: Alignment.topLeft,
                                        child: Text(
                                          "Chicago Pizza",
                                          textAlign: TextAlign.left,
                                          style: TextStyle(
                                            color: AppColors.primaryText,
                                            fontFamily: "Avenir",
                                            fontWeight: FontWeight.w800,
                                            fontSize: 14,
                                          ),
                                        ),
                                      ),
                                      Spacer(),
                                      Container(
                                        height: 25,
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.stretch,
                                          children: [
                                            Align(
                                              alignment: Alignment.bottomLeft,
                                              child: Container(
                                                width: 80,
                                                height: 20,
                                                margin: EdgeInsets.only(bottom: 2),
                                                child: Stack(
                                                  alignment: Alignment.center,
                                                  children: [
                                                    Positioned(
                                                      left: 0,
                                                      right: 0,
                                                      child: Row(
                                                        crossAxisAlignment: CrossAxisAlignment.stretch,
                                                        children: [
                                                          Align(
                                                            alignment: Alignment.centerLeft,
                                                            child: Container(
                                                              width: 20,
                                                              height: 20,
                                                              decoration: BoxDecoration(
                                                                border: Border.fromBorderSide(Borders.secondaryBorder),
                                                                borderRadius: BorderRadius.all(Radius.circular(10)),
                                                              ),
                                                              child: Column(
                                                                mainAxisAlignment: MainAxisAlignment.center,
                                                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                                                children: [
                                                                  Container(
                                                                    height: 2,
                                                                    margin: EdgeInsets.symmetric(horizontal: 5),
                                                                    child: Image.asset(
                                                                      "assets/images/group-8-2.png",
                                                                      fit: BoxFit.none,
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                          Spacer(),
                                                          Align(
                                                            alignment: Alignment.centerLeft,
                                                            child: Container(
                                                              width: 20,
                                                              height: 20,
                                                              decoration: BoxDecoration(
                                                                border: Border.fromBorderSide(Borders.secondaryBorder),
                                                                borderRadius: BorderRadius.all(Radius.circular(10)),
                                                              ),
                                                              child: Column(
                                                                mainAxisAlignment: MainAxisAlignment.center,
                                                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                                                children: [
                                                                  Container(
                                                                    height: 11,
                                                                    margin: EdgeInsets.symmetric(horizontal: 5),
                                                                    child: Image.asset(
                                                                      "assets/images/group-8-3.png",
                                                                      fit: BoxFit.none,
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    Positioned(
                                                      child: Text(
                                                        "1",
                                                        textAlign: TextAlign.center,
                                                        style: TextStyle(
                                                          color: AppColors.primaryText,
                                                          fontFamily: "Avenir",
                                                          fontWeight: FontWeight.w800,
                                                          fontSize: 16,
                                                          height: 1,
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                            Spacer(),
                                            Align(
                                              alignment: Alignment.bottomLeft,
                                              child: Text(
                                                "\$55.35",
                                                textAlign: TextAlign.left,
                                                style: TextStyle(
                                                  color: AppColors.primaryText,
                                                  fontFamily: "Avenir",
                                                  fontWeight: FontWeight.w800,
                                                  fontSize: 18,
                                                  height: 0.88889,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Spacer(),
                        Container(
                          height: 1,
                          decoration: BoxDecoration(
                            color: Color.fromARGB(255, 243, 243, 243),
                            borderRadius: BorderRadius.all(Radius.circular(0.5)),
                          ),
                          child: Container(),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    height: 106,
                    margin: EdgeInsets.only(top: 15),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Container(
                          height: 90,
                          margin: EdgeInsets.only(left: 16, right: 18),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Align(
                                alignment: Alignment.topLeft,
                                child: Container(
                                  width: 103,
                                  height: 90,
                                  child: Stack(
                                    alignment: Alignment.center,
                                    children: [
                                      Positioned(
                                        left: 0,
                                        top: 0,
                                        child: Container(
                                          width: 84,
                                          height: 90,
                                          decoration: BoxDecoration(
                                            color: Color.fromARGB(255, 243, 243, 243),
                                            boxShadow: [
                                              Shadows.secondaryShadow,
                                            ],
                                            borderRadius: BorderRadius.all(Radius.circular(22)),
                                          ),
                                          child: Container(),
                                        ),
                                      ),
                                      Positioned(
                                        left: 13,
                                        top: 10,
                                        child: Image.asset(
                                          "assets/images/20-pizza-png-image-2.png",
                                          fit: BoxFit.none,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Spacer(),
                              Align(
                                alignment: Alignment.topLeft,
                                child: Container(
                                  width: 217,
                                  height: 57,
                                  margin: EdgeInsets.only(top: 15),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.stretch,
                                    children: [
                                      Align(
                                        alignment: Alignment.topLeft,
                                        child: Text(
                                          "Neapolitan Pizza",
                                          textAlign: TextAlign.left,
                                          style: TextStyle(
                                            color: AppColors.primaryText,
                                            fontFamily: "Avenir",
                                            fontWeight: FontWeight.w800,
                                            fontSize: 14,
                                          ),
                                        ),
                                      ),
                                      Spacer(),
                                      Container(
                                        height: 25,
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.stretch,
                                          children: [
                                            Align(
                                              alignment: Alignment.bottomLeft,
                                              child: Container(
                                                width: 80,
                                                height: 20,
                                                margin: EdgeInsets.only(bottom: 2),
                                                child: Stack(
                                                  alignment: Alignment.center,
                                                  children: [
                                                    Positioned(
                                                      left: 0,
                                                      right: 0,
                                                      child: Row(
                                                        crossAxisAlignment: CrossAxisAlignment.stretch,
                                                        children: [
                                                          Align(
                                                            alignment: Alignment.centerLeft,
                                                            child: Container(
                                                              width: 20,
                                                              height: 20,
                                                              decoration: BoxDecoration(
                                                                border: Border.fromBorderSide(Borders.secondaryBorder),
                                                                borderRadius: BorderRadius.all(Radius.circular(10)),
                                                              ),
                                                              child: Column(
                                                                mainAxisAlignment: MainAxisAlignment.center,
                                                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                                                children: [
                                                                  Container(
                                                                    height: 2,
                                                                    margin: EdgeInsets.symmetric(horizontal: 5),
                                                                    child: Image.asset(
                                                                      "assets/images/group-8-2.png",
                                                                      fit: BoxFit.none,
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                          Spacer(),
                                                          Align(
                                                            alignment: Alignment.centerLeft,
                                                            child: Container(
                                                              width: 20,
                                                              height: 20,
                                                              decoration: BoxDecoration(
                                                                border: Border.fromBorderSide(Borders.secondaryBorder),
                                                                borderRadius: BorderRadius.all(Radius.circular(10)),
                                                              ),
                                                              child: Column(
                                                                mainAxisAlignment: MainAxisAlignment.center,
                                                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                                                children: [
                                                                  Container(
                                                                    height: 11,
                                                                    margin: EdgeInsets.symmetric(horizontal: 5),
                                                                    child: Image.asset(
                                                                      "assets/images/group-8-3.png",
                                                                      fit: BoxFit.none,
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    Positioned(
                                                      child: Text(
                                                        "2",
                                                        textAlign: TextAlign.center,
                                                        style: TextStyle(
                                                          color: AppColors.primaryText,
                                                          fontFamily: "Avenir",
                                                          fontWeight: FontWeight.w800,
                                                          fontSize: 16,
                                                          height: 1,
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                            Spacer(),
                                            Align(
                                              alignment: Alignment.bottomLeft,
                                              child: Text(
                                                "\$20.60",
                                                textAlign: TextAlign.left,
                                                style: TextStyle(
                                                  color: AppColors.primaryText,
                                                  fontFamily: "Avenir",
                                                  fontWeight: FontWeight.w800,
                                                  fontSize: 18,
                                                  height: 0.88889,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Spacer(),
                        Container(
                          height: 1,
                          decoration: BoxDecoration(
                            color: Color.fromARGB(255, 243, 243, 243),
                            borderRadius: BorderRadius.all(Radius.circular(0.5)),
                          ),
                          child: Container(),
                        ),
                      ],
                    ),
                  ),
                  Spacer(),
                  Align(
                    alignment: Alignment.topLeft,
                    child: Container(
                      width: 335,
                      height: 90,
                      margin: EdgeInsets.only(left: 16),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Align(
                            alignment: Alignment.centerLeft,
                            child: Container(
                              width: 101,
                              height: 90,
                              child: Stack(
                                alignment: Alignment.center,
                                children: [
                                  Positioned(
                                    left: 0,
                                    child: Container(
                                      width: 84,
                                      height: 90,
                                      decoration: BoxDecoration(
                                        color: Color.fromARGB(255, 243, 243, 243),
                                        borderRadius: BorderRadius.all(Radius.circular(22)),
                                      ),
                                      child: Container(),
                                    ),
                                  ),
                                  Positioned(
                                    left: 16,
                                    child: Image.asset(
                                      "assets/images/hiclipartcom-1-2.png",
                                      fit: BoxFit.none,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Expanded(
                            flex: 1,
                            child: Container(
                              height: 57,
                              margin: EdgeInsets.only(left: 23, top: 15, right: 52),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                children: [
                                  Align(
                                    alignment: Alignment.topRight,
                                    child: Text(
                                      "Bisoon Burgers",
                                      textAlign: TextAlign.left,
                                      style: TextStyle(
                                        color: AppColors.primaryText,
                                        fontFamily: "Avenir",
                                        fontWeight: FontWeight.w800,
                                        fontSize: 14,
                                      ),
                                    ),
                                  ),
                                  Align(
                                    alignment: Alignment.topLeft,
                                    child: Container(
                                      width: 80,
                                      height: 20,
                                      margin: EdgeInsets.only(top: 18),
                                      child: Stack(
                                        alignment: Alignment.center,
                                        children: [
                                          Positioned(
                                            left: 0,
                                            right: 0,
                                            child: Row(
                                              crossAxisAlignment: CrossAxisAlignment.stretch,
                                              children: [
                                                Align(
                                                  alignment: Alignment.centerLeft,
                                                  child: Container(
                                                    width: 20,
                                                    height: 20,
                                                    decoration: BoxDecoration(
                                                      border: Border.fromBorderSide(Borders.secondaryBorder),
                                                      borderRadius: BorderRadius.all(Radius.circular(10)),
                                                    ),
                                                    child: Column(
                                                      mainAxisAlignment: MainAxisAlignment.center,
                                                      crossAxisAlignment: CrossAxisAlignment.stretch,
                                                      children: [
                                                        Container(
                                                          height: 2,
                                                          margin: EdgeInsets.symmetric(horizontal: 5),
                                                          child: Image.asset(
                                                            "assets/images/group-8-2.png",
                                                            fit: BoxFit.none,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                                Spacer(),
                                                Align(
                                                  alignment: Alignment.centerLeft,
                                                  child: Container(
                                                    width: 20,
                                                    height: 20,
                                                    decoration: BoxDecoration(
                                                      border: Border.fromBorderSide(Borders.secondaryBorder),
                                                      borderRadius: BorderRadius.all(Radius.circular(10)),
                                                    ),
                                                    child: Column(
                                                      mainAxisAlignment: MainAxisAlignment.center,
                                                      crossAxisAlignment: CrossAxisAlignment.stretch,
                                                      children: [
                                                        Container(
                                                          height: 11,
                                                          margin: EdgeInsets.symmetric(horizontal: 5),
                                                          child: Image.asset(
                                                            "assets/images/group-8-3.png",
                                                            fit: BoxFit.none,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Positioned(
                                            child: Text(
                                              "1",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                color: AppColors.primaryText,
                                                fontFamily: "Avenir",
                                                fontWeight: FontWeight.w800,
                                                fontSize: 16,
                                                height: 1,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.only(top: 49),
                            child: Text(
                              "\$25.30",
                              textAlign: TextAlign.left,
                              style: TextStyle(
                                color: AppColors.primaryText,
                                fontFamily: "Avenir",
                                fontWeight: FontWeight.w800,
                                fontSize: 18,
                                height: 0.88889,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Spacer(),
            Container(
              height: 90,
              decoration: BoxDecoration(
                color: Color.fromARGB(255, 255, 245, 176),
                boxShadow: [
                  Shadows.secondaryShadow,
                ],
                borderRadius: BorderRadius.all(Radius.circular(12)),
              ),
              child: Row(
                children: [
                  Container(
                    width: 100,
                    height: 50,
                    margin: EdgeInsets.only(left: 24),
                    decoration: BoxDecoration(
                      color: AppColors.secondaryElement,
                      boxShadow: [
                        BoxShadow(
                          color: Color.fromARGB(6, 0, 0, 0),
                          offset: Offset(0, 2),
                          blurRadius: 8,
                        ),
                      ],
                      borderRadius: BorderRadius.all(Radius.circular(4)),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          margin: EdgeInsets.only(left: 12, top: 5),
                          child: Opacity(
                            opacity: 0.60156,
                            child: Text(
                              "Total",
                              textAlign: TextAlign.left,
                              style: TextStyle(
                                color: AppColors.primaryText,
                                fontFamily: "Avenir",
                                fontWeight: FontWeight.w400,
                                fontSize: 12,
                                height: 1,
                              ),
                            ),
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.only(left: 12, top: 2),
                          child: Text(
                            "\$306.35",
                            textAlign: TextAlign.left,
                            style: TextStyle(
                              color: AppColors.primaryText,
                              fontFamily: "Avenir",
                              fontWeight: FontWeight.w800,
                              fontSize: 14,
                              height: 1,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Spacer(),
                  Container(
                    width: 215,
                    height: 50,
                    margin: EdgeInsets.only(right: 24),
                    child: FlatButton(
                      onPressed: () => this.onGroupPressed(context),
                      color: AppColors.primaryElement,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.all(Radius.circular(4)),
                      ),
                      textColor: Color.fromARGB(255, 66, 80, 96),
                      padding: EdgeInsets.all(0),
                      child: Text(
                        "Place Order",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Color.fromARGB(255, 66, 80, 96),
                          fontFamily: "Avenir",
                          fontWeight: FontWeight.w800,
                          fontSize: 14,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}