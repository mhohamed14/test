/*
*  sign_in_widget.dart
*  Food UI Kit
*
*  Created by [Author].
*  Copyright © 2018 [Company]. All rights reserved.
    */

import 'package:flutter/material.dart';
import 'package:food_ui_kit/add_card_widget/add_card_widget.dart';
import 'package:food_ui_kit/values/values.dart';


class SignInWidget extends StatelessWidget {
  
  void onButtonPressed(BuildContext context) => Navigator.push(context, MaterialPageRoute(builder: (context) => AddCardWidget()));
  
  @override
  Widget build(BuildContext context) {
  
    return Scaffold(
      body: Container(
        constraints: BoxConstraints.expand(),
        decoration: BoxDecoration(
          color: Color.fromARGB(255, 250, 250, 250),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              height: 496,
              margin: EdgeInsets.only(left: 16, top: 138, right: 16),
              child: Stack(
                alignment: Alignment.topCenter,
                children: [
                  Positioned(
                    left: 0,
                    top: 56,
                    right: 0,
                    child: Opacity(
                      opacity: 0.95466,
                      child: Container(
                        height: 440,
                        decoration: BoxDecoration(
                          color: AppColors.primaryBackground,
                          borderRadius: BorderRadius.all(Radius.circular(15)),
                        ),
                        child: Container(),
                      ),
                    ),
                  ),
                  Positioned(
                    left: 20,
                    top: 0,
                    right: 20,
                    bottom: 64,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Align(
                          alignment: Alignment.topCenter,
                          child: Container(
                            width: 116,
                            height: 108,
                            child: Opacity(
                              opacity: 0.79839,
                              child: Image.asset(
                                "assets/images/004-burger-2.png",
                                fit: BoxFit.none,
                              ),
                            ),
                          ),
                        ),
                        Align(
                          alignment: Alignment.topCenter,
                          child: Container(
                            margin: EdgeInsets.only(top: 9),
                            child: Text(
                              "Foodies ",
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: AppColors.primaryText,
                                fontFamily: "Avenir",
                                fontWeight: FontWeight.w800,
                                fontSize: 16,
                                height: 0.75,
                              ),
                            ),
                          ),
                        ),
                        Container(
                          height: 72,
                          margin: EdgeInsets.only(top: 35),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Align(
                                alignment: Alignment.topLeft,
                                child: Opacity(
                                  opacity: 0.60156,
                                  child: Text(
                                    "Name",
                                    textAlign: TextAlign.left,
                                    style: TextStyle(
                                      color: AppColors.primaryText,
                                      fontFamily: "Avenir",
                                      fontWeight: FontWeight.w500,
                                      fontSize: 12,
                                      height: 1,
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                height: 50,
                                margin: EdgeInsets.only(top: 8),
                                decoration: BoxDecoration(
                                  border: Border.fromBorderSide(Borders.primaryBorder),
                                  borderRadius: Radii.k7pxRadius,
                                ),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      margin: EdgeInsets.only(left: 30),
                                      child: Text(
                                        "Shakibul Islam",
                                        textAlign: TextAlign.left,
                                        style: TextStyle(
                                          color: AppColors.primaryText,
                                          fontFamily: "Avenir",
                                          fontWeight: FontWeight.w500,
                                          fontSize: 16,
                                          height: 1,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          height: 72,
                          margin: EdgeInsets.only(top: 30),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Align(
                                alignment: Alignment.topLeft,
                                child: Opacity(
                                  opacity: 0.60156,
                                  child: Text(
                                    "Email",
                                    textAlign: TextAlign.left,
                                    style: TextStyle(
                                      color: AppColors.primaryText,
                                      fontFamily: "Avenir",
                                      fontWeight: FontWeight.w500,
                                      fontSize: 12,
                                      height: 1,
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                height: 50,
                                margin: EdgeInsets.only(top: 8),
                                decoration: BoxDecoration(
                                  border: Border.fromBorderSide(Borders.primaryBorder),
                                  borderRadius: Radii.k7pxRadius,
                                ),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      margin: EdgeInsets.only(left: 30),
                                      child: Text(
                                        "shakib@gmail.com",
                                        textAlign: TextAlign.left,
                                        style: TextStyle(
                                          color: AppColors.primaryText,
                                          fontFamily: "Avenir",
                                          fontWeight: FontWeight.w500,
                                          fontSize: 16,
                                          height: 1,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        Spacer(),
                        Container(
                          height: 54,
                          child: FlatButton(
                            onPressed: () => this.onButtonPressed(context),
                            color: AppColors.primaryElement,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.all(Radius.circular(4)),
                            ),
                            textColor: Color.fromARGB(255, 66, 80, 96),
                            padding: EdgeInsets.all(0),
                            child: Text(
                              "Next",
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: Color.fromARGB(255, 66, 80, 96),
                                fontFamily: "Avenir",
                                fontWeight: FontWeight.w800,
                                fontSize: 14,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}