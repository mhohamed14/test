/*
*  all_in_one_place_widget.dart
*  Food UI Kit
*
*  Created by [Author].
*  Copyright © 2018 [Company]. All rights reserved.
    */

import 'package:flutter/material.dart';
import 'package:food_ui_kit/nearest_restaurant_widget/nearest_restaurant_widget.dart';
import 'package:food_ui_kit/values/values.dart';


class AllInOnePlaceWidget extends StatelessWidget {
  
  void onNextPressed(BuildContext context) => Navigator.push(context, MaterialPageRoute(builder: (context) => NearestRestaurantWidget()));
  
  @override
  Widget build(BuildContext context) {
  
    return Scaffold(
      body: Container(
        constraints: BoxConstraints.expand(),
        decoration: BoxDecoration(
          color: Color.fromARGB(255, 255, 255, 255),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Align(
              alignment: Alignment.topLeft,
              child: Container(
                margin: EdgeInsets.only(left: 24, top: 105),
                child: Text(
                  "All Favourite Food\nin One Place",
                  textAlign: TextAlign.left,
                  style: TextStyle(
                    color: AppColors.primaryText,
                    fontFamily: "Avenir",
                    fontWeight: FontWeight.w800,
                    fontSize: 24,
                    height: 1.41667,
                  ),
                ),
              ),
            ),
            Container(
              height: 332,
              margin: EdgeInsets.only(top: 24),
              child: Stack(
                alignment: Alignment.topCenter,
                children: [
                  Positioned(
                    left: 1,
                    top: 1,
                    right: 1,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Align(
                          alignment: Alignment.topLeft,
                          child: Container(
                            width: 124,
                            height: 165,
                            margin: EdgeInsets.only(top: 11),
                            child: Image.asset(
                              "assets/images/group-copy-2.png",
                              fit: BoxFit.none,
                            ),
                          ),
                        ),
                        Spacer(),
                        Align(
                          alignment: Alignment.topLeft,
                          child: Container(
                            width: 148,
                            height: 163,
                            child: Image.asset(
                              "assets/images/group-copy.png",
                              fit: BoxFit.none,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Positioned(
                    top: 52,
                    child: Image.asset(
                      "assets/images/o-3.png",
                      fit: BoxFit.cover,
                    ),
                  ),
                  Positioned(
                    left: 82,
                    top: 52,
                    right: 97,
                    bottom: 24,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Container(
                          height: 79,
                          margin: EdgeInsets.only(left: 33),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Align(
                                alignment: Alignment.topLeft,
                                child: Container(
                                  width: 57,
                                  height: 58,
                                  child: Stack(
                                    alignment: Alignment.topCenter,
                                    children: [
                                      Positioned(
                                        left: 0,
                                        top: 29,
                                        right: 0,
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.stretch,
                                          children: [
                                            Align(
                                              alignment: Alignment.topLeft,
                                              child: Container(
                                                width: 27,
                                                height: 29,
                                                child: Image.asset(
                                                  "assets/images/group-31.png",
                                                  fit: BoxFit.none,
                                                ),
                                              ),
                                            ),
                                            Spacer(),
                                            Align(
                                              alignment: Alignment.topLeft,
                                              child: Container(
                                                width: 26,
                                                height: 28,
                                                child: Image.asset(
                                                  "assets/images/group-44.png",
                                                  fit: BoxFit.none,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Positioned(
                                        left: 15,
                                        top: 0,
                                        right: 13,
                                        child: Image.asset(
                                          "assets/images/group-20.png",
                                          fit: BoxFit.none,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Spacer(),
                              Align(
                                alignment: Alignment.topLeft,
                                child: Container(
                                  width: 61,
                                  height: 48,
                                  margin: EdgeInsets.only(top: 31),
                                  child: Stack(
                                    alignment: Alignment.center,
                                    children: [
                                      Positioned(
                                        left: 0,
                                        top: 1,
                                        right: 0,
                                        bottom: 1,
                                        child: Stack(
                                          alignment: Alignment.center,
                                          children: [
                                            Positioned(
                                              left: 0,
                                              top: 6,
                                              right: 0,
                                              bottom: 0,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                                children: [
                                                  Align(
                                                    alignment: Alignment.topLeft,
                                                    child: Container(
                                                      width: 3,
                                                      height: 2,
                                                      margin: EdgeInsets.only(left: 10),
                                                      child: Image.asset(
                                                        "assets/images/shape-7.png",
                                                        fit: BoxFit.none,
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    height: 4,
                                                    margin: EdgeInsets.only(left: 15, top: 2, right: 14),
                                                    child: Row(
                                                      crossAxisAlignment: CrossAxisAlignment.stretch,
                                                      children: [
                                                        Align(
                                                          alignment: Alignment.topLeft,
                                                          child: Container(
                                                            width: 4,
                                                            height: 4,
                                                            child: Image.asset(
                                                              "assets/images/group-39.png",
                                                              fit: BoxFit.none,
                                                            ),
                                                          ),
                                                        ),
                                                        Spacer(),
                                                        Align(
                                                          alignment: Alignment.topLeft,
                                                          child: Container(
                                                            width: 4,
                                                            height: 4,
                                                            child: Image.asset(
                                                              "assets/images/group-68.png",
                                                              fit: BoxFit.none,
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  Align(
                                                    alignment: Alignment.topLeft,
                                                    child: Container(
                                                      width: 3,
                                                      height: 3,
                                                      margin: EdgeInsets.only(left: 15),
                                                      child: Image.asset(
                                                        "assets/images/shape-2.png",
                                                        fit: BoxFit.none,
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    height: 12,
                                                    margin: EdgeInsets.only(left: 11, top: 4, right: 15),
                                                    child: Image.asset(
                                                      "assets/images/path-19.png",
                                                      fit: BoxFit.none,
                                                    ),
                                                  ),
                                                  Spacer(),
                                                  Container(
                                                    height: 9,
                                                    child: Opacity(
                                                      opacity: 0.5,
                                                      child: Image.asset(
                                                        "assets/images/path-10.png",
                                                        fit: BoxFit.none,
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Positioned(
                                              left: 0,
                                              right: 1,
                                              bottom: 2,
                                              child: Row(
                                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                                children: [
                                                  Align(
                                                    alignment: Alignment.bottomLeft,
                                                    child: Container(
                                                      width: 23,
                                                      height: 9,
                                                      child: Image.asset(
                                                        "assets/images/path-30.png",
                                                        fit: BoxFit.none,
                                                      ),
                                                    ),
                                                  ),
                                                  Spacer(),
                                                  Align(
                                                    alignment: Alignment.bottomLeft,
                                                    child: Container(
                                                      width: 23,
                                                      height: 9,
                                                      child: Image.asset(
                                                        "assets/images/path-25.png",
                                                        fit: BoxFit.none,
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Positioned(
                                              left: 15,
                                              right: 14,
                                              bottom: 5,
                                              child: Row(
                                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                                children: [
                                                  Align(
                                                    alignment: Alignment.bottomLeft,
                                                    child: Container(
                                                      width: 8,
                                                      height: 6,
                                                      child: Opacity(
                                                        opacity: 0.6,
                                                        child: Image.asset(
                                                          "assets/images/path-32.png",
                                                          fit: BoxFit.none,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Spacer(),
                                                  Align(
                                                    alignment: Alignment.bottomLeft,
                                                    child: Container(
                                                      width: 10,
                                                      height: 4,
                                                      child: Opacity(
                                                        opacity: 0.6,
                                                        child: Image.asset(
                                                          "assets/images/path-2.png",
                                                          fit: BoxFit.none,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Positioned(
                                              top: 19,
                                              right: 20,
                                              child: Image.asset(
                                                "assets/images/shape-3.png",
                                                fit: BoxFit.none,
                                              ),
                                            ),
                                            Positioned(
                                              left: 16,
                                              top: 20,
                                              child: Image.asset(
                                                "assets/images/path-18.png",
                                                fit: BoxFit.none,
                                              ),
                                            ),
                                            Positioned(
                                              left: 10,
                                              top: 10,
                                              right: 13,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                                children: [
                                                  Align(
                                                    alignment: Alignment.topRight,
                                                    child: Container(
                                                      width: 12,
                                                      height: 11,
                                                      margin: EdgeInsets.only(right: 9),
                                                      child: Image.asset(
                                                        "assets/images/group-47.png",
                                                        fit: BoxFit.none,
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    height: 8,
                                                    margin: EdgeInsets.only(top: 9),
                                                    child: Image.asset(
                                                      "assets/images/path-36.png",
                                                      fit: BoxFit.none,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Positioned(
                                              left: 11,
                                              top: 20,
                                              right: 19,
                                              child: Row(
                                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                                children: [
                                                  Align(
                                                    alignment: Alignment.topLeft,
                                                    child: Container(
                                                      width: 14,
                                                      height: 12,
                                                      child: Image.asset(
                                                        "assets/images/group-56.png",
                                                        fit: BoxFit.none,
                                                      ),
                                                    ),
                                                  ),
                                                  Spacer(),
                                                  Align(
                                                    alignment: Alignment.topLeft,
                                                    child: Container(
                                                      width: 16,
                                                      height: 11,
                                                      margin: EdgeInsets.only(top: 1),
                                                      child: Image.asset(
                                                        "assets/images/group-17.png",
                                                        fit: BoxFit.none,
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Positioned(
                                              top: 24,
                                              right: 14,
                                              child: Image.asset(
                                                "assets/images/group-81.png",
                                                fit: BoxFit.none,
                                              ),
                                            ),
                                            Positioned(
                                              top: 25,
                                              right: 24,
                                              child: Image.asset(
                                                "assets/images/group-64.png",
                                                fit: BoxFit.none,
                                              ),
                                            ),
                                            Positioned(
                                              left: 5,
                                              top: 5,
                                              right: 20,
                                              child: Row(
                                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                                children: [
                                                  Align(
                                                    alignment: Alignment.topLeft,
                                                    child: Container(
                                                      width: 23,
                                                      height: 25,
                                                      child: Stack(
                                                        alignment: Alignment.center,
                                                        children: [
                                                          Positioned(
                                                            left: 0,
                                                            right: 2,
                                                            child: Image.asset(
                                                              "assets/images/path-37.png",
                                                              fit: BoxFit.none,
                                                            ),
                                                          ),
                                                          Positioned(
                                                            left: 0,
                                                            right: 1,
                                                            child: Image.asset(
                                                              "assets/images/group-50.png",
                                                              fit: BoxFit.none,
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                  Spacer(),
                                                  Align(
                                                    alignment: Alignment.topLeft,
                                                    child: Container(
                                                      width: 3,
                                                      height: 2,
                                                      margin: EdgeInsets.only(top: 8),
                                                      child: Image.asset(
                                                        "assets/images/group-51.png",
                                                        fit: BoxFit.none,
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Positioned(
                                              left: 20,
                                              top: 13,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                                children: [
                                                  Align(
                                                    alignment: Alignment.topLeft,
                                                    child: Container(
                                                      width: 6,
                                                      height: 4,
                                                      child: Image.asset(
                                                        "assets/images/group-84.png",
                                                        fit: BoxFit.none,
                                                      ),
                                                    ),
                                                  ),
                                                  Align(
                                                    alignment: Alignment.topLeft,
                                                    child: Container(
                                                      width: 7,
                                                      height: 6,
                                                      margin: EdgeInsets.only(left: 3, top: 7),
                                                      child: Image.asset(
                                                        "assets/images/group-73.png",
                                                        fit: BoxFit.none,
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Positioned(
                                              left: 9,
                                              top: 15,
                                              right: 15,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                                children: [
                                                  Align(
                                                    alignment: Alignment.topLeft,
                                                    child: Container(
                                                      width: 2,
                                                      height: 3,
                                                      child: Image.asset(
                                                        "assets/images/group-43.png",
                                                        fit: BoxFit.none,
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    height: 22,
                                                    margin: EdgeInsets.only(left: 2, top: 3),
                                                    child: Image.asset(
                                                      "assets/images/group-70.png",
                                                      fit: BoxFit.none,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Positioned(
                                              left: 17,
                                              top: 0,
                                              right: 1,
                                              bottom: 6,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                                children: [
                                                  Container(
                                                    height: 11,
                                                    margin: EdgeInsets.only(left: 3, right: 20),
                                                    child: Row(
                                                      crossAxisAlignment: CrossAxisAlignment.stretch,
                                                      children: [
                                                        Align(
                                                          alignment: Alignment.topLeft,
                                                          child: Container(
                                                            width: 8,
                                                            height: 8,
                                                            child: Image.asset(
                                                              "assets/images/group-88.png",
                                                              fit: BoxFit.none,
                                                            ),
                                                          ),
                                                        ),
                                                        Spacer(),
                                                        Align(
                                                          alignment: Alignment.topLeft,
                                                          child: Container(
                                                            width: 6,
                                                            height: 6,
                                                            margin: EdgeInsets.only(top: 5),
                                                            child: Image.asset(
                                                              "assets/images/group-89.png",
                                                              fit: BoxFit.none,
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  Align(
                                                    alignment: Alignment.topRight,
                                                    child: Container(
                                                      width: 31,
                                                      height: 8,
                                                      margin: EdgeInsets.only(top: 2),
                                                      child: Image.asset(
                                                        "assets/images/group-32.png",
                                                        fit: BoxFit.none,
                                                      ),
                                                    ),
                                                  ),
                                                  Spacer(),
                                                  Align(
                                                    alignment: Alignment.topLeft,
                                                    child: Container(
                                                      width: 23,
                                                      height: 4,
                                                      child: Opacity(
                                                        opacity: 0.4,
                                                        child: Image.asset(
                                                          "assets/images/path-22.png",
                                                          fit: BoxFit.none,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Positioned(
                                              left: 9,
                                              top: 29,
                                              right: 13,
                                              child: Image.asset(
                                                "assets/images/group-15.png",
                                                fit: BoxFit.none,
                                              ),
                                            ),
                                            Positioned(
                                              left: 8,
                                              top: 3,
                                              right: 5,
                                              bottom: 2,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                                children: [
                                                  Container(
                                                    height: 26,
                                                    child: Image.asset(
                                                      "assets/images/group-3.png",
                                                      fit: BoxFit.none,
                                                    ),
                                                  ),
                                                  Spacer(),
                                                  Align(
                                                    alignment: Alignment.topRight,
                                                    child: Container(
                                                      width: 15,
                                                      height: 12,
                                                      margin: EdgeInsets.only(right: 1),
                                                      child: Image.asset(
                                                        "assets/images/group-25.png",
                                                        fit: BoxFit.none,
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Positioned(
                                              left: 2,
                                              top: 23,
                                              child: Image.asset(
                                                "assets/images/group-79.png",
                                                fit: BoxFit.none,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Positioned(
                                        left: 12,
                                        right: 19,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.stretch,
                                          children: [
                                            Align(
                                              alignment: Alignment.topLeft,
                                              child: Container(
                                                width: 6,
                                                height: 1,
                                                child: Image.asset(
                                                  "assets/images/path-11.png",
                                                  fit: BoxFit.none,
                                                ),
                                              ),
                                            ),
                                            Align(
                                              alignment: Alignment.topRight,
                                              child: Container(
                                                width: 2,
                                                height: 3,
                                                child: Image.asset(
                                                  "assets/images/shape-13.png",
                                                  fit: BoxFit.none,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Positioned(
                                        left: 17,
                                        child: Image.asset(
                                          "assets/images/path-12.png",
                                          fit: BoxFit.none,
                                        ),
                                      ),
                                      Positioned(
                                        child: Image.asset(
                                          "assets/images/shape-5.png",
                                          fit: BoxFit.none,
                                        ),
                                      ),
                                      Positioned(
                                        left: 17,
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.stretch,
                                          children: [
                                            Align(
                                              alignment: Alignment.centerLeft,
                                              child: Container(
                                                width: 3,
                                                height: 3,
                                                child: Image.asset(
                                                  "assets/images/shape-11.png",
                                                  fit: BoxFit.none,
                                                ),
                                              ),
                                            ),
                                            Align(
                                              alignment: Alignment.centerLeft,
                                              child: Container(
                                                width: 4,
                                                height: 4,
                                                child: Image.asset(
                                                  "assets/images/group-46.png",
                                                  fit: BoxFit.none,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Positioned(
                                        left: 14,
                                        child: Image.asset(
                                          "assets/images/group-78.png",
                                          fit: BoxFit.none,
                                        ),
                                      ),
                                      Positioned(
                                        left: 11,
                                        right: 15,
                                        child: Image.asset(
                                          "assets/images/path-6.png",
                                          fit: BoxFit.none,
                                        ),
                                      ),
                                      Positioned(
                                        left: 17,
                                        top: 7,
                                        right: 16,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.stretch,
                                          children: [
                                            Align(
                                              alignment: Alignment.topCenter,
                                              child: Container(
                                                width: 2,
                                                height: 3,
                                                child: Image.asset(
                                                  "assets/images/shape-4.png",
                                                  fit: BoxFit.none,
                                                ),
                                              ),
                                            ),
                                            Align(
                                              alignment: Alignment.topLeft,
                                              child: Container(
                                                width: 8,
                                                height: 1,
                                                child: Image.asset(
                                                  "assets/images/path-33.png",
                                                  fit: BoxFit.none,
                                                ),
                                              ),
                                            ),
                                            Align(
                                              alignment: Alignment.topRight,
                                              child: Container(
                                                width: 22,
                                                height: 6,
                                                child: Image.asset(
                                                  "assets/images/path-15.png",
                                                  fit: BoxFit.none,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Spacer(),
                        Container(
                          height: 84,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Align(
                                alignment: Alignment.bottomLeft,
                                child: Container(
                                  width: 60,
                                  height: 67,
                                  margin: EdgeInsets.only(bottom: 17),
                                  child: Row(
                                    children: [
                                      Container(
                                        width: 28,
                                        height: 64,
                                        child: Image.asset(
                                          "assets/images/group-18.png",
                                          fit: BoxFit.none,
                                        ),
                                      ),
                                      Spacer(),
                                      Container(
                                        width: 28,
                                        height: 63,
                                        child: Stack(
                                          alignment: Alignment.center,
                                          children: [
                                            Positioned(
                                              left: 0,
                                              right: 0,
                                              child: Stack(
                                                alignment: Alignment.topCenter,
                                                children: [
                                                  Positioned(
                                                    left: 1,
                                                    top: 22,
                                                    right: 2,
                                                    child: Image.asset(
                                                      "assets/images/group-57.png",
                                                      fit: BoxFit.none,
                                                    ),
                                                  ),
                                                  Positioned(
                                                    left: 5,
                                                    top: 22,
                                                    right: 2,
                                                    child: Image.asset(
                                                      "assets/images/path-29.png",
                                                      fit: BoxFit.none,
                                                    ),
                                                  ),
                                                  Positioned(
                                                    left: 0,
                                                    top: 22,
                                                    right: 0,
                                                    child: Column(
                                                      crossAxisAlignment: CrossAxisAlignment.stretch,
                                                      children: [
                                                        Container(
                                                          height: 7,
                                                          child: Image.asset(
                                                            "assets/images/group-27.png",
                                                            fit: BoxFit.none,
                                                          ),
                                                        ),
                                                        Align(
                                                          alignment: Alignment.topLeft,
                                                          child: Container(
                                                            width: 4,
                                                            height: 18,
                                                            margin: EdgeInsets.only(left: 4, top: 2),
                                                            child: Opacity(
                                                              opacity: 0.6,
                                                              child: Stack(
                                                                alignment: Alignment.center,
                                                                children: [
                                                                  Positioned(
                                                                    left: 0,
                                                                    right: 1,
                                                                    child: Image.asset(
                                                                      "assets/images/group-74.png",
                                                                      fit: BoxFit.none,
                                                                    ),
                                                                  ),
                                                                  Positioned(
                                                                    left: 1,
                                                                    right: 1,
                                                                    bottom: 0,
                                                                    child: Image.asset(
                                                                      "assets/images/group-59.png",
                                                                      fit: BoxFit.none,
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  Positioned(
                                                    left: 0,
                                                    top: 19,
                                                    right: 0,
                                                    child: Image.asset(
                                                      "assets/images/group-28.png",
                                                      fit: BoxFit.none,
                                                    ),
                                                  ),
                                                  Positioned(
                                                    left: 3,
                                                    top: 20,
                                                    right: 2,
                                                    child: Image.asset(
                                                      "assets/images/group-48.png",
                                                      fit: BoxFit.none,
                                                    ),
                                                  ),
                                                  Positioned(
                                                    left: 0,
                                                    top: 0,
                                                    right: 12,
                                                    child: Stack(
                                                      alignment: Alignment.center,
                                                      children: [
                                                        Positioned(
                                                          left: 0,
                                                          right: 1,
                                                          child: Image.asset(
                                                            "assets/images/group-53.png",
                                                            fit: BoxFit.none,
                                                          ),
                                                        ),
                                                        Positioned(
                                                          left: 6,
                                                          right: 1,
                                                          child: Stack(
                                                            alignment: Alignment.center,
                                                            children: [
                                                              Positioned(
                                                                left: 4,
                                                                right: 1,
                                                                child: Image.asset(
                                                                  "assets/images/group-29.png",
                                                                  fit: BoxFit.none,
                                                                ),
                                                              ),
                                                              Positioned(
                                                                left: 0,
                                                                top: 0,
                                                                right: 0,
                                                                bottom: 0,
                                                                child: Column(
                                                                  crossAxisAlignment: CrossAxisAlignment.stretch,
                                                                  children: [
                                                                    Container(
                                                                      height: 6,
                                                                      margin: EdgeInsets.only(right: 4),
                                                                      child: Image.asset(
                                                                        "assets/images/group-13.png",
                                                                        fit: BoxFit.none,
                                                                      ),
                                                                    ),
                                                                    Spacer(),
                                                                    Container(
                                                                      height: 7,
                                                                      margin: EdgeInsets.only(left: 5),
                                                                      child: Image.asset(
                                                                        "assets/images/group.png",
                                                                        fit: BoxFit.none,
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                        Positioned(
                                                          left: 1,
                                                          right: 3,
                                                          child: Image.asset(
                                                            "assets/images/path-20.png",
                                                            fit: BoxFit.none,
                                                          ),
                                                        ),
                                                        Positioned(
                                                          left: 0,
                                                          top: 0,
                                                          right: 13,
                                                          child: Image.asset(
                                                            "assets/images/group-7.png",
                                                            fit: BoxFit.none,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  Positioned(
                                                    left: 2,
                                                    top: 11,
                                                    right: 2,
                                                    child: Image.asset(
                                                      "assets/images/shape-10.png",
                                                      fit: BoxFit.none,
                                                    ),
                                                  ),
                                                  Positioned(
                                                    left: 2,
                                                    top: 11,
                                                    right: 2,
                                                    child: Opacity(
                                                      opacity: 0.9,
                                                      child: Image.asset(
                                                        "assets/images/group-91.png",
                                                        fit: BoxFit.none,
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Positioned(
                                              left: 8,
                                              top: 41,
                                              right: 7,
                                              child: Stack(
                                                alignment: Alignment.center,
                                                children: [
                                                  Positioned(
                                                    left: 0,
                                                    right: 0,
                                                    child: Row(
                                                      children: [
                                                        Expanded(
                                                          flex: 1,
                                                          child: Container(
                                                            height: 4,
                                                            margin: EdgeInsets.only(right: 4),
                                                            child: Image.asset(
                                                              "assets/images/group-52.png",
                                                              fit: BoxFit.none,
                                                            ),
                                                          ),
                                                        ),
                                                        Expanded(
                                                          flex: 1,
                                                          child: Container(
                                                            height: 4,
                                                            margin: EdgeInsets.only(left: 4, right: 1),
                                                            child: Image.asset(
                                                              "assets/images/group-52.png",
                                                              fit: BoxFit.none,
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  Positioned(
                                                    left: -0,
                                                    top: -1,
                                                    right: 1,
                                                    child: Image.asset(
                                                      "assets/images/group-8.png",
                                                      fit: BoxFit.none,
                                                    ),
                                                  ),
                                                  Positioned(
                                                    left: 4,
                                                    right: 5,
                                                    child: Image.asset(
                                                      "assets/images/group-54.png",
                                                      fit: BoxFit.none,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Spacer(),
                              Align(
                                alignment: Alignment.bottomLeft,
                                child: Container(
                                  width: 60,
                                  height: 60,
                                  child: Image.asset(
                                    "assets/images/layer-0-3.png",
                                    fit: BoxFit.none,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Spacer(),
            Align(
              alignment: Alignment.topCenter,
              child: Container(
                width: 327,
                height: 46,
                margin: EdgeInsets.only(bottom: 127),
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    Positioned(
                      left: 0,
                      right: 0,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Align(
                            alignment: Alignment.centerLeft,
                            child: Text(
                              "Skeep",
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: AppColors.primaryText,
                                fontFamily: "Avenir",
                                fontWeight: FontWeight.w800,
                                fontSize: 14,
                                height: 1,
                              ),
                            ),
                          ),
                          Spacer(),
                          Align(
                            alignment: Alignment.centerLeft,
                            child: Container(
                              width: 44,
                              height: 46,
                              child: FlatButton(
                                onPressed: () => this.onNextPressed(context),
                                color: Color.fromARGB(0, 0, 0, 0),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.all(Radius.circular(0)),
                                ),
                                textColor: Color.fromARGB(255, 0, 0, 0),
                                padding: EdgeInsets.all(0),
                                child: Text(
                                  "",
                                  textAlign: TextAlign.left,
                                  style: TextStyle(
                                    color: Color.fromARGB(255, 0, 0, 0),
                                    fontWeight: FontWeight.w400,
                                    fontSize: 12,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Positioned(
                      child: Image.asset(
                        "assets/images/group-3-6.png",
                        fit: BoxFit.none,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}