/*
*  search_on_map_widget.dart
*  Food UI Kit
*
*  Created by [Author].
*  Copyright © 2018 [Company]. All rights reserved.
    */

import 'package:flutter/material.dart';
import 'package:food_ui_kit/home_widget/home_widget.dart';
import 'package:food_ui_kit/values/values.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';


class SearchOnMapWidget extends StatelessWidget {
  
  void onFilterPressed(BuildContext context) => Navigator.push(context, MaterialPageRoute(builder: (context) => HomeWidget()));
  
  @override
  Widget build(BuildContext context) {
  
    return Scaffold(
      body: Container(
        constraints: BoxConstraints.expand(),
        decoration: BoxDecoration(
          color: Color.fromARGB(255, 250, 250, 250),
        ),
        child: Stack(
          alignment: Alignment.topRight,
          children: [
            Positioned(
              left: -68,
              top: -24,
              right: -151,
              child: Stack(
                alignment: Alignment.centerLeft,
                children: [
                  Positioned(
                    left: 0,
                    right: 1,
                    child: Image.asset(
                      "assets/images/bitmap-2.png",
                      fit: BoxFit.cover,
                    ),
                  ),
                  Positioned(
                    left: 68,
                    top: 24,
                    child: Opacity(
                      opacity: 0.30118,
                      child: Container(
                        width: 375,
                        height: 812,
                        decoration: BoxDecoration(
                          color: Color.fromARGB(255, 245, 246, 246),
                        ),
                        child: Container(),
                      ),
                    ),
                  ),
                  Positioned(
                    left: 108,
                    top: 296,
                    child: Image.asset(
                      "assets/images/group-3-9.png",
                      fit: BoxFit.cover,
                    ),
                  ),
                ],
              ),
            ),
            Positioned(
              left: 0,
              top: 0,
              right: -216,
              bottom: 30,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    height: 168,
                    margin: EdgeInsets.only(right: 216),
                    decoration: BoxDecoration(
                      color: Color.fromARGB(255, 255, 245, 176),
                      boxShadow: [
                        Shadows.secondaryShadow,
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Container(
                          height: 46,
                          margin: EdgeInsets.only(left: 16, top: 64, right: 16),
                          decoration: BoxDecoration(
                            color: AppColors.secondaryElement,
                            borderRadius: Radii.k7pxRadius,
                          ),
                          child: Row(
                            children: [
                              Container(
                                width: 10,
                                height: 16,
                                margin: EdgeInsets.only(left: 25),
                                child: Image.asset(
                                  "assets/images/maps-and-flags.png",
                                  fit: BoxFit.none,
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.only(left: 20),
                                child: Text(
                                  "Nayasharakh Road, Sylhet",
                                  textAlign: TextAlign.left,
                                  style: TextStyle(
                                    color: AppColors.primaryText,
                                    fontFamily: "Avenir",
                                    fontWeight: FontWeight.w400,
                                    fontSize: 14,
                                  ),
                                ),
                              ),
                              Spacer(),
                              Container(
                                width: 36,
                                height: 36,
                                margin: EdgeInsets.only(right: 5),
                                child: FlatButton(
                                  onPressed: () => this.onFilterPressed(context),
                                  color: AppColors.primaryElement,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: Radii.k7pxRadius,
                                  ),
                                  textColor: Color.fromARGB(255, 0, 0, 0),
                                  padding: EdgeInsets.all(0),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Image.asset("assets/images/close.png",),
                                      SizedBox(
                                        width: 10,
                                      ),
                                      Text(
                                        "",
                                        textAlign: TextAlign.left,
                                        style: TextStyle(
                                          color: Color.fromARGB(255, 0, 0, 0),
                                          fontWeight: FontWeight.w400,
                                          fontSize: 12,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Spacer(),
                        Container(
                          height: 20,
                          margin: EdgeInsets.only(left: 20, right: 46, bottom: 7),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Align(
                                alignment: Alignment.bottomLeft,
                                child: Text(
                                  "Fast Food",
                                  textAlign: TextAlign.left,
                                  style: TextStyle(
                                    color: AppColors.primaryText,
                                    fontFamily: "Avenir",
                                    fontWeight: FontWeight.w800,
                                    fontSize: 14,
                                    height: 1,
                                  ),
                                ),
                              ),
                              Align(
                                alignment: Alignment.bottomLeft,
                                child: Container(
                                  margin: EdgeInsets.only(left: 33),
                                  child: Opacity(
                                    opacity: 0.59961,
                                    child: Text(
                                      "Breakfast",
                                      textAlign: TextAlign.left,
                                      style: TextStyle(
                                        color: AppColors.primaryText,
                                        fontFamily: "Avenir",
                                        fontWeight: FontWeight.w400,
                                        fontSize: 14,
                                        height: 1,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Spacer(),
                              Align(
                                alignment: Alignment.bottomLeft,
                                child: Container(
                                  margin: EdgeInsets.only(right: 35),
                                  child: Opacity(
                                    opacity: 0.59961,
                                    child: Text(
                                      "Lunch",
                                      textAlign: TextAlign.left,
                                      style: TextStyle(
                                        color: AppColors.primaryText,
                                        fontFamily: "Avenir",
                                        fontWeight: FontWeight.w400,
                                        fontSize: 14,
                                        height: 1,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Align(
                                alignment: Alignment.bottomLeft,
                                child: Opacity(
                                  opacity: 0.59961,
                                  child: Text(
                                    "Dinner",
                                    textAlign: TextAlign.left,
                                    style: TextStyle(
                                      color: AppColors.primaryText,
                                      fontFamily: "Avenir",
                                      fontWeight: FontWeight.w400,
                                      fontSize: 14,
                                      height: 1,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Align(
                          alignment: Alignment.topLeft,
                          child: Container(
                            width: 40,
                            height: 3,
                            margin: EdgeInsets.only(left: 32),
                            decoration: BoxDecoration(
                              color: Color.fromARGB(255, 66, 80, 96),
                              borderRadius: BorderRadius.all(Radius.circular(1.5)),
                            ),
                            child: Container(),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Spacer(),
                  Container(
                    height: 100,
                    margin: EdgeInsets.only(left: 16),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Align(
                          alignment: Alignment.bottomLeft,
                          child: Container(
                            width: 280,
                            height: 100,
                            decoration: BoxDecoration(
                              color: AppColors.primaryBackground,
                              boxShadow: [
                                BoxShadow(
                                  color: Color.fromARGB(51, 169, 202, 235),
                                  offset: Offset(0, 0),
                                  blurRadius: 14,
                                ),
                              ],
                              borderRadius: BorderRadius.all(Radius.circular(10)),
                            ),
                            child: Row(
                              children: [
                                Container(
                                  width: 79,
                                  height: 86,
                                  margin: EdgeInsets.only(left: 7),
                                  child: Image.asset(
                                    "assets/images/bitmap-6.png",
                                    fit: BoxFit.none,
                                  ),
                                ),
                                Spacer(),
                                Container(
                                  width: 144,
                                  height: 59,
                                  margin: EdgeInsets.only(right: 29),
                                  child: Stack(
                                    alignment: Alignment.center,
                                    children: [
                                      Positioned(
                                        left: 0,
                                        top: -3,
                                        right: 3,
                                        bottom: 0,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.stretch,
                                          children: [
                                            Text(
                                              "Italiano Restaurant",
                                              textAlign: TextAlign.left,
                                              style: TextStyle(
                                                color: AppColors.primaryText,
                                                fontFamily: "Avenir",
                                                fontWeight: FontWeight.w800,
                                                fontSize: 16,
                                                height: 1,
                                              ),
                                            ),
                                            Spacer(),
                                            Align(
                                              alignment: Alignment.topLeft,
                                              child: Container(
                                                width: 60,
                                                height: 12,
                                                child: Image.asset(
                                                  "assets/images/rating-3.png",
                                                  fit: BoxFit.none,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Positioned(
                                        left: 0,
                                        right: 0,
                                        child: Row(
                                          children: [
                                            Container(
                                              width: 8,
                                              height: 12,
                                              child: Image.asset(
                                                "assets/images/maps-and-flags-3.png",
                                                fit: BoxFit.none,
                                              ),
                                            ),
                                            Expanded(
                                              flex: 1,
                                              child: Container(
                                                margin: EdgeInsets.only(left: 10),
                                                child: Opacity(
                                                  opacity: 0.59961,
                                                  child: Text(
                                                    "Nayasharak - 14 KM",
                                                    textAlign: TextAlign.left,
                                                    style: TextStyle(
                                                      color: AppColors.primaryText,
                                                      fontFamily: "Avenir",
                                                      fontWeight: FontWeight.w400,
                                                      fontSize: 14,
                                                      height: 1,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Spacer(),
                        Align(
                          alignment: Alignment.bottomLeft,
                          child: Container(
                            width: 280,
                            height: 100,
                            decoration: BoxDecoration(
                              color: AppColors.primaryBackground,
                              boxShadow: [
                                BoxShadow(
                                  color: Color.fromARGB(51, 169, 202, 235),
                                  offset: Offset(0, 0),
                                  blurRadius: 14,
                                ),
                              ],
                              borderRadius: BorderRadius.all(Radius.circular(10)),
                            ),
                            child: Row(
                              children: [
                                Container(
                                  width: 79,
                                  height: 86,
                                  margin: EdgeInsets.only(left: 7),
                                  child: Image.asset(
                                    "assets/images/bitmap-11.png",
                                    fit: BoxFit.none,
                                  ),
                                ),
                                Spacer(),
                                Container(
                                  width: 144,
                                  height: 59,
                                  margin: EdgeInsets.only(right: 29),
                                  child: Stack(
                                    alignment: Alignment.center,
                                    children: [
                                      Positioned(
                                        left: 0,
                                        top: -3,
                                        right: 3,
                                        bottom: 0,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.stretch,
                                          children: [
                                            Text(
                                              "Italiano Restaurant",
                                              textAlign: TextAlign.left,
                                              style: TextStyle(
                                                color: AppColors.primaryText,
                                                fontFamily: "Avenir",
                                                fontWeight: FontWeight.w800,
                                                fontSize: 16,
                                                height: 1,
                                              ),
                                            ),
                                            Spacer(),
                                            Align(
                                              alignment: Alignment.topLeft,
                                              child: Container(
                                                width: 60,
                                                height: 12,
                                                child: Image.asset(
                                                  "assets/images/rating-3.png",
                                                  fit: BoxFit.none,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Positioned(
                                        left: 0,
                                        right: 0,
                                        child: Row(
                                          children: [
                                            Container(
                                              width: 8,
                                              height: 12,
                                              child: GoogleMap(
                                                onMapCreated: (controller) {
                                                
                                                },
                                              ),
                                            ),
                                            Expanded(
                                              flex: 1,
                                              child: Container(
                                                margin: EdgeInsets.only(left: 10),
                                                child: Opacity(
                                                  opacity: 0.59961,
                                                  child: Text(
                                                    "Nayasharak - 14 KM",
                                                    textAlign: TextAlign.left,
                                                    style: TextStyle(
                                                      color: AppColors.primaryText,
                                                      fontFamily: "Avenir",
                                                      fontWeight: FontWeight.w400,
                                                      fontSize: 14,
                                                      height: 1,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Positioned(
              right: 20,
              bottom: 40,
              child: GoogleMap(
                onMapCreated: (controller) {
                
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}