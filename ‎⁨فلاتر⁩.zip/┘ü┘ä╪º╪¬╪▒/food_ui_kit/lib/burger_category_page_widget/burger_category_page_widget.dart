/*
*  burger_category_page_widget.dart
*  Food UI Kit
*
*  Created by [Author].
*  Copyright © 2018 [Company]. All rights reserved.
    */

import 'package:flutter/material.dart';
import 'package:food_ui_kit/burger_order_app_details_widget/burger_order_app_details_widget.dart';
import 'package:food_ui_kit/food_category_widget/food_category_widget.dart';
import 'package:food_ui_kit/values/values.dart';


class BurgerCategoryPageWidget extends StatelessWidget {
  
  void onBackPressed(BuildContext context) => Navigator.push(context, MaterialPageRoute(builder: (context) => BurgerOrderAppDetailsWidget()));
  
  void onCartPressed(BuildContext context) => Navigator.push(context, MaterialPageRoute(builder: (context) => FoodCategoryWidget()));
  
  @override
  Widget build(BuildContext context) {
  
    return Scaffold(
      body: Container(
        constraints: BoxConstraints.expand(),
        decoration: BoxDecoration(
          color: Color.fromARGB(255, 250, 250, 250),
        ),
        child: Stack(
          alignment: Alignment.topCenter,
          children: [
            Positioned(
              left: 0,
              top: 0,
              right: 0,
              child: Container(
                height: 820,
                decoration: BoxDecoration(
                  color: Color.fromARGB(255, 250, 250, 250),
                ),
                child: Container(),
              ),
            ),
            Positioned(
              left: 0,
              top: 0,
              right: 0,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    height: 81,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.end,
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Container(
                          height: 22,
                          margin: EdgeInsets.symmetric(horizontal: 15),
                          child: Row(
                            children: [
                              Container(
                                width: 13,
                                height: 19,
                                child: FlatButton(
                                  onPressed: () => this.onBackPressed(context),
                                  color: Color.fromARGB(0, 0, 0, 0),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.all(Radius.circular(0)),
                                  ),
                                  textColor: Color.fromARGB(255, 0, 0, 0),
                                  padding: EdgeInsets.all(0),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Image.asset("assets/images/back-3.png",),
                                      SizedBox(
                                        width: 10,
                                      ),
                                      Text(
                                        "",
                                        textAlign: TextAlign.left,
                                        style: TextStyle(
                                          color: Color.fromARGB(255, 0, 0, 0),
                                          fontWeight: FontWeight.w400,
                                          fontSize: 12,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.only(left: 29),
                                child: Text(
                                  "Burger Category",
                                  textAlign: TextAlign.left,
                                  style: TextStyle(
                                    color: AppColors.primaryText,
                                    fontFamily: "Avenir",
                                    fontWeight: FontWeight.w800,
                                    fontSize: 16,
                                  ),
                                ),
                              ),
                              Spacer(),
                              Align(
                                alignment: Alignment.topLeft,
                                child: Container(
                                  width: 16,
                                  height: 18,
                                  margin: EdgeInsets.only(right: 24),
                                  child: Image.asset(
                                    "assets/images/003-notification-1.png",
                                    fit: BoxFit.none,
                                  ),
                                ),
                              ),
                              Container(
                                width: 14,
                                height: 18,
                                child: FlatButton(
                                  onPressed: () => this.onCartPressed(context),
                                  color: Color.fromARGB(0, 0, 0, 0),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.all(Radius.circular(0)),
                                  ),
                                  textColor: Color.fromARGB(255, 0, 0, 0),
                                  padding: EdgeInsets.all(0),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Image.asset("assets/images/cart.png",),
                                      SizedBox(
                                        width: 10,
                                      ),
                                      Text(
                                        "",
                                        textAlign: TextAlign.left,
                                        style: TextStyle(
                                          color: Color.fromARGB(255, 0, 0, 0),
                                          fontWeight: FontWeight.w400,
                                          fontSize: 12,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    height: 733,
                    margin: EdgeInsets.only(left: 16, top: 20, right: 16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Container(
                          height: 174,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Align(
                                alignment: Alignment.topLeft,
                                child: Container(
                                  width: 166,
                                  height: 174,
                                  child: Stack(
                                    alignment: Alignment.center,
                                    children: [
                                      Positioned(
                                        left: 0,
                                        top: 14,
                                        right: 0,
                                        child: Opacity(
                                          opacity: 0.05,
                                          child: Container(
                                            height: 160,
                                            decoration: BoxDecoration(
                                              color: AppColors.ternaryBackground,
                                              borderRadius: BorderRadius.all(Radius.circular(14)),
                                            ),
                                            child: Container(),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        left: 0,
                                        right: 0,
                                        child: Container(
                                          height: 174,
                                          decoration: BoxDecoration(
                                            color: AppColors.secondaryBackground,
                                            borderRadius: BorderRadius.all(Radius.circular(14)),
                                          ),
                                          child: Container(),
                                        ),
                                      ),
                                      Positioned(
                                        left: 15,
                                        top: 9,
                                        right: 9,
                                        bottom: 11,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.stretch,
                                          children: [
                                            Align(
                                              alignment: Alignment.topRight,
                                              child: Container(
                                                width: 15,
                                                height: 14,
                                                child: Image.asset(
                                                  "assets/images/favorite-heart-button-3.png",
                                                  fit: BoxFit.none,
                                                ),
                                              ),
                                            ),
                                            Align(
                                              alignment: Alignment.topCenter,
                                              child: Container(
                                                width: 110,
                                                height: 75,
                                                margin: EdgeInsets.only(top: 1),
                                                child: Image.asset(
                                                  "assets/images/burger-10963.png",
                                                  fit: BoxFit.none,
                                                ),
                                              ),
                                            ),
                                            Spacer(),
                                            Align(
                                              alignment: Alignment.topLeft,
                                              child: Container(
                                                margin: EdgeInsets.only(bottom: 5),
                                                child: Text(
                                                  "Hot Spicy Burger",
                                                  textAlign: TextAlign.left,
                                                  style: TextStyle(
                                                    color: AppColors.primaryText,
                                                    fontFamily: "Avenir",
                                                    fontWeight: FontWeight.w800,
                                                    fontSize: 14,
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Container(
                                              height: 17,
                                              margin: EdgeInsets.only(right: 6),
                                              child: Row(
                                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                                children: [
                                                  Align(
                                                    alignment: Alignment.bottomLeft,
                                                    child: Opacity(
                                                      opacity: 0.60156,
                                                      child: Text(
                                                        "\$14",
                                                        textAlign: TextAlign.left,
                                                        style: TextStyle(
                                                          color: AppColors.primaryText,
                                                          fontFamily: "Avenir",
                                                          fontWeight: FontWeight.w800,
                                                          fontSize: 12,
                                                          height: 1,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Spacer(),
                                                  Align(
                                                    alignment: Alignment.bottomLeft,
                                                    child: Container(
                                                      width: 37,
                                                      height: 12,
                                                      margin: EdgeInsets.only(bottom: 2),
                                                      child: Row(
                                                        children: [
                                                          Container(
                                                            width: 13,
                                                            height: 12,
                                                            child: Image.asset(
                                                              "assets/images/path-21.png",
                                                              fit: BoxFit.none,
                                                            ),
                                                          ),
                                                          Expanded(
                                                            flex: 1,
                                                            child: Container(
                                                              margin: EdgeInsets.only(left: 5, right: 3),
                                                              child: Opacity(
                                                                opacity: 0.59961,
                                                                child: Text(
                                                                  "4.5",
                                                                  textAlign: TextAlign.left,
                                                                  style: TextStyle(
                                                                    color: AppColors.primaryText,
                                                                    fontFamily: "Avenir",
                                                                    fontWeight: FontWeight.w400,
                                                                    fontSize: 12,
                                                                    height: 1.16667,
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Spacer(),
                              Align(
                                alignment: Alignment.topLeft,
                                child: Container(
                                  width: 166,
                                  height: 174,
                                  child: Stack(
                                    alignment: Alignment.topCenter,
                                    children: [
                                      Positioned(
                                        left: 0,
                                        top: 0,
                                        right: 0,
                                        bottom: 0,
                                        child: Stack(
                                          alignment: Alignment.center,
                                          children: [
                                            Positioned(
                                              left: 0,
                                              top: 14,
                                              right: 0,
                                              child: Opacity(
                                                opacity: 0.05,
                                                child: Container(
                                                  height: 160,
                                                  decoration: BoxDecoration(
                                                    color: AppColors.ternaryBackground,
                                                    borderRadius: BorderRadius.all(Radius.circular(14)),
                                                  ),
                                                  child: Container(),
                                                ),
                                              ),
                                            ),
                                            Positioned(
                                              left: 0,
                                              right: 0,
                                              child: Container(
                                                height: 174,
                                                decoration: BoxDecoration(
                                                  color: AppColors.secondaryBackground,
                                                  borderRadius: BorderRadius.all(Radius.circular(14)),
                                                ),
                                                child: Container(),
                                              ),
                                            ),
                                            Positioned(
                                              left: 15,
                                              top: 9,
                                              right: 9,
                                              bottom: 11,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                                children: [
                                                  Align(
                                                    alignment: Alignment.topRight,
                                                    child: Container(
                                                      width: 15,
                                                      height: 14,
                                                      child: Image.asset(
                                                        "assets/images/favorite-heart-button-2.png",
                                                        fit: BoxFit.none,
                                                      ),
                                                    ),
                                                  ),
                                                  Spacer(),
                                                  Align(
                                                    alignment: Alignment.topLeft,
                                                    child: Container(
                                                      margin: EdgeInsets.only(bottom: 5),
                                                      child: Text(
                                                        "Veggie Burgers",
                                                        textAlign: TextAlign.left,
                                                        style: TextStyle(
                                                          color: AppColors.primaryText,
                                                          fontFamily: "Avenir",
                                                          fontWeight: FontWeight.w800,
                                                          fontSize: 14,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    height: 17,
                                                    margin: EdgeInsets.only(right: 6),
                                                    child: Row(
                                                      crossAxisAlignment: CrossAxisAlignment.stretch,
                                                      children: [
                                                        Align(
                                                          alignment: Alignment.bottomLeft,
                                                          child: Opacity(
                                                            opacity: 0.60156,
                                                            child: Text(
                                                              "\$20",
                                                              textAlign: TextAlign.left,
                                                              style: TextStyle(
                                                                color: AppColors.primaryText,
                                                                fontFamily: "Avenir",
                                                                fontWeight: FontWeight.w800,
                                                                fontSize: 12,
                                                                height: 1,
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                        Spacer(),
                                                        Align(
                                                          alignment: Alignment.bottomLeft,
                                                          child: Container(
                                                            width: 37,
                                                            height: 12,
                                                            margin: EdgeInsets.only(bottom: 2),
                                                            child: Row(
                                                              children: [
                                                                Container(
                                                                  width: 13,
                                                                  height: 12,
                                                                  child: Image.asset(
                                                                    "assets/images/path-21.png",
                                                                    fit: BoxFit.none,
                                                                  ),
                                                                ),
                                                                Expanded(
                                                                  flex: 1,
                                                                  child: Container(
                                                                    margin: EdgeInsets.only(left: 5, right: 3),
                                                                    child: Opacity(
                                                                      opacity: 0.59961,
                                                                      child: Text(
                                                                        "4.3",
                                                                        textAlign: TextAlign.left,
                                                                        style: TextStyle(
                                                                          color: AppColors.primaryText,
                                                                          fontFamily: "Avenir",
                                                                          fontWeight: FontWeight.w400,
                                                                          fontSize: 12,
                                                                          height: 1.16667,
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Positioned(
                                        top: 20,
                                        child: Image.asset(
                                          "assets/images/unnamed.png",
                                          fit: BoxFit.none,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          height: 174,
                          margin: EdgeInsets.only(top: 15),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Align(
                                alignment: Alignment.topLeft,
                                child: Container(
                                  width: 166,
                                  height: 174,
                                  child: Stack(
                                    alignment: Alignment.topCenter,
                                    children: [
                                      Positioned(
                                        left: 0,
                                        top: 0,
                                        right: 0,
                                        bottom: 0,
                                        child: Stack(
                                          alignment: Alignment.center,
                                          children: [
                                            Positioned(
                                              left: 0,
                                              top: 14,
                                              right: 0,
                                              child: Opacity(
                                                opacity: 0.05,
                                                child: Container(
                                                  height: 160,
                                                  decoration: BoxDecoration(
                                                    color: AppColors.ternaryBackground,
                                                    borderRadius: BorderRadius.all(Radius.circular(14)),
                                                  ),
                                                  child: Container(),
                                                ),
                                              ),
                                            ),
                                            Positioned(
                                              left: 0,
                                              right: 0,
                                              child: Container(
                                                height: 174,
                                                decoration: BoxDecoration(
                                                  color: AppColors.secondaryBackground,
                                                  borderRadius: BorderRadius.all(Radius.circular(14)),
                                                ),
                                                child: Container(),
                                              ),
                                            ),
                                            Positioned(
                                              left: 15,
                                              top: 9,
                                              right: 9,
                                              bottom: 11,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                                children: [
                                                  Align(
                                                    alignment: Alignment.topRight,
                                                    child: Container(
                                                      width: 15,
                                                      height: 14,
                                                      child: Image.asset(
                                                        "assets/images/favorite-heart-button-2.png",
                                                        fit: BoxFit.none,
                                                      ),
                                                    ),
                                                  ),
                                                  Spacer(),
                                                  Align(
                                                    alignment: Alignment.topLeft,
                                                    child: Container(
                                                      margin: EdgeInsets.only(bottom: 5),
                                                      child: Text(
                                                        "Chicken Burger",
                                                        textAlign: TextAlign.left,
                                                        style: TextStyle(
                                                          color: AppColors.primaryText,
                                                          fontFamily: "Avenir",
                                                          fontWeight: FontWeight.w800,
                                                          fontSize: 14,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    height: 17,
                                                    margin: EdgeInsets.only(right: 6),
                                                    child: Row(
                                                      crossAxisAlignment: CrossAxisAlignment.stretch,
                                                      children: [
                                                        Align(
                                                          alignment: Alignment.bottomLeft,
                                                          child: Opacity(
                                                            opacity: 0.60156,
                                                            child: Text(
                                                              "\$22",
                                                              textAlign: TextAlign.left,
                                                              style: TextStyle(
                                                                color: AppColors.primaryText,
                                                                fontFamily: "Avenir",
                                                                fontWeight: FontWeight.w800,
                                                                fontSize: 12,
                                                                height: 1,
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                        Spacer(),
                                                        Align(
                                                          alignment: Alignment.bottomLeft,
                                                          child: Container(
                                                            width: 37,
                                                            height: 12,
                                                            margin: EdgeInsets.only(bottom: 2),
                                                            child: Row(
                                                              children: [
                                                                Container(
                                                                  width: 13,
                                                                  height: 12,
                                                                  child: Image.asset(
                                                                    "assets/images/path-21.png",
                                                                    fit: BoxFit.none,
                                                                  ),
                                                                ),
                                                                Expanded(
                                                                  flex: 1,
                                                                  child: Container(
                                                                    margin: EdgeInsets.only(left: 5, right: 3),
                                                                    child: Opacity(
                                                                      opacity: 0.59961,
                                                                      child: Text(
                                                                        "4.0",
                                                                        textAlign: TextAlign.left,
                                                                        style: TextStyle(
                                                                          color: AppColors.primaryText,
                                                                          fontFamily: "Avenir",
                                                                          fontWeight: FontWeight.w400,
                                                                          fontSize: 12,
                                                                          height: 1.16667,
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Positioned(
                                        top: 20,
                                        child: Image.asset(
                                          "assets/images/burger-10956-3.png",
                                          fit: BoxFit.none,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Spacer(),
                              Align(
                                alignment: Alignment.topLeft,
                                child: Container(
                                  width: 166,
                                  height: 174,
                                  child: Stack(
                                    alignment: Alignment.topCenter,
                                    children: [
                                      Positioned(
                                        left: 0,
                                        top: 0,
                                        right: 0,
                                        bottom: 0,
                                        child: Stack(
                                          alignment: Alignment.center,
                                          children: [
                                            Positioned(
                                              left: 0,
                                              top: 14,
                                              right: 0,
                                              child: Opacity(
                                                opacity: 0.05,
                                                child: Container(
                                                  height: 160,
                                                  decoration: BoxDecoration(
                                                    color: AppColors.ternaryBackground,
                                                    borderRadius: BorderRadius.all(Radius.circular(14)),
                                                  ),
                                                  child: Container(),
                                                ),
                                              ),
                                            ),
                                            Positioned(
                                              left: 0,
                                              right: 0,
                                              child: Container(
                                                height: 174,
                                                decoration: BoxDecoration(
                                                  color: AppColors.secondaryBackground,
                                                  borderRadius: BorderRadius.all(Radius.circular(14)),
                                                ),
                                                child: Container(),
                                              ),
                                            ),
                                            Positioned(
                                              left: 15,
                                              top: 9,
                                              right: 9,
                                              bottom: 11,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                                children: [
                                                  Align(
                                                    alignment: Alignment.topRight,
                                                    child: Container(
                                                      width: 15,
                                                      height: 14,
                                                      child: Image.asset(
                                                        "assets/images/favorite-heart-button-3.png",
                                                        fit: BoxFit.none,
                                                      ),
                                                    ),
                                                  ),
                                                  Spacer(),
                                                  Align(
                                                    alignment: Alignment.topLeft,
                                                    child: Container(
                                                      margin: EdgeInsets.only(bottom: 5),
                                                      child: Text(
                                                        "Black Bean Burgers",
                                                        textAlign: TextAlign.left,
                                                        style: TextStyle(
                                                          color: AppColors.primaryText,
                                                          fontFamily: "Avenir",
                                                          fontWeight: FontWeight.w800,
                                                          fontSize: 14,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    height: 17,
                                                    margin: EdgeInsets.only(right: 6),
                                                    child: Row(
                                                      crossAxisAlignment: CrossAxisAlignment.stretch,
                                                      children: [
                                                        Align(
                                                          alignment: Alignment.bottomLeft,
                                                          child: Opacity(
                                                            opacity: 0.60156,
                                                            child: Text(
                                                              "\$25",
                                                              textAlign: TextAlign.left,
                                                              style: TextStyle(
                                                                color: AppColors.primaryText,
                                                                fontFamily: "Avenir",
                                                                fontWeight: FontWeight.w800,
                                                                fontSize: 12,
                                                                height: 1,
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                        Spacer(),
                                                        Align(
                                                          alignment: Alignment.bottomLeft,
                                                          child: Container(
                                                            width: 37,
                                                            height: 12,
                                                            margin: EdgeInsets.only(bottom: 2),
                                                            child: Row(
                                                              children: [
                                                                Container(
                                                                  width: 13,
                                                                  height: 12,
                                                                  child: Image.asset(
                                                                    "assets/images/path-21.png",
                                                                    fit: BoxFit.none,
                                                                  ),
                                                                ),
                                                                Expanded(
                                                                  flex: 1,
                                                                  child: Container(
                                                                    margin: EdgeInsets.only(left: 5, right: 3),
                                                                    child: Opacity(
                                                                      opacity: 0.59961,
                                                                      child: Text(
                                                                        "3.9",
                                                                        textAlign: TextAlign.left,
                                                                        style: TextStyle(
                                                                          color: AppColors.primaryText,
                                                                          fontFamily: "Avenir",
                                                                          fontWeight: FontWeight.w400,
                                                                          fontSize: 12,
                                                                          height: 1.16667,
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Positioned(
                                        top: 20,
                                        child: Image.asset(
                                          "assets/images/hiclipartcom-2.png",
                                          fit: BoxFit.none,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          height: 174,
                          margin: EdgeInsets.only(top: 11),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Align(
                                alignment: Alignment.topLeft,
                                child: Container(
                                  width: 166,
                                  height: 174,
                                  child: Stack(
                                    alignment: Alignment.topCenter,
                                    children: [
                                      Positioned(
                                        left: 0,
                                        top: 0,
                                        right: 0,
                                        bottom: 0,
                                        child: Stack(
                                          alignment: Alignment.center,
                                          children: [
                                            Positioned(
                                              left: 0,
                                              top: 14,
                                              right: 0,
                                              child: Opacity(
                                                opacity: 0.05,
                                                child: Container(
                                                  height: 160,
                                                  decoration: BoxDecoration(
                                                    color: AppColors.ternaryBackground,
                                                    borderRadius: BorderRadius.all(Radius.circular(14)),
                                                  ),
                                                  child: Container(),
                                                ),
                                              ),
                                            ),
                                            Positioned(
                                              left: 0,
                                              right: 0,
                                              child: Container(
                                                height: 174,
                                                decoration: BoxDecoration(
                                                  color: AppColors.secondaryBackground,
                                                  borderRadius: BorderRadius.all(Radius.circular(14)),
                                                ),
                                                child: Container(),
                                              ),
                                            ),
                                            Positioned(
                                              left: 15,
                                              top: 9,
                                              right: 9,
                                              bottom: 11,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                                children: [
                                                  Align(
                                                    alignment: Alignment.topRight,
                                                    child: Container(
                                                      width: 15,
                                                      height: 14,
                                                      child: Image.asset(
                                                        "assets/images/favorite-heart-button-3.png",
                                                        fit: BoxFit.none,
                                                      ),
                                                    ),
                                                  ),
                                                  Spacer(),
                                                  Align(
                                                    alignment: Alignment.topLeft,
                                                    child: Container(
                                                      margin: EdgeInsets.only(bottom: 5),
                                                      child: Text(
                                                        "Elk Burgers",
                                                        textAlign: TextAlign.left,
                                                        style: TextStyle(
                                                          color: AppColors.primaryText,
                                                          fontFamily: "Avenir",
                                                          fontWeight: FontWeight.w800,
                                                          fontSize: 14,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    height: 17,
                                                    margin: EdgeInsets.only(right: 6),
                                                    child: Row(
                                                      crossAxisAlignment: CrossAxisAlignment.stretch,
                                                      children: [
                                                        Align(
                                                          alignment: Alignment.bottomLeft,
                                                          child: Opacity(
                                                            opacity: 0.60156,
                                                            child: Text(
                                                              "\$18",
                                                              textAlign: TextAlign.left,
                                                              style: TextStyle(
                                                                color: AppColors.primaryText,
                                                                fontFamily: "Avenir",
                                                                fontWeight: FontWeight.w800,
                                                                fontSize: 12,
                                                                height: 1,
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                        Spacer(),
                                                        Align(
                                                          alignment: Alignment.bottomLeft,
                                                          child: Container(
                                                            width: 37,
                                                            height: 12,
                                                            margin: EdgeInsets.only(bottom: 2),
                                                            child: Row(
                                                              children: [
                                                                Container(
                                                                  width: 13,
                                                                  height: 12,
                                                                  child: Image.asset(
                                                                    "assets/images/path-21.png",
                                                                    fit: BoxFit.none,
                                                                  ),
                                                                ),
                                                                Expanded(
                                                                  flex: 1,
                                                                  child: Container(
                                                                    margin: EdgeInsets.only(left: 5, right: 3),
                                                                    child: Opacity(
                                                                      opacity: 0.59961,
                                                                      child: Text(
                                                                        "3.8",
                                                                        textAlign: TextAlign.left,
                                                                        style: TextStyle(
                                                                          color: AppColors.primaryText,
                                                                          fontFamily: "Avenir",
                                                                          fontWeight: FontWeight.w400,
                                                                          fontSize: 12,
                                                                          height: 1.16667,
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Positioned(
                                        top: 15,
                                        child: Image.asset(
                                          "assets/images/burger-10917-4.png",
                                          fit: BoxFit.none,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Spacer(),
                              Align(
                                alignment: Alignment.topLeft,
                                child: Container(
                                  width: 166,
                                  height: 174,
                                  child: Stack(
                                    alignment: Alignment.topCenter,
                                    children: [
                                      Positioned(
                                        left: 0,
                                        top: 0,
                                        right: 0,
                                        bottom: 0,
                                        child: Stack(
                                          alignment: Alignment.center,
                                          children: [
                                            Positioned(
                                              left: 0,
                                              top: 14,
                                              right: 0,
                                              child: Opacity(
                                                opacity: 0.05,
                                                child: Container(
                                                  height: 160,
                                                  decoration: BoxDecoration(
                                                    color: AppColors.ternaryBackground,
                                                    borderRadius: BorderRadius.all(Radius.circular(14)),
                                                  ),
                                                  child: Container(),
                                                ),
                                              ),
                                            ),
                                            Positioned(
                                              left: 0,
                                              right: 0,
                                              child: Container(
                                                height: 174,
                                                decoration: BoxDecoration(
                                                  color: AppColors.secondaryBackground,
                                                  borderRadius: BorderRadius.all(Radius.circular(14)),
                                                ),
                                                child: Container(),
                                              ),
                                            ),
                                            Positioned(
                                              left: 15,
                                              top: 9,
                                              right: 9,
                                              bottom: 11,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                                children: [
                                                  Align(
                                                    alignment: Alignment.topRight,
                                                    child: Container(
                                                      width: 15,
                                                      height: 14,
                                                      child: Image.asset(
                                                        "assets/images/favorite-heart-button-2.png",
                                                        fit: BoxFit.none,
                                                      ),
                                                    ),
                                                  ),
                                                  Spacer(),
                                                  Align(
                                                    alignment: Alignment.topLeft,
                                                    child: Container(
                                                      margin: EdgeInsets.only(bottom: 5),
                                                      child: Text(
                                                        "Bison Burgers",
                                                        textAlign: TextAlign.left,
                                                        style: TextStyle(
                                                          color: AppColors.primaryText,
                                                          fontFamily: "Avenir",
                                                          fontWeight: FontWeight.w800,
                                                          fontSize: 14,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    height: 17,
                                                    margin: EdgeInsets.only(right: 6),
                                                    child: Row(
                                                      crossAxisAlignment: CrossAxisAlignment.stretch,
                                                      children: [
                                                        Align(
                                                          alignment: Alignment.bottomLeft,
                                                          child: Opacity(
                                                            opacity: 0.60156,
                                                            child: Text(
                                                              "\$30",
                                                              textAlign: TextAlign.left,
                                                              style: TextStyle(
                                                                color: AppColors.primaryText,
                                                                fontFamily: "Avenir",
                                                                fontWeight: FontWeight.w800,
                                                                fontSize: 12,
                                                                height: 1,
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                        Spacer(),
                                                        Align(
                                                          alignment: Alignment.bottomLeft,
                                                          child: Container(
                                                            width: 37,
                                                            height: 12,
                                                            margin: EdgeInsets.only(bottom: 2),
                                                            child: Row(
                                                              children: [
                                                                Container(
                                                                  width: 13,
                                                                  height: 12,
                                                                  child: Image.asset(
                                                                    "assets/images/path-21.png",
                                                                    fit: BoxFit.none,
                                                                  ),
                                                                ),
                                                                Expanded(
                                                                  flex: 1,
                                                                  child: Container(
                                                                    margin: EdgeInsets.only(left: 5, right: 3),
                                                                    child: Opacity(
                                                                      opacity: 0.59961,
                                                                      child: Text(
                                                                        "3.5",
                                                                        textAlign: TextAlign.left,
                                                                        style: TextStyle(
                                                                          color: AppColors.primaryText,
                                                                          fontFamily: "Avenir",
                                                                          fontWeight: FontWeight.w400,
                                                                          fontSize: 12,
                                                                          height: 1.16667,
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Positioned(
                                        top: 20,
                                        child: Image.asset(
                                          "assets/images/hiclipartcom-1.png",
                                          fit: BoxFit.none,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Spacer(),
                        Container(
                          height: 174,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Align(
                                alignment: Alignment.bottomLeft,
                                child: Container(
                                  width: 166,
                                  height: 174,
                                  child: Stack(
                                    alignment: Alignment.center,
                                    children: [
                                      Positioned(
                                        left: 0,
                                        top: 14,
                                        right: 0,
                                        child: Opacity(
                                          opacity: 0.05,
                                          child: Container(
                                            height: 160,
                                            decoration: BoxDecoration(
                                              color: AppColors.ternaryBackground,
                                              borderRadius: BorderRadius.all(Radius.circular(14)),
                                            ),
                                            child: Container(),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        left: 0,
                                        right: 0,
                                        child: Container(
                                          height: 174,
                                          decoration: BoxDecoration(
                                            color: AppColors.secondaryBackground,
                                            borderRadius: BorderRadius.all(Radius.circular(14)),
                                          ),
                                          child: Container(),
                                        ),
                                      ),
                                      Positioned(
                                        left: 15,
                                        top: 9,
                                        right: 9,
                                        bottom: 11,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.stretch,
                                          children: [
                                            Align(
                                              alignment: Alignment.topRight,
                                              child: Container(
                                                width: 15,
                                                height: 14,
                                                child: Image.asset(
                                                  "assets/images/favorite-heart-button-2.png",
                                                  fit: BoxFit.none,
                                                ),
                                              ),
                                            ),
                                            Spacer(),
                                            Align(
                                              alignment: Alignment.topLeft,
                                              child: Container(
                                                margin: EdgeInsets.only(bottom: 5),
                                                child: Text(
                                                  "Mushroom Burgers",
                                                  textAlign: TextAlign.left,
                                                  style: TextStyle(
                                                    color: AppColors.primaryText,
                                                    fontFamily: "Avenir",
                                                    fontWeight: FontWeight.w800,
                                                    fontSize: 14,
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Container(
                                              height: 17,
                                              margin: EdgeInsets.only(right: 6),
                                              child: Row(
                                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                                children: [
                                                  Align(
                                                    alignment: Alignment.bottomLeft,
                                                    child: Opacity(
                                                      opacity: 0.60156,
                                                      child: Text(
                                                        "\$15",
                                                        textAlign: TextAlign.left,
                                                        style: TextStyle(
                                                          color: AppColors.primaryText,
                                                          fontFamily: "Avenir",
                                                          fontWeight: FontWeight.w800,
                                                          fontSize: 12,
                                                          height: 1,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Spacer(),
                                                  Align(
                                                    alignment: Alignment.bottomLeft,
                                                    child: Container(
                                                      width: 37,
                                                      height: 12,
                                                      margin: EdgeInsets.only(bottom: 2),
                                                      child: Row(
                                                        children: [
                                                          Container(
                                                            width: 13,
                                                            height: 12,
                                                            child: Image.asset(
                                                              "assets/images/path-21.png",
                                                              fit: BoxFit.none,
                                                            ),
                                                          ),
                                                          Expanded(
                                                            flex: 1,
                                                            child: Container(
                                                              margin: EdgeInsets.only(left: 5, right: 3),
                                                              child: Opacity(
                                                                opacity: 0.59961,
                                                                child: Text(
                                                                  "3.4",
                                                                  textAlign: TextAlign.left,
                                                                  style: TextStyle(
                                                                    color: AppColors.primaryText,
                                                                    fontFamily: "Avenir",
                                                                    fontWeight: FontWeight.w400,
                                                                    fontSize: 12,
                                                                    height: 1.16667,
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Positioned(
                                        left: 17,
                                        top: 18,
                                        right: 19,
                                        child: Image.asset(
                                          "assets/images/burger-10909.png",
                                          fit: BoxFit.none,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Spacer(),
                              Align(
                                alignment: Alignment.bottomLeft,
                                child: Container(
                                  width: 166,
                                  height: 174,
                                  child: Stack(
                                    alignment: Alignment.topCenter,
                                    children: [
                                      Positioned(
                                        left: 0,
                                        top: 0,
                                        right: 0,
                                        bottom: 0,
                                        child: Stack(
                                          alignment: Alignment.center,
                                          children: [
                                            Positioned(
                                              left: 0,
                                              top: 14,
                                              right: 0,
                                              child: Opacity(
                                                opacity: 0.05,
                                                child: Container(
                                                  height: 160,
                                                  decoration: BoxDecoration(
                                                    color: AppColors.ternaryBackground,
                                                    borderRadius: BorderRadius.all(Radius.circular(14)),
                                                  ),
                                                  child: Container(),
                                                ),
                                              ),
                                            ),
                                            Positioned(
                                              left: 0,
                                              right: 0,
                                              child: Container(
                                                height: 174,
                                                decoration: BoxDecoration(
                                                  color: AppColors.secondaryBackground,
                                                  borderRadius: BorderRadius.all(Radius.circular(14)),
                                                ),
                                                child: Container(),
                                              ),
                                            ),
                                            Positioned(
                                              left: 15,
                                              top: 9,
                                              right: 9,
                                              bottom: 11,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                                children: [
                                                  Align(
                                                    alignment: Alignment.topRight,
                                                    child: Container(
                                                      width: 15,
                                                      height: 14,
                                                      child: Image.asset(
                                                        "assets/images/favorite-heart-button-3.png",
                                                        fit: BoxFit.none,
                                                      ),
                                                    ),
                                                  ),
                                                  Spacer(),
                                                  Align(
                                                    alignment: Alignment.topLeft,
                                                    child: Container(
                                                      margin: EdgeInsets.only(bottom: 5),
                                                      child: Text(
                                                        "Salmon Burgers",
                                                        textAlign: TextAlign.left,
                                                        style: TextStyle(
                                                          color: AppColors.primaryText,
                                                          fontFamily: "Avenir",
                                                          fontWeight: FontWeight.w800,
                                                          fontSize: 14,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    height: 17,
                                                    margin: EdgeInsets.only(right: 6),
                                                    child: Row(
                                                      crossAxisAlignment: CrossAxisAlignment.stretch,
                                                      children: [
                                                        Align(
                                                          alignment: Alignment.bottomLeft,
                                                          child: Opacity(
                                                            opacity: 0.60156,
                                                            child: Text(
                                                              "\$35",
                                                              textAlign: TextAlign.left,
                                                              style: TextStyle(
                                                                color: AppColors.primaryText,
                                                                fontFamily: "Avenir",
                                                                fontWeight: FontWeight.w800,
                                                                fontSize: 12,
                                                                height: 1,
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                        Spacer(),
                                                        Align(
                                                          alignment: Alignment.bottomLeft,
                                                          child: Container(
                                                            width: 37,
                                                            height: 12,
                                                            margin: EdgeInsets.only(bottom: 2),
                                                            child: Row(
                                                              children: [
                                                                Container(
                                                                  width: 13,
                                                                  height: 12,
                                                                  child: Image.asset(
                                                                    "assets/images/path-21.png",
                                                                    fit: BoxFit.none,
                                                                  ),
                                                                ),
                                                                Expanded(
                                                                  flex: 1,
                                                                  child: Container(
                                                                    margin: EdgeInsets.only(left: 5, right: 3),
                                                                    child: Opacity(
                                                                      opacity: 0.59961,
                                                                      child: Text(
                                                                        "3.3",
                                                                        textAlign: TextAlign.left,
                                                                        style: TextStyle(
                                                                          color: AppColors.primaryText,
                                                                          fontFamily: "Avenir",
                                                                          fontWeight: FontWeight.w400,
                                                                          fontSize: 12,
                                                                          height: 1.16667,
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Positioned(
                                        top: 20,
                                        child: Image.asset(
                                          "assets/images/hiclipartcom.png",
                                          fit: BoxFit.none,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}