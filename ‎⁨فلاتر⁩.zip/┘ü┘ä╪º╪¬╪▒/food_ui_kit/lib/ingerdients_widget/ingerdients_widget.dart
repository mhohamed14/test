/*
*  ingerdients_widget.dart
*  Food UI Kit
*
*  Created by [Author].
*  Copyright © 2018 [Company]. All rights reserved.
    */

import 'package:flutter/material.dart';
import 'package:food_ui_kit/burger_order_app_details_widget/burger_order_app_details_widget.dart';
import 'package:food_ui_kit/user_review_widget/user_review_widget.dart';
import 'package:food_ui_kit/values/values.dart';


class IngerdientsWidget extends StatelessWidget {
  
  void onBackPressed(BuildContext context) => Navigator.push(context, MaterialPageRoute(builder: (context) => UserReviewWidget()));
  
  void onAddToCartButtonPressed(BuildContext context) => Navigator.push(context, MaterialPageRoute(builder: (context) => BurgerOrderAppDetailsWidget()));
  
  void onGroup4Pressed(BuildContext context) {
  
  }
  
  void onGroup4CopyPressed(BuildContext context) {
  
  }
  
  @override
  Widget build(BuildContext context) {
  
    return Scaffold(
      body: Container(
        constraints: BoxConstraints.expand(),
        decoration: BoxDecoration(
          color: Color.fromARGB(255, 255, 255, 255),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              height: 300,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  Positioned(
                    left: 16,
                    top: 0,
                    right: 0,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          width: 40,
                          height: 150,
                          margin: EdgeInsets.only(top: 130),
                          child: Stack(
                            alignment: Alignment.center,
                            children: [
                              Positioned(
                                left: -1,
                                right: -1,
                                child: Image.asset(
                                  "assets/images/group-12.png",
                                  fit: BoxFit.none,
                                ),
                              ),
                              Positioned(
                                left: -1,
                                top: -1,
                                right: -1,
                                bottom: -1,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.stretch,
                                  children: [
                                    Container(
                                      height: 41,
                                      child: Image.asset(
                                        "assets/images/group-10-2.png",
                                        fit: BoxFit.none,
                                      ),
                                    ),
                                    Spacer(),
                                    Container(
                                      height: 41,
                                      child: Image.asset(
                                        "assets/images/group-11-2.png",
                                        fit: BoxFit.none,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        Spacer(),
                        Container(
                          width: 295,
                          height: 300,
                          child: Stack(
                            alignment: Alignment.center,
                            children: [
                              Positioned(
                                right: 0,
                                child: Container(
                                  width: 215,
                                  height: 300,
                                  decoration: BoxDecoration(
                                    color: Color.fromARGB(255, 255, 245, 176),
                                    boxShadow: [
                                      Shadows.secondaryShadow,
                                    ],
                                    borderRadius: BorderRadius.all(Radius.circular(50)),
                                  ),
                                  child: Container(),
                                ),
                              ),
                              Positioned(
                                top: 84,
                                right: 45,
                                child: Image.asset(
                                  "assets/images/burger-10956.png",
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Positioned(
                    left: 0,
                    top: 0,
                    right: 0,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Container(
                          width: 13,
                          height: 19,
                          margin: EdgeInsets.only(left: 16),
                          child: FlatButton(
                            onPressed: () => this.onBackPressed(context),
                            color: Color.fromARGB(0, 0, 0, 0),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.all(Radius.circular(0)),
                            ),
                            textColor: Color.fromARGB(255, 0, 0, 0),
                            padding: EdgeInsets.all(0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Image.asset("assets/images/back-3.png",),
                                SizedBox(
                                  width: 10,
                                ),
                                Text(
                                  "",
                                  textAlign: TextAlign.left,
                                  style: TextStyle(
                                    color: Color.fromARGB(255, 0, 0, 0),
                                    fontWeight: FontWeight.w400,
                                    fontSize: 12,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Spacer(),
                        Container(
                          width: 14,
                          height: 18,
                          margin: EdgeInsets.only(right: 16),
                          child: Image.asset(
                            "assets/images/cart.png",
                            fit: BoxFit.none,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              height: 121,
              margin: EdgeInsets.only(left: 16, top: 25, right: 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    height: 82,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Container(
                          height: 33,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Align(
                                alignment: Alignment.topLeft,
                                child: Text(
                                  "Chicken Burger",
                                  textAlign: TextAlign.left,
                                  style: TextStyle(
                                    color: AppColors.primaryText,
                                    fontFamily: "Avenir",
                                    fontWeight: FontWeight.w800,
                                    fontSize: 24,
                                    height: 0.91667,
                                  ),
                                ),
                              ),
                              Spacer(),
                              Align(
                                alignment: Alignment.topLeft,
                                child: Container(
                                  width: 30,
                                  height: 30,
                                  margin: EdgeInsets.only(top: 2),
                                  child: Image.asset(
                                    "assets/images/favorite-heart-button.png",
                                    fit: BoxFit.none,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Align(
                          alignment: Alignment.topLeft,
                          child: Container(
                            width: 202,
                            height: 19,
                            margin: EdgeInsets.only(top: 5),
                            child: Row(
                              children: [
                                Container(
                                  width: 8,
                                  height: 12,
                                  child: Image.asset(
                                    "assets/images/maps-and-flags-3.png",
                                    fit: BoxFit.none,
                                  ),
                                ),
                                Expanded(
                                  flex: 1,
                                  child: Container(
                                    margin: EdgeInsets.only(left: 10, right: 1),
                                    child: Opacity(
                                      opacity: 0.59961,
                                      child: Text(
                                        "Italiano Restaurant and Coffe",
                                        textAlign: TextAlign.left,
                                        style: TextStyle(
                                          color: AppColors.primaryText,
                                          fontFamily: "Avenir",
                                          fontWeight: FontWeight.w400,
                                          fontSize: 14,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Spacer(),
                        Container(
                          height: 13,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Align(
                                alignment: Alignment.bottomLeft,
                                child: Container(
                                  width: 75,
                                  height: 13,
                                  child: Row(
                                    children: [
                                      Container(
                                        width: 15,
                                        height: 14,
                                        child: Image.asset(
                                          "assets/images/path-7.png",
                                          fit: BoxFit.none,
                                        ),
                                      ),
                                      Spacer(),
                                      Container(
                                        margin: EdgeInsets.only(right: 7),
                                        child: Opacity(
                                          opacity: 0.59961,
                                          child: Text(
                                            "4.3 (132)",
                                            textAlign: TextAlign.left,
                                            style: TextStyle(
                                              color: AppColors.primaryText,
                                              fontFamily: "Avenir",
                                              fontWeight: FontWeight.w400,
                                              fontSize: 12,
                                              height: 1.16667,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Align(
                                alignment: Alignment.bottomLeft,
                                child: Container(
                                  width: 62,
                                  height: 12,
                                  margin: EdgeInsets.only(left: 57),
                                  child: Row(
                                    children: [
                                      Container(
                                        width: 12,
                                        height: 12,
                                        child: Image.asset(
                                          "assets/images/002-clock-2.png",
                                          fit: BoxFit.none,
                                        ),
                                      ),
                                      Expanded(
                                        flex: 1,
                                        child: Container(
                                          margin: EdgeInsets.only(left: 7, right: 6),
                                          child: Opacity(
                                            opacity: 0.59961,
                                            child: Text(
                                              "30 min",
                                              textAlign: TextAlign.left,
                                              style: TextStyle(
                                                color: AppColors.primaryText,
                                                fontFamily: "Avenir",
                                                fontWeight: FontWeight.w400,
                                                fontSize: 12,
                                                height: 1.16667,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Spacer(),
                              Align(
                                alignment: Alignment.bottomLeft,
                                child: Container(
                                  width: 58,
                                  height: 12,
                                  child: Row(
                                    children: [
                                      Container(
                                        width: 10,
                                        height: 13,
                                        child: Image.asset(
                                          "assets/images/maps-and-flags-2.png",
                                          fit: BoxFit.none,
                                        ),
                                      ),
                                      Expanded(
                                        flex: 1,
                                        child: Container(
                                          margin: EdgeInsets.symmetric(horizontal: 6),
                                          child: Opacity(
                                            opacity: 0.59961,
                                            child: Text(
                                              "1.4 km",
                                              textAlign: TextAlign.left,
                                              style: TextStyle(
                                                color: AppColors.primaryText,
                                                fontFamily: "Avenir",
                                                fontWeight: FontWeight.w400,
                                                fontSize: 12,
                                                height: 1.16667,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Spacer(),
                  Align(
                    alignment: Alignment.topCenter,
                    child: Container(
                      width: 263,
                      height: 19,
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          Positioned(
                            child: Text(
                              "Ingradients",
                              textAlign: TextAlign.left,
                              style: TextStyle(
                                color: AppColors.primaryText,
                                fontFamily: "Avenir",
                                fontWeight: FontWeight.w800,
                                fontSize: 14,
                              ),
                            ),
                          ),
                          Positioned(
                            left: 0,
                            right: 0,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: [
                                Align(
                                  alignment: Alignment.centerLeft,
                                  child: Opacity(
                                    opacity: 0.59961,
                                    child: Text(
                                      "Details",
                                      textAlign: TextAlign.left,
                                      style: TextStyle(
                                        color: AppColors.primaryText,
                                        fontFamily: "Avenir",
                                        fontWeight: FontWeight.w400,
                                        fontSize: 14,
                                      ),
                                    ),
                                  ),
                                ),
                                Spacer(),
                                Align(
                                  alignment: Alignment.centerLeft,
                                  child: Opacity(
                                    opacity: 0.59961,
                                    child: Text(
                                      "Review",
                                      textAlign: TextAlign.left,
                                      style: TextStyle(
                                        color: AppColors.primaryText,
                                        fontFamily: "Avenir",
                                        fontWeight: FontWeight.w400,
                                        fontSize: 14,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              flex: 1,
              child: Container(
                margin: EdgeInsets.only(top: 30),
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    Positioned(
                      left: 16,
                      top: 0,
                      right: 0,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Container(
                            height: 25,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Expanded(
                                  flex: 1,
                                  child: Align(
                                    alignment: Alignment.bottomLeft,
                                    child: Container(
                                      height: 1,
                                      decoration: BoxDecoration(
                                        color: Color.fromARGB(255, 237, 240, 242),
                                        borderRadius: BorderRadius.all(Radius.circular(0.5)),
                                      ),
                                      child: Container(),
                                    ),
                                  ),
                                ),
                                Container(
                                  width: 14,
                                  height: 14,
                                  child: Image.asset(
                                    "assets/images/chicken-leg.png",
                                    fit: BoxFit.none,
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.only(left: 14),
                                  child: Text(
                                    "Chicken :",
                                    textAlign: TextAlign.left,
                                    style: TextStyle(
                                      color: AppColors.primaryText,
                                      fontFamily: "Avenir",
                                      fontWeight: FontWeight.w500,
                                      fontSize: 14,
                                      height: 1,
                                    ),
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.only(left: 30),
                                  child: Opacity(
                                    opacity: 0.59961,
                                    child: Text(
                                      "02 Pcs",
                                      textAlign: TextAlign.left,
                                      style: TextStyle(
                                        color: AppColors.primaryText,
                                        fontFamily: "Avenir",
                                        fontWeight: FontWeight.w400,
                                        fontSize: 12,
                                        height: 1.16667,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            height: 25,
                            margin: EdgeInsets.only(top: 20),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Expanded(
                                  flex: 1,
                                  child: Align(
                                    alignment: Alignment.bottomLeft,
                                    child: Container(
                                      height: 1,
                                      decoration: BoxDecoration(
                                        color: Color.fromARGB(255, 237, 240, 242),
                                        borderRadius: BorderRadius.all(Radius.circular(0.5)),
                                      ),
                                      child: Container(),
                                    ),
                                  ),
                                ),
                                Container(
                                  width: 14,
                                  height: 14,
                                  child: Image.asset(
                                    "assets/images/001-cabbage.png",
                                    fit: BoxFit.none,
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.only(left: 14),
                                  child: Text(
                                    "Cabbage :",
                                    textAlign: TextAlign.left,
                                    style: TextStyle(
                                      color: AppColors.primaryText,
                                      fontFamily: "Avenir",
                                      fontWeight: FontWeight.w500,
                                      fontSize: 14,
                                      height: 1,
                                    ),
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.only(left: 23),
                                  child: Opacity(
                                    opacity: 0.59961,
                                    child: Text(
                                      "500 Gm",
                                      textAlign: TextAlign.left,
                                      style: TextStyle(
                                        color: AppColors.primaryText,
                                        fontFamily: "Avenir",
                                        fontWeight: FontWeight.w400,
                                        fontSize: 12,
                                        height: 1.16667,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            height: 25,
                            margin: EdgeInsets.only(top: 20),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Expanded(
                                  flex: 1,
                                  child: Align(
                                    alignment: Alignment.bottomLeft,
                                    child: Container(
                                      height: 1,
                                      decoration: BoxDecoration(
                                        color: Color.fromARGB(255, 237, 240, 242),
                                        borderRadius: BorderRadius.all(Radius.circular(0.5)),
                                      ),
                                      child: Container(),
                                    ),
                                  ),
                                ),
                                Container(
                                  width: 14,
                                  height: 14,
                                  child: Image.asset(
                                    "assets/images/carrot.png",
                                    fit: BoxFit.none,
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.only(left: 14),
                                  child: Text(
                                    "Carrot :",
                                    textAlign: TextAlign.left,
                                    style: TextStyle(
                                      color: AppColors.primaryText,
                                      fontFamily: "Avenir",
                                      fontWeight: FontWeight.w500,
                                      fontSize: 14,
                                      height: 1,
                                    ),
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.only(left: 40),
                                  child: Opacity(
                                    opacity: 0.59961,
                                    child: Text(
                                      "200 Gm",
                                      textAlign: TextAlign.left,
                                      style: TextStyle(
                                        color: AppColors.primaryText,
                                        fontFamily: "Avenir",
                                        fontWeight: FontWeight.w400,
                                        fontSize: 12,
                                        height: 1.16667,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            height: 25,
                            margin: EdgeInsets.only(top: 20),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Expanded(
                                  flex: 1,
                                  child: Align(
                                    alignment: Alignment.bottomLeft,
                                    child: Container(
                                      height: 1,
                                      decoration: BoxDecoration(
                                        color: Color.fromARGB(255, 237, 240, 242),
                                        borderRadius: BorderRadius.all(Radius.circular(0.5)),
                                      ),
                                      child: Container(),
                                    ),
                                  ),
                                ),
                                Container(
                                  width: 13,
                                  height: 14,
                                  child: Image.asset(
                                    "assets/images/chilli.png",
                                    fit: BoxFit.none,
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.only(left: 15),
                                  child: Text(
                                    "Chilli :",
                                    textAlign: TextAlign.left,
                                    style: TextStyle(
                                      color: AppColors.primaryText,
                                      fontFamily: "Avenir",
                                      fontWeight: FontWeight.w500,
                                      fontSize: 14,
                                      height: 1,
                                    ),
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.only(left: 50),
                                  child: Opacity(
                                    opacity: 0.59961,
                                    child: Text(
                                      "50 Gm",
                                      textAlign: TextAlign.left,
                                      style: TextStyle(
                                        color: AppColors.primaryText,
                                        fontFamily: "Avenir",
                                        fontWeight: FontWeight.w400,
                                        fontSize: 12,
                                        height: 1.16667,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Spacer(),
                          Container(
                            height: 25,
                            margin: EdgeInsets.only(bottom: 20),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Expanded(
                                  flex: 1,
                                  child: Align(
                                    alignment: Alignment.bottomLeft,
                                    child: Container(
                                      height: 1,
                                      decoration: BoxDecoration(
                                        color: Color.fromARGB(255, 237, 240, 242),
                                        borderRadius: BorderRadius.all(Radius.circular(0.5)),
                                      ),
                                      child: Container(),
                                    ),
                                  ),
                                ),
                                Container(
                                  width: 14,
                                  height: 14,
                                  child: Image.asset(
                                    "assets/images/onion.png",
                                    fit: BoxFit.none,
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.only(left: 14),
                                  child: Text(
                                    "Onion :",
                                    textAlign: TextAlign.left,
                                    style: TextStyle(
                                      color: AppColors.primaryText,
                                      fontFamily: "Avenir",
                                      fontWeight: FontWeight.w500,
                                      fontSize: 14,
                                      height: 1,
                                    ),
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.only(left: 42),
                                  child: Opacity(
                                    opacity: 0.59961,
                                    child: Text(
                                      "200 Gm",
                                      textAlign: TextAlign.left,
                                      style: TextStyle(
                                        color: AppColors.primaryText,
                                        fontFamily: "Avenir",
                                        fontWeight: FontWeight.w400,
                                        fontSize: 12,
                                        height: 1.16667,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            height: 25,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Expanded(
                                  flex: 1,
                                  child: Align(
                                    alignment: Alignment.bottomLeft,
                                    child: Container(
                                      height: 1,
                                      decoration: BoxDecoration(
                                        color: Color.fromARGB(255, 237, 240, 242),
                                        borderRadius: BorderRadius.all(Radius.circular(0.5)),
                                      ),
                                      child: Container(),
                                    ),
                                  ),
                                ),
                                Container(
                                  width: 14,
                                  height: 14,
                                  child: Image.asset(
                                    "assets/images/tomato.png",
                                    fit: BoxFit.none,
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.only(left: 14),
                                  child: Text(
                                    "Tomato :",
                                    textAlign: TextAlign.left,
                                    style: TextStyle(
                                      color: AppColors.primaryText,
                                      fontFamily: "Avenir",
                                      fontWeight: FontWeight.w500,
                                      fontSize: 14,
                                      height: 1,
                                    ),
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.only(left: 33),
                                  child: Opacity(
                                    opacity: 0.59961,
                                    child: Text(
                                      "100 Gm",
                                      textAlign: TextAlign.left,
                                      style: TextStyle(
                                        color: AppColors.primaryText,
                                        fontFamily: "Avenir",
                                        fontWeight: FontWeight.w400,
                                        fontSize: 12,
                                        height: 1.16667,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Positioned(
                      left: 0,
                      right: 0,
                      bottom: 0,
                      child: Container(
                        height: 90,
                        decoration: BoxDecoration(
                          color: Color.fromARGB(255, 255, 245, 176),
                          boxShadow: [
                            Shadows.secondaryShadow,
                          ],
                          borderRadius: BorderRadius.all(Radius.circular(12)),
                        ),
                        child: Row(
                          children: [
                            Container(
                              width: 110,
                              height: 50,
                              margin: EdgeInsets.only(left: 24),
                              decoration: BoxDecoration(
                                color: AppColors.secondaryElement,
                                boxShadow: [
                                  BoxShadow(
                                    color: Color.fromARGB(6, 0, 0, 0),
                                    offset: Offset(0, 2),
                                    blurRadius: 8,
                                  ),
                                ],
                                borderRadius: BorderRadius.all(Radius.circular(4)),
                              ),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                children: [
                                  Container(
                                    height: 16,
                                    margin: EdgeInsets.symmetric(horizontal: 18),
                                    child: Stack(
                                      alignment: Alignment.center,
                                      children: [
                                        Positioned(
                                          left: 0,
                                          right: 0,
                                          child: Row(
                                            crossAxisAlignment: CrossAxisAlignment.stretch,
                                            children: [
                                              Align(
                                                alignment: Alignment.centerLeft,
                                                child: Container(
                                                  width: 16,
                                                  height: 16,
                                                  child: FlatButton(
                                                    onPressed: () => this.onGroup4CopyPressed(context),
                                                    color: Color.fromARGB(255, 243, 243, 243),
                                                    shape: RoundedRectangleBorder(
                                                      borderRadius: BorderRadius.all(Radius.circular(8)),
                                                    ),
                                                    textColor: Color.fromARGB(255, 0, 0, 0),
                                                    padding: EdgeInsets.all(0),
                                                    child: Row(
                                                      mainAxisAlignment: MainAxisAlignment.center,
                                                      children: [
                                                        Image.asset("assets/images/group-3-7.png",),
                                                        SizedBox(
                                                          width: 10,
                                                        ),
                                                        Text(
                                                          "",
                                                          textAlign: TextAlign.left,
                                                          style: TextStyle(
                                                            color: Color.fromARGB(255, 0, 0, 0),
                                                            fontWeight: FontWeight.w400,
                                                            fontSize: 12,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Spacer(),
                                              Align(
                                                alignment: Alignment.centerLeft,
                                                child: Container(
                                                  width: 16,
                                                  height: 16,
                                                  child: FlatButton(
                                                    onPressed: () => this.onGroup4Pressed(context),
                                                    color: Color.fromARGB(255, 243, 243, 243),
                                                    shape: RoundedRectangleBorder(
                                                      borderRadius: BorderRadius.all(Radius.circular(8)),
                                                    ),
                                                    textColor: Color.fromARGB(255, 0, 0, 0),
                                                    padding: EdgeInsets.all(0),
                                                    child: Row(
                                                      mainAxisAlignment: MainAxisAlignment.center,
                                                      children: [
                                                        Image.asset("assets/images/group-3-5.png",),
                                                        SizedBox(
                                                          width: 10,
                                                        ),
                                                        Text(
                                                          "",
                                                          textAlign: TextAlign.left,
                                                          style: TextStyle(
                                                            color: Color.fromARGB(255, 0, 0, 0),
                                                            fontWeight: FontWeight.w400,
                                                            fontSize: 12,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Positioned(
                                          child: Text(
                                            "2",
                                            textAlign: TextAlign.left,
                                            style: TextStyle(
                                              color: AppColors.primaryText,
                                              fontFamily: "Avenir",
                                              fontWeight: FontWeight.w500,
                                              fontSize: 14,
                                              height: 1,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Spacer(),
                            Container(
                              width: 212,
                              height: 50,
                              margin: EdgeInsets.only(right: 16),
                              child: FlatButton(
                                onPressed: () => this.onAddToCartButtonPressed(context),
                                color: AppColors.primaryElement,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.all(Radius.circular(4)),
                                ),
                                textColor: Color.fromARGB(255, 66, 80, 96),
                                padding: EdgeInsets.all(0),
                                child: Text(
                                  "Add To Cart",
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    color: Color.fromARGB(255, 66, 80, 96),
                                    fontFamily: "Avenir",
                                    fontWeight: FontWeight.w800,
                                    fontSize: 14,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}