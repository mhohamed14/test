/*
*  user_profile_widget.dart
*  Food UI Kit
*
*  Created by [Author].
*  Copyright © 2018 [Company]. All rights reserved.
    */

import 'package:flutter/material.dart';
import 'package:food_ui_kit/edit_profile_widget/edit_profile_widget.dart';
import 'package:food_ui_kit/payment_method_widget/payment_method_widget.dart';
import 'package:food_ui_kit/setting_widget/setting_widget.dart';
import 'package:food_ui_kit/splash_widget/splash_widget.dart';
import 'package:food_ui_kit/values/values.dart';


class UserProfileWidget extends StatelessWidget {
  
  void onOrderPressed(BuildContext context) {
  
  }
  
  void onChevronRight1Pressed(BuildContext context) => Navigator.push(context, MaterialPageRoute(builder: (context) => EditProfileWidget()));
  
  void onChevronRight1TwoPressed(BuildContext context) {
  
  }
  
  void onChevronRight1ThreePressed(BuildContext context) => Navigator.push(context, MaterialPageRoute(builder: (context) => SettingWidget()));
  
  void onChevronRight1FourPressed(BuildContext context) => Navigator.push(context, MaterialPageRoute(builder: (context) => PaymentMethodWidget()));
  
  void onChevronRight1FivePressed(BuildContext context) => Navigator.push(context, MaterialPageRoute(builder: (context) => SplashWidget()));
  
  @override
  Widget build(BuildContext context) {
  
    return Scaffold(
      body: Container(
        constraints: BoxConstraints.expand(),
        decoration: BoxDecoration(
          color: Color.fromARGB(255, 250, 250, 250),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              height: 313,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  Positioned(
                    left: 0,
                    top: 0,
                    right: 0,
                    child: Container(
                      height: 262,
                      decoration: BoxDecoration(
                        color: Color.fromARGB(255, 255, 210, 78),
                        borderRadius: BorderRadius.all(Radius.circular(12)),
                      ),
                      child: Container(),
                    ),
                  ),
                  Positioned(
                    left: 20,
                    top: 89,
                    right: 20,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Align(
                          alignment: Alignment.topLeft,
                          child: Container(
                            width: 188,
                            height: 42,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: [
                                Align(
                                  alignment: Alignment.centerLeft,
                                  child: Container(
                                    width: 46,
                                    height: 46,
                                    child: Image.asset(
                                      "assets/images/bitmap-8.png",
                                      fit: BoxFit.none,
                                    ),
                                  ),
                                ),
                                Spacer(),
                                Container(
                                  width: 94,
                                  margin: EdgeInsets.only(top: 1, right: 37),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.stretch,
                                    children: [
                                      Align(
                                        alignment: Alignment.topRight,
                                        child: Container(
                                          margin: EdgeInsets.only(right: 1),
                                          child: Text(
                                            "Shakibul Islam",
                                            textAlign: TextAlign.left,
                                            style: TextStyle(
                                              color: AppColors.primaryText,
                                              fontFamily: "Avenir",
                                              fontWeight: FontWeight.w800,
                                              fontSize: 14,
                                              height: 1,
                                            ),
                                          ),
                                        ),
                                      ),
                                      Spacer(),
                                      Align(
                                        alignment: Alignment.topRight,
                                        child: Opacity(
                                          opacity: 0.59519,
                                          child: Text(
                                            "User ID: 10023",
                                            textAlign: TextAlign.left,
                                            style: TextStyle(
                                              color: AppColors.primaryText,
                                              fontFamily: "Avenir",
                                              fontWeight: FontWeight.w400,
                                              fontSize: 14,
                                              height: 1,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Container(
                          height: 142,
                          margin: EdgeInsets.only(top: 40),
                          decoration: BoxDecoration(
                            color: AppColors.primaryBackground,
                            boxShadow: [
                              Shadows.primaryShadow,
                            ],
                            borderRadius: BorderRadius.all(Radius.circular(14)),
                          ),
                          child: Stack(
                            alignment: Alignment.center,
                            children: [
                              Positioned(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.stretch,
                                  children: [
                                    Container(
                                      height: 36,
                                      margin: EdgeInsets.symmetric(horizontal: 9),
                                      decoration: BoxDecoration(
                                        color: Color.fromARGB(255, 255, 237, 197),
                                        borderRadius: BorderRadius.all(Radius.circular(18)),
                                      ),
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        crossAxisAlignment: CrossAxisAlignment.stretch,
                                        children: [
                                          Container(
                                            height: 16,
                                            margin: EdgeInsets.only(left: 10, right: 9),
                                            child: Image.asset(
                                              "assets/images/004-gift.png",
                                              fit: BoxFit.none,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Spacer(),
                                    Text(
                                      "Offer & \nPromos",
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        color: AppColors.primaryText,
                                        fontFamily: "Avenir",
                                        fontWeight: FontWeight.w800,
                                        fontSize: 14,
                                        height: 1.28571,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Positioned(
                                left: 30,
                                right: 31,
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.stretch,
                                  children: [
                                    Align(
                                      alignment: Alignment.centerLeft,
                                      child: Container(
                                        width: 54,
                                        height: 82,
                                        child: FlatButton(
                                          onPressed: () => this.onOrderPressed(context),
                                          color: Color.fromARGB(0, 0, 0, 0),
                                          shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.all(Radius.circular(0)),
                                          ),
                                          textColor: Color.fromARGB(255, 66, 80, 96),
                                          padding: EdgeInsets.all(0),
                                          child: Row(
                                            mainAxisAlignment: MainAxisAlignment.center,
                                            children: [
                                              Image.asset("assets/images/delivery-truck.png",),
                                              SizedBox(
                                                width: 10,
                                              ),
                                              Text(
                                                "My All Order",
                                                textAlign: TextAlign.center,
                                                style: TextStyle(
                                                  color: Color.fromARGB(255, 66, 80, 96),
                                                  fontFamily: "Avenir",
                                                  fontWeight: FontWeight.w800,
                                                  fontSize: 14,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ),
                                    Spacer(),
                                    Align(
                                      alignment: Alignment.centerLeft,
                                      child: Container(
                                        width: 54,
                                        height: 82,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.stretch,
                                          children: [
                                            Container(
                                              height: 36,
                                              margin: EdgeInsets.symmetric(horizontal: 9),
                                              decoration: BoxDecoration(
                                                color: Color.fromARGB(255, 255, 230, 222),
                                                borderRadius: BorderRadius.all(Radius.circular(18)),
                                              ),
                                              child: Column(
                                                mainAxisAlignment: MainAxisAlignment.center,
                                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                                children: [
                                                  Container(
                                                    height: 17,
                                                    margin: EdgeInsets.only(left: 12, right: 11),
                                                    child: Image.asset(
                                                      "assets/images/group-5-2.png",
                                                      fit: BoxFit.none,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Spacer(),
                                            Text(
                                              "Delivery\nAddress",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                color: AppColors.primaryText,
                                                fontFamily: "Avenir",
                                                fontWeight: FontWeight.w800,
                                                fontSize: 14,
                                                height: 1.28571,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              height: 364,
              margin: EdgeInsets.only(left: 20, top: 20, right: 20),
              decoration: BoxDecoration(
                color: AppColors.primaryBackground,
                boxShadow: [
                  Shadows.primaryShadow,
                ],
                borderRadius: BorderRadius.all(Radius.circular(12)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    height: 51,
                    margin: EdgeInsets.only(top: 20),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          flex: 1,
                          child: Align(
                            alignment: Alignment.bottomLeft,
                            child: Container(
                              height: 1,
                              decoration: BoxDecoration(
                                color: Color.fromARGB(255, 243, 243, 243),
                                borderRadius: BorderRadius.all(Radius.circular(0.5)),
                              ),
                              child: Container(),
                            ),
                          ),
                        ),
                        Container(
                          width: 30,
                          height: 30,
                          child: Stack(
                            alignment: Alignment.center,
                            children: [
                              Positioned(
                                left: 0,
                                top: 0,
                                child: Container(
                                  width: 30,
                                  height: 30,
                                  decoration: BoxDecoration(
                                    color: Color.fromARGB(255, 240, 243, 255),
                                    borderRadius: BorderRadius.all(Radius.circular(6)),
                                  ),
                                  child: Container(),
                                ),
                              ),
                              Positioned(
                                left: 8,
                                top: 7,
                                child: Image.asset(
                                  "assets/images/group-2-3.png",
                                  fit: BoxFit.none,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.only(left: 30, top: 5),
                          child: Text(
                            "My Profile",
                            textAlign: TextAlign.left,
                            style: TextStyle(
                              color: AppColors.primaryText,
                              fontFamily: "Avenir",
                              fontWeight: FontWeight.w500,
                              fontSize: 14,
                              height: 1,
                            ),
                          ),
                        ),
                        Container(
                          width: 6,
                          height: 10,
                          margin: EdgeInsets.only(top: 10, right: 20),
                          child: FlatButton(
                            onPressed: () => this.onChevronRight1Pressed(context),
                            color: Color.fromARGB(0, 0, 0, 0),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.all(Radius.circular(0)),
                            ),
                            textColor: Color.fromARGB(255, 0, 0, 0),
                            padding: EdgeInsets.all(0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Image.asset("assets/images/chevron-right-1-.png",),
                                SizedBox(
                                  width: 10,
                                ),
                                Text(
                                  "",
                                  textAlign: TextAlign.left,
                                  style: TextStyle(
                                    color: Color.fromARGB(255, 0, 0, 0),
                                    fontWeight: FontWeight.w400,
                                    fontSize: 12,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    height: 51,
                    margin: EdgeInsets.only(top: 20),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          flex: 1,
                          child: Align(
                            alignment: Alignment.bottomLeft,
                            child: Container(
                              height: 1,
                              decoration: BoxDecoration(
                                color: Color.fromARGB(255, 243, 243, 243),
                                borderRadius: BorderRadius.all(Radius.circular(0.5)),
                              ),
                              child: Container(),
                            ),
                          ),
                        ),
                        Container(
                          width: 30,
                          height: 30,
                          child: Stack(
                            alignment: Alignment.center,
                            children: [
                              Positioned(
                                left: 0,
                                top: 0,
                                child: Container(
                                  width: 30,
                                  height: 30,
                                  decoration: BoxDecoration(
                                    color: Color.fromARGB(255, 226, 255, 225),
                                    borderRadius: BorderRadius.all(Radius.circular(6)),
                                  ),
                                  child: Container(),
                                ),
                              ),
                              Positioned(
                                left: 9,
                                top: 8,
                                child: Image.asset(
                                  "assets/images/001-notifications-bell-button.png",
                                  fit: BoxFit.none,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.only(left: 30, top: 5),
                          child: Text(
                            "Notificaion",
                            textAlign: TextAlign.left,
                            style: TextStyle(
                              color: AppColors.primaryText,
                              fontFamily: "Avenir",
                              fontWeight: FontWeight.w500,
                              fontSize: 14,
                              height: 1,
                            ),
                          ),
                        ),
                        Container(
                          width: 6,
                          height: 10,
                          margin: EdgeInsets.only(top: 10, right: 20),
                          child: FlatButton(
                            onPressed: () => this.onChevronRight1TwoPressed(context),
                            color: Color.fromARGB(0, 0, 0, 0),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.all(Radius.circular(0)),
                            ),
                            textColor: Color.fromARGB(255, 0, 0, 0),
                            padding: EdgeInsets.all(0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Image.asset("assets/images/chevron-right-1-.png",),
                                SizedBox(
                                  width: 10,
                                ),
                                Text(
                                  "",
                                  textAlign: TextAlign.left,
                                  style: TextStyle(
                                    color: Color.fromARGB(255, 0, 0, 0),
                                    fontWeight: FontWeight.w400,
                                    fontSize: 12,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    height: 51,
                    margin: EdgeInsets.only(top: 20),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          flex: 1,
                          child: Align(
                            alignment: Alignment.bottomLeft,
                            child: Container(
                              height: 1,
                              decoration: BoxDecoration(
                                color: Color.fromARGB(255, 243, 243, 243),
                                borderRadius: BorderRadius.all(Radius.circular(0.5)),
                              ),
                              child: Container(),
                            ),
                          ),
                        ),
                        Container(
                          width: 30,
                          height: 30,
                          child: Stack(
                            alignment: Alignment.center,
                            children: [
                              Positioned(
                                left: 0,
                                top: 0,
                                child: Container(
                                  width: 30,
                                  height: 30,
                                  decoration: BoxDecoration(
                                    color: Color.fromARGB(255, 255, 244, 208),
                                    borderRadius: BorderRadius.all(Radius.circular(6)),
                                  ),
                                  child: Container(),
                                ),
                              ),
                              Positioned(
                                left: 7,
                                top: 7,
                                child: Image.asset(
                                  "assets/images/gear.png",
                                  fit: BoxFit.none,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.only(left: 30, top: 5),
                          child: Text(
                            "Settings",
                            textAlign: TextAlign.left,
                            style: TextStyle(
                              color: AppColors.primaryText,
                              fontFamily: "Avenir",
                              fontWeight: FontWeight.w500,
                              fontSize: 14,
                              height: 1,
                            ),
                          ),
                        ),
                        Container(
                          width: 6,
                          height: 10,
                          margin: EdgeInsets.only(top: 10, right: 20),
                          child: FlatButton(
                            onPressed: () => this.onChevronRight1ThreePressed(context),
                            color: Color.fromARGB(0, 0, 0, 0),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.all(Radius.circular(0)),
                            ),
                            textColor: Color.fromARGB(255, 0, 0, 0),
                            padding: EdgeInsets.all(0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Image.asset("assets/images/chevron-right-1-.png",),
                                SizedBox(
                                  width: 10,
                                ),
                                Text(
                                  "",
                                  textAlign: TextAlign.left,
                                  style: TextStyle(
                                    color: Color.fromARGB(255, 0, 0, 0),
                                    fontWeight: FontWeight.w400,
                                    fontSize: 12,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    height: 51,
                    margin: EdgeInsets.only(top: 20),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          flex: 1,
                          child: Align(
                            alignment: Alignment.bottomLeft,
                            child: Container(
                              height: 1,
                              decoration: BoxDecoration(
                                color: Color.fromARGB(255, 243, 243, 243),
                                borderRadius: BorderRadius.all(Radius.circular(0.5)),
                              ),
                              child: Container(),
                            ),
                          ),
                        ),
                        Container(
                          width: 30,
                          height: 30,
                          child: Stack(
                            alignment: Alignment.center,
                            children: [
                              Positioned(
                                left: 0,
                                top: 0,
                                child: Container(
                                  width: 30,
                                  height: 30,
                                  decoration: BoxDecoration(
                                    color: Color.fromARGB(255, 237, 240, 255),
                                    borderRadius: BorderRadius.all(Radius.circular(6)),
                                  ),
                                  child: Container(),
                                ),
                              ),
                              Positioned(
                                left: 7,
                                top: 8,
                                child: Image.asset(
                                  "assets/images/currency.png",
                                  fit: BoxFit.none,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.only(left: 30, top: 5),
                          child: Text(
                            "Payment",
                            textAlign: TextAlign.left,
                            style: TextStyle(
                              color: AppColors.primaryText,
                              fontFamily: "Avenir",
                              fontWeight: FontWeight.w500,
                              fontSize: 14,
                              height: 1,
                            ),
                          ),
                        ),
                        Container(
                          width: 6,
                          height: 10,
                          margin: EdgeInsets.only(top: 10, right: 20),
                          child: FlatButton(
                            onPressed: () => this.onChevronRight1FourPressed(context),
                            color: Color.fromARGB(0, 0, 0, 0),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.all(Radius.circular(0)),
                            ),
                            textColor: Color.fromARGB(255, 0, 0, 0),
                            padding: EdgeInsets.all(0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Image.asset("assets/images/chevron-right-1-.png",),
                                SizedBox(
                                  width: 10,
                                ),
                                Text(
                                  "",
                                  textAlign: TextAlign.left,
                                  style: TextStyle(
                                    color: Color.fromARGB(255, 0, 0, 0),
                                    fontWeight: FontWeight.w400,
                                    fontSize: 12,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Spacer(),
                  Container(
                    height: 30,
                    margin: EdgeInsets.only(left: 20, right: 20, bottom: 30),
                    child: Row(
                      children: [
                        Container(
                          width: 30,
                          height: 30,
                          child: Stack(
                            alignment: Alignment.center,
                            children: [
                              Positioned(
                                left: 0,
                                child: Container(
                                  width: 30,
                                  height: 30,
                                  decoration: BoxDecoration(
                                    color: Color.fromARGB(255, 255, 230, 230),
                                    borderRadius: BorderRadius.all(Radius.circular(6)),
                                  ),
                                  child: Container(),
                                ),
                              ),
                              Positioned(
                                left: 7,
                                child: Image.asset(
                                  "assets/images/exit-2.png",
                                  fit: BoxFit.none,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.only(left: 30),
                          child: Text(
                            "Log Out",
                            textAlign: TextAlign.left,
                            style: TextStyle(
                              color: AppColors.primaryText,
                              fontFamily: "Avenir",
                              fontWeight: FontWeight.w500,
                              fontSize: 14,
                              height: 1,
                            ),
                          ),
                        ),
                        Spacer(),
                        Container(
                          width: 6,
                          height: 10,
                          child: FlatButton(
                            onPressed: () => this.onChevronRight1FivePressed(context),
                            color: Color.fromARGB(0, 0, 0, 0),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.all(Radius.circular(0)),
                            ),
                            textColor: Color.fromARGB(255, 0, 0, 0),
                            padding: EdgeInsets.all(0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Image.asset("assets/images/chevron-right-1-.png",),
                                SizedBox(
                                  width: 10,
                                ),
                                Text(
                                  "",
                                  textAlign: TextAlign.left,
                                  style: TextStyle(
                                    color: Color.fromARGB(255, 0, 0, 0),
                                    fontWeight: FontWeight.w400,
                                    fontSize: 12,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Spacer(),
            Container(
              height: 82,
              decoration: BoxDecoration(
                color: AppColors.primaryBackground,
                boxShadow: [
                  BoxShadow(
                    color: Color.fromARGB(27, 137, 168, 203),
                    offset: Offset(0, -1),
                    blurRadius: 3,
                  ),
                ],
                borderRadius: BorderRadius.all(Radius.circular(16)),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    height: 41,
                    margin: EdgeInsets.only(left: 16, right: 14),
                    child: Row(
                      children: [
                        Container(
                          width: 33,
                          height: 38,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Container(
                                height: 18,
                                margin: EdgeInsets.only(left: 10, right: 9),
                                child: Image.asset(
                                  "assets/images/group-5-3.png",
                                  fit: BoxFit.none,
                                ),
                              ),
                              Spacer(),
                              Text(
                                "Home",
                                textAlign: TextAlign.left,
                                style: TextStyle(
                                  color: AppColors.accentText,
                                  fontFamily: "Avenir",
                                  fontWeight: FontWeight.w400,
                                  fontSize: 12,
                                  height: 1,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          width: 44,
                          height: 39,
                          margin: EdgeInsets.only(left: 32),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Container(
                                height: 19,
                                margin: EdgeInsets.only(left: 13, right: 12),
                                child: Image.asset(
                                  "assets/images/005-nearby-copy-2.png",
                                  fit: BoxFit.none,
                                ),
                              ),
                              Spacer(),
                              Text(
                                "Near By",
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  color: AppColors.accentText,
                                  fontFamily: "Avenir",
                                  fontWeight: FontWeight.w400,
                                  fontSize: 12,
                                  height: 1,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          width: 52,
                          height: 40,
                          margin: EdgeInsets.only(left: 32),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Container(
                                height: 18,
                                margin: EdgeInsets.only(left: 18, right: 16),
                                child: Image.asset(
                                  "assets/images/group-3-3.png",
                                  fit: BoxFit.none,
                                ),
                              ),
                              Spacer(),
                              Text(
                                "Category",
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  color: AppColors.accentText,
                                  fontFamily: "Avenir",
                                  fontWeight: FontWeight.w400,
                                  fontSize: 12,
                                  height: 1,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Spacer(),
                        Container(
                          width: 52,
                          height: 40,
                          margin: EdgeInsets.only(right: 31),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Container(
                                height: 18,
                                margin: EdgeInsets.symmetric(horizontal: 16),
                                child: Image.asset(
                                  "assets/images/path-16.png",
                                  fit: BoxFit.none,
                                ),
                              ),
                              Spacer(),
                              Text(
                                "Favourite",
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  color: AppColors.accentText,
                                  fontFamily: "Avenir",
                                  fontWeight: FontWeight.w400,
                                  fontSize: 12,
                                  height: 1,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          width: 37,
                          height: 41,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Container(
                                height: 18,
                                margin: EdgeInsets.only(left: 9, right: 8),
                                child: Image.asset(
                                  "assets/images/group-2-4.png",
                                  fit: BoxFit.none,
                                ),
                              ),
                              Spacer(),
                              Container(
                                margin: EdgeInsets.symmetric(horizontal: 1),
                                child: Text(
                                  "Profile",
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    color: AppColors.primaryText,
                                    fontFamily: "Avenir",
                                    fontWeight: FontWeight.w500,
                                    fontSize: 12,
                                    height: 1,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}