/*
*  payment_method_widget.dart
*  Food UI Kit
*
*  Created by [Author].
*  Copyright © 2018 [Company]. All rights reserved.
    */

import 'package:flutter/material.dart';
import 'package:food_ui_kit/add_card2_widget/add_card2_widget.dart';
import 'package:food_ui_kit/search_filter_widget/search_filter_widget.dart';
import 'package:food_ui_kit/values/values.dart';


class PaymentMethodWidget extends StatelessWidget {
  
  void onBackPressed(BuildContext context) => Navigator.push(context, MaterialPageRoute(builder: (context) => AddCard2Widget()));
  
  void onGroup3Pressed(BuildContext context) => Navigator.push(context, MaterialPageRoute(builder: (context) => SearchFilterWidget()));
  
  void onRectanglePressed(BuildContext context) => Navigator.push(context, MaterialPageRoute(builder: (context) => SearchFilterWidget()));
  
  void onRectangleTwoPressed(BuildContext context) => Navigator.push(context, MaterialPageRoute(builder: (context) => SearchFilterWidget()));
  
  @override
  Widget build(BuildContext context) {
  
    return Scaffold(
      body: Container(
        constraints: BoxConstraints.expand(),
        decoration: BoxDecoration(
          color: Color.fromARGB(255, 250, 250, 250),
        ),
        child: Stack(
          alignment: Alignment.topCenter,
          children: [
            Positioned(
              left: 0,
              top: 0,
              right: 0,
              child: Container(
                height: 266,
                decoration: BoxDecoration(
                  color: AppColors.primaryBackground,
                  borderRadius: BorderRadius.all(Radius.circular(36)),
                ),
                child: Container(),
              ),
            ),
            Positioned(
              left: 0,
              top: 0,
              right: -205,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    height: 81,
                    margin: EdgeInsets.only(right: 205),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.end,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          width: 172,
                          height: 22,
                          margin: EdgeInsets.only(left: 16),
                          child: Row(
                            children: [
                              Container(
                                width: 13,
                                height: 19,
                                child: FlatButton(
                                  onPressed: () => this.onBackPressed(context),
                                  color: Color.fromARGB(0, 0, 0, 0),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.all(Radius.circular(0)),
                                  ),
                                  textColor: Color.fromARGB(255, 0, 0, 0),
                                  padding: EdgeInsets.all(0),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Image.asset("assets/images/back-3.png",),
                                      SizedBox(
                                        width: 10,
                                      ),
                                      Text(
                                        "",
                                        textAlign: TextAlign.left,
                                        style: TextStyle(
                                          color: Color.fromARGB(255, 0, 0, 0),
                                          fontWeight: FontWeight.w400,
                                          fontSize: 12,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Spacer(),
                              Text(
                                "Payment Method",
                                textAlign: TextAlign.left,
                                style: TextStyle(
                                  color: AppColors.primaryText,
                                  fontFamily: "Avenir",
                                  fontWeight: FontWeight.w800,
                                  fontSize: 16,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    height: 546,
                    margin: EdgeInsets.only(left: 20, top: 44),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Container(
                          height: 24,
                          margin: EdgeInsets.only(right: 221),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Align(
                                alignment: Alignment.topLeft,
                                child: Container(
                                  margin: EdgeInsets.only(top: 2),
                                  child: Text(
                                    "My Card",
                                    textAlign: TextAlign.left,
                                    style: TextStyle(
                                      color: AppColors.primaryText,
                                      fontFamily: "Avenir",
                                      fontWeight: FontWeight.w800,
                                      fontSize: 14,
                                      height: 1,
                                    ),
                                  ),
                                ),
                              ),
                              Spacer(),
                              Align(
                                alignment: Alignment.topLeft,
                                child: Container(
                                  width: 24,
                                  height: 24,
                                  child: Image.asset(
                                    "assets/images/add-button.png",
                                    fit: BoxFit.none,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          height: 167,
                          margin: EdgeInsets.only(top: 20),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Align(
                                alignment: Alignment.topLeft,
                                child: Container(
                                  width: 270,
                                  height: 167,
                                  child: Stack(
                                    alignment: Alignment.topCenter,
                                    children: [
                                      Positioned(
                                        left: 12,
                                        top: 24,
                                        right: 12,
                                        child: Opacity(
                                          opacity: 0.09866,
                                          child: Container(
                                            height: 143,
                                            decoration: BoxDecoration(
                                              color: Color.fromARGB(255, 0, 0, 0),
                                              borderRadius: Radii.k7pxRadius,
                                            ),
                                            child: Container(),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        left: 0,
                                        top: 0,
                                        right: 0,
                                        child: Image.asset(
                                          "assets/images/group-33.png",
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                      Positioned(
                                        left: 15,
                                        top: 85,
                                        right: 16,
                                        bottom: 20,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.stretch,
                                          children: [
                                            Align(
                                              alignment: Alignment.topLeft,
                                              child: Container(
                                                decoration: BoxDecoration(
                                                  boxShadow: [
                                                    BoxShadow(
                                                      color: Color.fromARGB(64, 0, 0, 0),
                                                      offset: Offset(0, 2),
                                                      blurRadius: 4,
                                                    ),
                                                  ],
                                                ),
                                                child: Text(
                                                  "1234  5678  1234  5678",
                                                  textAlign: TextAlign.left,
                                                  style: TextStyle(
                                                    color: AppColors.primaryText,
                                                    fontFamily: "Avenir",
                                                    fontWeight: FontWeight.w800,
                                                    fontSize: 11.5,
                                                    letterSpacing: 2.15625,
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Spacer(),
                                            Container(
                                              height: 7,
                                              margin: EdgeInsets.only(right: 4, bottom: 3),
                                              child: Row(
                                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                                children: [
                                                  Align(
                                                    alignment: Alignment.bottomLeft,
                                                    child: Text(
                                                      "CARD HOLDER",
                                                      textAlign: TextAlign.left,
                                                      style: TextStyle(
                                                        color: AppColors.primaryText,
                                                        fontFamily: "Avenir",
                                                        fontWeight: FontWeight.w800,
                                                        fontSize: 5,
                                                      ),
                                                    ),
                                                  ),
                                                  Spacer(),
                                                  Align(
                                                    alignment: Alignment.bottomLeft,
                                                    child: Text(
                                                      "EXP DATE",
                                                      textAlign: TextAlign.left,
                                                      style: TextStyle(
                                                        color: AppColors.primaryText,
                                                        fontFamily: "Avenir",
                                                        fontWeight: FontWeight.w800,
                                                        fontSize: 5,
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Container(
                                              height: 14,
                                              child: Row(
                                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                                children: [
                                                  Align(
                                                    alignment: Alignment.bottomLeft,
                                                    child: Text(
                                                      "DANNIS ALBERT",
                                                      textAlign: TextAlign.left,
                                                      style: TextStyle(
                                                        color: AppColors.primaryText,
                                                        fontFamily: "Avenir",
                                                        fontWeight: FontWeight.w800,
                                                        fontSize: 10,
                                                        height: 1,
                                                      ),
                                                    ),
                                                  ),
                                                  Spacer(),
                                                  Align(
                                                    alignment: Alignment.bottomLeft,
                                                    child: Text(
                                                      "10/24",
                                                      textAlign: TextAlign.left,
                                                      style: TextStyle(
                                                        color: AppColors.primaryText,
                                                        fontFamily: "Avenir",
                                                        fontWeight: FontWeight.w800,
                                                        fontSize: 10,
                                                        height: 1,
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Spacer(),
                              Align(
                                alignment: Alignment.topLeft,
                                child: Container(
                                  width: 270,
                                  height: 160,
                                  child: Stack(
                                    alignment: Alignment.center,
                                    children: [
                                      Positioned(
                                        left: 0,
                                        right: 0,
                                        child: Image.asset(
                                          "assets/images/group-49.png",
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                      Positioned(
                                        left: 15,
                                        top: 85,
                                        right: 16,
                                        bottom: 13,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.stretch,
                                          children: [
                                            Align(
                                              alignment: Alignment.topLeft,
                                              child: Container(
                                                decoration: BoxDecoration(
                                                  boxShadow: [
                                                    BoxShadow(
                                                      color: Color.fromARGB(64, 0, 0, 0),
                                                      offset: Offset(0, 2),
                                                      blurRadius: 4,
                                                    ),
                                                  ],
                                                ),
                                                child: Text(
                                                  "1234  5678  1234  5678",
                                                  textAlign: TextAlign.left,
                                                  style: TextStyle(
                                                    color: AppColors.primaryText,
                                                    fontFamily: "Avenir",
                                                    fontWeight: FontWeight.w800,
                                                    fontSize: 11.5,
                                                    letterSpacing: 2.15625,
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Spacer(),
                                            Container(
                                              height: 7,
                                              margin: EdgeInsets.only(right: 4, bottom: 3),
                                              child: Row(
                                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                                children: [
                                                  Align(
                                                    alignment: Alignment.bottomLeft,
                                                    child: Text(
                                                      "CARD HOLDER",
                                                      textAlign: TextAlign.left,
                                                      style: TextStyle(
                                                        color: AppColors.primaryText,
                                                        fontFamily: "Avenir",
                                                        fontWeight: FontWeight.w800,
                                                        fontSize: 5,
                                                      ),
                                                    ),
                                                  ),
                                                  Spacer(),
                                                  Align(
                                                    alignment: Alignment.bottomLeft,
                                                    child: Text(
                                                      "EXP DATE",
                                                      textAlign: TextAlign.left,
                                                      style: TextStyle(
                                                        color: AppColors.primaryText,
                                                        fontFamily: "Avenir",
                                                        fontWeight: FontWeight.w800,
                                                        fontSize: 5,
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Container(
                                              height: 14,
                                              child: Row(
                                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                                children: [
                                                  Align(
                                                    alignment: Alignment.bottomLeft,
                                                    child: Text(
                                                      "DANNIS ALBERT",
                                                      textAlign: TextAlign.left,
                                                      style: TextStyle(
                                                        color: AppColors.primaryText,
                                                        fontFamily: "Avenir",
                                                        fontWeight: FontWeight.w800,
                                                        fontSize: 10,
                                                        height: 1,
                                                      ),
                                                    ),
                                                  ),
                                                  Spacer(),
                                                  Align(
                                                    alignment: Alignment.bottomLeft,
                                                    child: Text(
                                                      "10/24",
                                                      textAlign: TextAlign.left,
                                                      style: TextStyle(
                                                        color: AppColors.primaryText,
                                                        fontFamily: "Avenir",
                                                        fontWeight: FontWeight.w800,
                                                        fontSize: 10,
                                                        height: 1,
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Align(
                          alignment: Alignment.topLeft,
                          child: Container(
                            width: 335,
                            height: 302,
                            margin: EdgeInsets.only(top: 33),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: [
                                Align(
                                  alignment: Alignment.topLeft,
                                  child: Text(
                                    "Other Payment Option",
                                    textAlign: TextAlign.left,
                                    style: TextStyle(
                                      color: AppColors.primaryText,
                                      fontFamily: "Avenir",
                                      fontWeight: FontWeight.w800,
                                      fontSize: 14,
                                      height: 1,
                                    ),
                                  ),
                                ),
                                Container(
                                  height: 76,
                                  margin: EdgeInsets.only(top: 17),
                                  decoration: BoxDecoration(
                                    color: Color.fromARGB(255, 227, 240, 247),
                                    borderRadius: BorderRadius.all(Radius.circular(12)),
                                  ),
                                  child: Stack(
                                    alignment: Alignment.topCenter,
                                    children: [
                                      Positioned(
                                        top: 41,
                                        child: Text(
                                          "shakibul@gmail.com",
                                          textAlign: TextAlign.left,
                                          style: TextStyle(
                                            color: AppColors.primaryText,
                                            fontFamily: "Avenir",
                                            fontWeight: FontWeight.w400,
                                            fontSize: 14,
                                            height: 1.28571,
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        left: 15,
                                        top: 8,
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.stretch,
                                          children: [
                                            Align(
                                              alignment: Alignment.centerLeft,
                                              child: Container(
                                                width: 60,
                                                height: 60,
                                                child: FlatButton(
                                                  onPressed: () => this.onGroup3Pressed(context),
                                                  color: AppColors.secondaryElement,
                                                  shape: RoundedRectangleBorder(
                                                    borderRadius: BorderRadius.all(Radius.circular(12)),
                                                  ),
                                                  textColor: Color.fromARGB(255, 0, 0, 0),
                                                  padding: EdgeInsets.all(0),
                                                  child: Row(
                                                    mainAxisAlignment: MainAxisAlignment.center,
                                                    children: [
                                                      Image.asset("assets/images/002-paypal-1.png",),
                                                      SizedBox(
                                                        width: 10,
                                                      ),
                                                      Text(
                                                        "",
                                                        textAlign: TextAlign.left,
                                                        style: TextStyle(
                                                          color: Color.fromARGB(255, 0, 0, 0),
                                                          fontWeight: FontWeight.w400,
                                                          fontSize: 12,
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Align(
                                              alignment: Alignment.topLeft,
                                              child: Container(
                                                margin: EdgeInsets.only(left: 30, top: 8),
                                                child: Text(
                                                  "Paypal",
                                                  textAlign: TextAlign.left,
                                                  style: TextStyle(
                                                    color: AppColors.primaryText,
                                                    fontFamily: "Avenir",
                                                    fontWeight: FontWeight.w800,
                                                    fontSize: 14,
                                                    height: 1.28571,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  height: 76,
                                  margin: EdgeInsets.only(top: 20),
                                  decoration: BoxDecoration(
                                    color: Color.fromARGB(255, 222, 253, 233),
                                    borderRadius: BorderRadius.all(Radius.circular(12)),
                                  ),
                                  child: Row(
                                    children: [
                                      Container(
                                        width: 60,
                                        height: 60,
                                        margin: EdgeInsets.only(left: 15),
                                        child: Stack(
                                          alignment: Alignment.center,
                                          children: [
                                            Positioned(
                                              left: 0,
                                              child: FlatButton(
                                                onPressed: () => this.onRectanglePressed(context),
                                                color: AppColors.secondaryElement,
                                                shape: RoundedRectangleBorder(
                                                  borderRadius: BorderRadius.all(Radius.circular(12)),
                                                ),
                                                textColor: Color.fromARGB(255, 0, 0, 0),
                                                padding: EdgeInsets.all(0),
                                                child: Text(
                                                  "",
                                                  textAlign: TextAlign.left,
                                                  style: TextStyle(
                                                    color: Color.fromARGB(255, 0, 0, 0),
                                                    fontWeight: FontWeight.w400,
                                                    fontSize: 12,
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Positioned(
                                              left: 10,
                                              child: Image.asset(
                                                "assets/images/005-money.png",
                                                fit: BoxFit.none,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Align(
                                        alignment: Alignment.topLeft,
                                        child: Container(
                                          width: 114,
                                          height: 45,
                                          margin: EdgeInsets.only(left: 30, top: 16),
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.stretch,
                                            children: [
                                              Align(
                                                alignment: Alignment.topLeft,
                                                child: Text(
                                                  "Cash On Delivery",
                                                  textAlign: TextAlign.left,
                                                  style: TextStyle(
                                                    color: AppColors.primaryText,
                                                    fontFamily: "Avenir",
                                                    fontWeight: FontWeight.w800,
                                                    fontSize: 14,
                                                    height: 1.28571,
                                                  ),
                                                ),
                                              ),
                                              Align(
                                                alignment: Alignment.topLeft,
                                                child: Container(
                                                  margin: EdgeInsets.only(top: 5),
                                                  child: Text(
                                                    "Pay in cash",
                                                    textAlign: TextAlign.left,
                                                    style: TextStyle(
                                                      color: AppColors.primaryText,
                                                      fontFamily: "Avenir",
                                                      fontWeight: FontWeight.w400,
                                                      fontSize: 14,
                                                      height: 1.28571,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Spacer(),
                                Container(
                                  height: 76,
                                  decoration: BoxDecoration(
                                    color: Color.fromARGB(255, 229, 240, 255),
                                    borderRadius: BorderRadius.all(Radius.circular(12)),
                                  ),
                                  child: Stack(
                                    alignment: Alignment.topCenter,
                                    children: [
                                      Positioned(
                                        top: 44,
                                        child: Text(
                                          "shakibul@gmail.com",
                                          textAlign: TextAlign.left,
                                          style: TextStyle(
                                            color: AppColors.primaryText,
                                            fontFamily: "Avenir",
                                            fontWeight: FontWeight.w400,
                                            fontSize: 14,
                                            height: 1.28571,
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        left: 15,
                                        top: 8,
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.stretch,
                                          children: [
                                            Align(
                                              alignment: Alignment.centerLeft,
                                              child: Container(
                                                width: 60,
                                                height: 60,
                                                child: Stack(
                                                  alignment: Alignment.center,
                                                  children: [
                                                    Positioned(
                                                      left: 0,
                                                      child: FlatButton(
                                                        onPressed: () => this.onRectangleTwoPressed(context),
                                                        color: AppColors.secondaryElement,
                                                        shape: RoundedRectangleBorder(
                                                          borderRadius: BorderRadius.all(Radius.circular(12)),
                                                        ),
                                                        textColor: Color.fromARGB(255, 0, 0, 0),
                                                        padding: EdgeInsets.all(0),
                                                        child: Text(
                                                          "",
                                                          textAlign: TextAlign.left,
                                                          style: TextStyle(
                                                            color: Color.fromARGB(255, 0, 0, 0),
                                                            fontWeight: FontWeight.w400,
                                                            fontSize: 12,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Positioned(
                                                      left: 15,
                                                      child: Image.asset(
                                                        "assets/images/apple-2.png",
                                                        fit: BoxFit.none,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                            Align(
                                              alignment: Alignment.topLeft,
                                              child: Container(
                                                margin: EdgeInsets.only(left: 30, top: 8),
                                                child: Text(
                                                  "Apple Pay",
                                                  textAlign: TextAlign.left,
                                                  style: TextStyle(
                                                    color: AppColors.primaryText,
                                                    fontFamily: "Avenir",
                                                    fontWeight: FontWeight.w800,
                                                    fontSize: 14,
                                                    height: 1.28571,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}