/*
*  search_filter_widget.dart
*  Food UI Kit
*
*  Created by [Author].
*  Copyright © 2018 [Company]. All rights reserved.
    */

import 'package:flutter/material.dart';
import 'package:food_ui_kit/payment_method_widget/payment_method_widget.dart';
import 'package:food_ui_kit/shop_home_widget/shop_home_widget.dart';
import 'package:food_ui_kit/values/values.dart';


class SearchFilterWidget extends StatelessWidget {
  
  void onBackPressed(BuildContext context) => Navigator.push(context, MaterialPageRoute(builder: (context) => PaymentMethodWidget()));
  
  void onButtonPressed(BuildContext context) => Navigator.push(context, MaterialPageRoute(builder: (context) => ShopHomeWidget()));
  
  @override
  Widget build(BuildContext context) {
  
    return Scaffold(
      body: Container(
        constraints: BoxConstraints.expand(),
        decoration: BoxDecoration(
          color: Color.fromARGB(255, 255, 255, 255),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              height: 81,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.end,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 136,
                    height: 22,
                    margin: EdgeInsets.only(left: 16),
                    child: Row(
                      children: [
                        Container(
                          width: 13,
                          height: 19,
                          child: FlatButton(
                            onPressed: () => this.onBackPressed(context),
                            color: Color.fromARGB(0, 0, 0, 0),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.all(Radius.circular(0)),
                            ),
                            textColor: Color.fromARGB(255, 0, 0, 0),
                            padding: EdgeInsets.all(0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Image.asset("assets/images/back-3.png",),
                                SizedBox(
                                  width: 10,
                                ),
                                Text(
                                  "",
                                  textAlign: TextAlign.left,
                                  style: TextStyle(
                                    color: Color.fromARGB(255, 0, 0, 0),
                                    fontWeight: FontWeight.w400,
                                    fontSize: 12,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Spacer(),
                        Text(
                          "Search Filter",
                          textAlign: TextAlign.left,
                          style: TextStyle(
                            color: AppColors.primaryText,
                            fontFamily: "Avenir",
                            fontWeight: FontWeight.w800,
                            fontSize: 16,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Align(
              alignment: Alignment.topCenter,
              child: Container(
                width: 327,
                height: 77,
                margin: EdgeInsets.only(top: 40),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Align(
                      alignment: Alignment.topLeft,
                      child: Container(
                        margin: EdgeInsets.only(left: 1),
                        child: Text(
                          "Distance",
                          textAlign: TextAlign.left,
                          style: TextStyle(
                            color: AppColors.primaryText,
                            fontFamily: "Avenir",
                            fontWeight: FontWeight.w800,
                            fontSize: 16,
                            height: 1,
                          ),
                        ),
                      ),
                    ),
                    Container(
                      height: 41,
                      margin: EdgeInsets.only(top: 17),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Container(
                            height: 15,
                            child: Stack(
                              alignment: Alignment.center,
                              children: [
                                Positioned(
                                  left: 1,
                                  top: 3,
                                  right: 0,
                                  child: Container(
                                    height: 9,
                                    decoration: BoxDecoration(
                                      color: Color.fromARGB(255, 243, 243, 243),
                                      borderRadius: BorderRadius.all(Radius.circular(4.5)),
                                    ),
                                    child: Container(),
                                  ),
                                ),
                                Positioned(
                                  left: 7,
                                  top: 3,
                                  child: Container(
                                    width: 179,
                                    height: 9,
                                    decoration: BoxDecoration(
                                      color: AppColors.primaryElement,
                                      borderRadius: BorderRadius.all(Radius.circular(4.5)),
                                    ),
                                    child: Container(),
                                  ),
                                ),
                                Positioned(
                                  left: 0,
                                  top: 0,
                                  right: 134,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.stretch,
                                    children: [
                                      Align(
                                        alignment: Alignment.topLeft,
                                        child: Container(
                                          width: 15,
                                          height: 15,
                                          decoration: BoxDecoration(
                                            color: AppColors.primaryElement,
                                            border: Border.all(
                                              width: 2,
                                              color: Color.fromARGB(255, 255, 255, 255),
                                            ),
                                            boxShadow: [
                                              BoxShadow(
                                                color: Color.fromARGB(25, 0, 0, 0),
                                                offset: Offset(0, 1),
                                                blurRadius: 3,
                                              ),
                                            ],
                                            borderRadius: BorderRadius.all(Radius.circular(7.5)),
                                          ),
                                          child: Container(),
                                        ),
                                      ),
                                      Spacer(),
                                      Align(
                                        alignment: Alignment.topLeft,
                                        child: Container(
                                          width: 15,
                                          height: 15,
                                          decoration: BoxDecoration(
                                            color: AppColors.primaryElement,
                                            border: Border.all(
                                              width: 2,
                                              color: Color.fromARGB(255, 255, 255, 255),
                                            ),
                                            boxShadow: [
                                              BoxShadow(
                                                color: Color.fromARGB(25, 0, 0, 0),
                                                offset: Offset(0, 1),
                                                blurRadius: 3,
                                              ),
                                            ],
                                            borderRadius: BorderRadius.all(Radius.circular(7.5)),
                                          ),
                                          child: Container(),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Spacer(),
                          Container(
                            height: 20,
                            margin: EdgeInsets.only(right: 110),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: [
                                Align(
                                  alignment: Alignment.bottomLeft,
                                  child: Opacity(
                                    opacity: 0.59961,
                                    child: Text(
                                      "0 km",
                                      textAlign: TextAlign.left,
                                      style: TextStyle(
                                        color: AppColors.primaryText,
                                        fontFamily: "Avenir",
                                        fontWeight: FontWeight.w400,
                                        fontSize: 14,
                                        height: 1,
                                      ),
                                    ),
                                  ),
                                ),
                                Spacer(),
                                Align(
                                  alignment: Alignment.bottomLeft,
                                  child: Opacity(
                                    opacity: 0.59961,
                                    child: Text(
                                      "10 km",
                                      textAlign: TextAlign.left,
                                      style: TextStyle(
                                        color: AppColors.primaryText,
                                        fontFamily: "Avenir",
                                        fontWeight: FontWeight.w400,
                                        fontSize: 14,
                                        height: 1,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Align(
              alignment: Alignment.topLeft,
              child: Container(
                width: 300,
                height: 65,
                margin: EdgeInsets.only(left: 24, top: 35),
                child: Stack(
                  alignment: Alignment.topCenter,
                  children: [
                    Positioned(
                      top: 31,
                      child: Container(
                        width: 90,
                        height: 34,
                        decoration: BoxDecoration(
                          color: Color.fromARGB(255, 243, 243, 243),
                          borderRadius: BorderRadius.all(Radius.circular(17)),
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Opacity(
                              opacity: 0.59961,
                              child: Text(
                                "30 Min",
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  color: AppColors.primaryText,
                                  fontFamily: "Avenir",
                                  fontWeight: FontWeight.w400,
                                  fontSize: 14,
                                  height: 1,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      left: 0,
                      top: -3,
                      right: 0,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Align(
                            alignment: Alignment.topLeft,
                            child: Container(
                              margin: EdgeInsets.only(left: 2),
                              child: Text(
                                "Delivery Time",
                                textAlign: TextAlign.left,
                                style: TextStyle(
                                  color: AppColors.primaryText,
                                  fontFamily: "Avenir",
                                  fontWeight: FontWeight.w800,
                                  fontSize: 16,
                                  height: 1,
                                ),
                              ),
                            ),
                          ),
                          Container(
                            height: 34,
                            margin: EdgeInsets.only(top: 12),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: [
                                Align(
                                  alignment: Alignment.topLeft,
                                  child: Container(
                                    width: 90,
                                    height: 34,
                                    decoration: BoxDecoration(
                                      color: AppColors.primaryElement,
                                      borderRadius: BorderRadius.all(Radius.circular(17)),
                                    ),
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        Text(
                                          "20 Min",
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                            color: AppColors.primaryText,
                                            fontFamily: "Avenir",
                                            fontWeight: FontWeight.w500,
                                            fontSize: 14,
                                            height: 1,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                Spacer(),
                                Align(
                                  alignment: Alignment.topLeft,
                                  child: Container(
                                    width: 90,
                                    height: 34,
                                    decoration: BoxDecoration(
                                      color: Color.fromARGB(255, 243, 243, 243),
                                      borderRadius: BorderRadius.all(Radius.circular(17)),
                                    ),
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        Opacity(
                                          opacity: 0.59961,
                                          child: Text(
                                            "40 Min",
                                            textAlign: TextAlign.center,
                                            style: TextStyle(
                                              color: AppColors.primaryText,
                                              fontFamily: "Avenir",
                                              fontWeight: FontWeight.w400,
                                              fontSize: 14,
                                              height: 1,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Align(
              alignment: Alignment.topLeft,
              child: Container(
                width: 320,
                height: 136,
                margin: EdgeInsets.only(left: 24, top: 35),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Align(
                      alignment: Alignment.topLeft,
                      child: Text(
                        "Sort By",
                        textAlign: TextAlign.left,
                        style: TextStyle(
                          color: AppColors.primaryText,
                          fontFamily: "Avenir",
                          fontWeight: FontWeight.w800,
                          fontSize: 16,
                          height: 1,
                        ),
                      ),
                    ),
                    Container(
                      height: 25,
                      margin: EdgeInsets.only(top: 12),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Container(
                            height: 20,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: [
                                Align(
                                  alignment: Alignment.topLeft,
                                  child: Text(
                                    "Top Rated",
                                    textAlign: TextAlign.left,
                                    style: TextStyle(
                                      color: Color.fromARGB(255, 255, 210, 78),
                                      fontFamily: "Avenir",
                                      fontWeight: FontWeight.w800,
                                      fontSize: 14,
                                      height: 1,
                                    ),
                                  ),
                                ),
                                Spacer(),
                                Align(
                                  alignment: Alignment.topLeft,
                                  child: Container(
                                    width: 14,
                                    height: 10,
                                    margin: EdgeInsets.only(top: 5),
                                    child: Image.asset(
                                      "assets/images/selected-2.png",
                                      fit: BoxFit.none,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Spacer(),
                          Container(
                            height: 1,
                            decoration: BoxDecoration(
                              color: Color.fromARGB(255, 243, 243, 243),
                            ),
                            child: Container(),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      height: 25,
                      margin: EdgeInsets.only(top: 15),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Align(
                            alignment: Alignment.topLeft,
                            child: Opacity(
                              opacity: 0.59961,
                              child: Text(
                                "Price High to Low",
                                textAlign: TextAlign.left,
                                style: TextStyle(
                                  color: AppColors.primaryText,
                                  fontFamily: "Avenir",
                                  fontWeight: FontWeight.w400,
                                  fontSize: 14,
                                  height: 1,
                                ),
                              ),
                            ),
                          ),
                          Spacer(),
                          Container(
                            height: 1,
                            decoration: BoxDecoration(
                              color: Color.fromARGB(255, 243, 243, 243),
                            ),
                            child: Container(),
                          ),
                        ],
                      ),
                    ),
                    Spacer(),
                    Container(
                      height: 25,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Align(
                            alignment: Alignment.topLeft,
                            child: Opacity(
                              opacity: 0.59961,
                              child: Text(
                                "Price Low to High",
                                textAlign: TextAlign.left,
                                style: TextStyle(
                                  color: AppColors.primaryText,
                                  fontFamily: "Avenir",
                                  fontWeight: FontWeight.w400,
                                  fontSize: 14,
                                  height: 1,
                                ),
                              ),
                            ),
                          ),
                          Spacer(),
                          Container(
                            height: 1,
                            decoration: BoxDecoration(
                              color: Color.fromARGB(255, 243, 243, 243),
                            ),
                            child: Container(),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Align(
              alignment: Alignment.topLeft,
              child: Container(
                width: 180,
                height: 60,
                margin: EdgeInsets.only(left: 24, top: 35),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Align(
                      alignment: Alignment.topLeft,
                      child: Text(
                        "Rating Star",
                        textAlign: TextAlign.left,
                        style: TextStyle(
                          color: AppColors.primaryText,
                          fontFamily: "Avenir",
                          fontWeight: FontWeight.w800,
                          fontSize: 16,
                          height: 1,
                        ),
                      ),
                    ),
                    Spacer(),
                    Container(
                      height: 24,
                      child: Image.asset(
                        "assets/images/rating-3-3.png",
                        fit: BoxFit.none,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Spacer(),
            Align(
              alignment: Alignment.topCenter,
              child: Container(
                width: 326,
                height: 77,
                margin: EdgeInsets.only(bottom: 35),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Align(
                      alignment: Alignment.topLeft,
                      child: Text(
                        "Price",
                        textAlign: TextAlign.left,
                        style: TextStyle(
                          color: AppColors.primaryText,
                          fontFamily: "Avenir",
                          fontWeight: FontWeight.w800,
                          fontSize: 16,
                          height: 1,
                        ),
                      ),
                    ),
                    Container(
                      height: 41,
                      margin: EdgeInsets.only(top: 17),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Container(
                            height: 15,
                            child: Stack(
                              alignment: Alignment.center,
                              children: [
                                Positioned(
                                  left: 0,
                                  top: 3,
                                  right: 0,
                                  child: Container(
                                    height: 9,
                                    decoration: BoxDecoration(
                                      color: Color.fromARGB(255, 243, 243, 243),
                                      borderRadius: BorderRadius.all(Radius.circular(4.5)),
                                    ),
                                    child: Container(),
                                  ),
                                ),
                                Positioned(
                                  left: 34,
                                  top: 3,
                                  child: Container(
                                    width: 151,
                                    height: 9,
                                    decoration: BoxDecoration(
                                      color: AppColors.primaryElement,
                                      borderRadius: BorderRadius.all(Radius.circular(4.5)),
                                    ),
                                    child: Container(),
                                  ),
                                ),
                                Positioned(
                                  left: 34,
                                  top: 0,
                                  right: 134,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.stretch,
                                    children: [
                                      Align(
                                        alignment: Alignment.topLeft,
                                        child: Container(
                                          width: 15,
                                          height: 15,
                                          decoration: BoxDecoration(
                                            color: AppColors.primaryElement,
                                            border: Border.all(
                                              width: 2,
                                              color: Color.fromARGB(255, 255, 255, 255),
                                            ),
                                            boxShadow: [
                                              BoxShadow(
                                                color: Color.fromARGB(25, 0, 0, 0),
                                                offset: Offset(0, 1),
                                                blurRadius: 3,
                                              ),
                                            ],
                                            borderRadius: BorderRadius.all(Radius.circular(7.5)),
                                          ),
                                          child: Container(),
                                        ),
                                      ),
                                      Spacer(),
                                      Align(
                                        alignment: Alignment.topLeft,
                                        child: Container(
                                          width: 15,
                                          height: 15,
                                          decoration: BoxDecoration(
                                            color: AppColors.primaryElement,
                                            border: Border.all(
                                              width: 2,
                                              color: Color.fromARGB(255, 255, 255, 255),
                                            ),
                                            boxShadow: [
                                              BoxShadow(
                                                color: Color.fromARGB(25, 0, 0, 0),
                                                offset: Offset(0, 1),
                                                blurRadius: 3,
                                              ),
                                            ],
                                            borderRadius: BorderRadius.all(Radius.circular(7.5)),
                                          ),
                                          child: Container(),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Spacer(),
                          Container(
                            height: 20,
                            margin: EdgeInsets.only(left: 34, right: 125),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: [
                                Align(
                                  alignment: Alignment.bottomLeft,
                                  child: Opacity(
                                    opacity: 0.59961,
                                    child: Text(
                                      "\$10",
                                      textAlign: TextAlign.left,
                                      style: TextStyle(
                                        color: AppColors.primaryText,
                                        fontFamily: "Avenir",
                                        fontWeight: FontWeight.w400,
                                        fontSize: 14,
                                        height: 1,
                                      ),
                                    ),
                                  ),
                                ),
                                Spacer(),
                                Align(
                                  alignment: Alignment.bottomLeft,
                                  child: Opacity(
                                    opacity: 0.59961,
                                    child: Text(
                                      "\$50",
                                      textAlign: TextAlign.left,
                                      style: TextStyle(
                                        color: AppColors.primaryText,
                                        fontFamily: "Avenir",
                                        fontWeight: FontWeight.w400,
                                        fontSize: 14,
                                        height: 1,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Align(
              alignment: Alignment.topCenter,
              child: Container(
                width: 327,
                height: 48,
                margin: EdgeInsets.only(bottom: 12),
                child: FlatButton(
                  onPressed: () => this.onButtonPressed(context),
                  color: AppColors.primaryElement,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.all(Radius.circular(4)),
                  ),
                  textColor: Color.fromARGB(255, 66, 80, 96),
                  padding: EdgeInsets.all(0),
                  child: Text(
                    "Apply",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Color.fromARGB(255, 66, 80, 96),
                      fontFamily: "Avenir",
                      fontWeight: FontWeight.w800,
                      fontSize: 14,
                    ),
                  ),
                ),
              ),
            ),
            Align(
              alignment: Alignment.topCenter,
              child: Container(
                margin: EdgeInsets.only(bottom: 21),
                child: Text(
                  "Clear Filter",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Color.fromARGB(255, 255, 210, 78),
                    fontFamily: "Avenir",
                    fontWeight: FontWeight.w800,
                    fontSize: 14,
                    height: 1,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}