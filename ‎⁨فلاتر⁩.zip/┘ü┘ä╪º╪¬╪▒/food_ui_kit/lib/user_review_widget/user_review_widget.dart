/*
*  user_review_widget.dart
*  Food UI Kit
*
*  Created by [Author].
*  Copyright © 2018 [Company]. All rights reserved.
    */

import 'package:flutter/material.dart';
import 'package:food_ui_kit/burger_order_app_cart_widget/burger_order_app_cart_widget.dart';
import 'package:food_ui_kit/ingerdients_widget/ingerdients_widget.dart';
import 'package:food_ui_kit/values/values.dart';


class UserReviewWidget extends StatelessWidget {
  
  void onBackPressed(BuildContext context) => Navigator.push(context, MaterialPageRoute(builder: (context) => BurgerOrderAppCartWidget()));
  
  void onAddToCartButtonPressed(BuildContext context) => Navigator.push(context, MaterialPageRoute(builder: (context) => IngerdientsWidget()));
  
  void onGroup3Pressed(BuildContext context) {
  
  }
  
  void onGroup4CopyPressed(BuildContext context) {
  
  }
  
  @override
  Widget build(BuildContext context) {
  
    return Scaffold(
      body: Container(
        constraints: BoxConstraints.expand(),
        decoration: BoxDecoration(
          color: Color.fromARGB(255, 255, 255, 255),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              height: 300,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  Positioned(
                    left: 16,
                    top: 0,
                    right: 0,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          width: 40,
                          height: 150,
                          margin: EdgeInsets.only(top: 130),
                          child: Stack(
                            alignment: Alignment.center,
                            children: [
                              Positioned(
                                left: -1,
                                right: -1,
                                child: Image.asset(
                                  "assets/images/group-12.png",
                                  fit: BoxFit.none,
                                ),
                              ),
                              Positioned(
                                left: -1,
                                top: -1,
                                right: -1,
                                bottom: -1,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.stretch,
                                  children: [
                                    Container(
                                      height: 41,
                                      child: Image.asset(
                                        "assets/images/group-10-2.png",
                                        fit: BoxFit.none,
                                      ),
                                    ),
                                    Spacer(),
                                    Container(
                                      height: 41,
                                      child: Image.asset(
                                        "assets/images/group-11-2.png",
                                        fit: BoxFit.none,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        Spacer(),
                        Container(
                          width: 295,
                          height: 300,
                          child: Stack(
                            alignment: Alignment.center,
                            children: [
                              Positioned(
                                right: 0,
                                child: Container(
                                  width: 215,
                                  height: 300,
                                  decoration: BoxDecoration(
                                    color: Color.fromARGB(255, 255, 245, 176),
                                    boxShadow: [
                                      Shadows.secondaryShadow,
                                    ],
                                    borderRadius: BorderRadius.all(Radius.circular(50)),
                                  ),
                                  child: Container(),
                                ),
                              ),
                              Positioned(
                                top: 84,
                                right: 45,
                                child: Image.asset(
                                  "assets/images/burger-10956.png",
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Positioned(
                    left: 0,
                    top: 0,
                    right: 0,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Container(
                          width: 13,
                          height: 19,
                          margin: EdgeInsets.only(left: 16),
                          child: FlatButton(
                            onPressed: () => this.onBackPressed(context),
                            color: Color.fromARGB(0, 0, 0, 0),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.all(Radius.circular(0)),
                            ),
                            textColor: Color.fromARGB(255, 0, 0, 0),
                            padding: EdgeInsets.all(0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Image.asset("assets/images/back-3.png",),
                                SizedBox(
                                  width: 10,
                                ),
                                Text(
                                  "",
                                  textAlign: TextAlign.left,
                                  style: TextStyle(
                                    color: Color.fromARGB(255, 0, 0, 0),
                                    fontWeight: FontWeight.w400,
                                    fontSize: 12,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Spacer(),
                        Container(
                          width: 14,
                          height: 18,
                          margin: EdgeInsets.only(right: 16),
                          child: Image.asset(
                            "assets/images/cart.png",
                            fit: BoxFit.none,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              height: 121,
              margin: EdgeInsets.only(left: 16, top: 25, right: 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    height: 82,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Container(
                          height: 33,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Align(
                                alignment: Alignment.topLeft,
                                child: Text(
                                  "Chicken Burger",
                                  textAlign: TextAlign.left,
                                  style: TextStyle(
                                    color: AppColors.primaryText,
                                    fontFamily: "Avenir",
                                    fontWeight: FontWeight.w800,
                                    fontSize: 24,
                                    height: 0.91667,
                                  ),
                                ),
                              ),
                              Spacer(),
                              Align(
                                alignment: Alignment.topLeft,
                                child: Container(
                                  width: 30,
                                  height: 30,
                                  margin: EdgeInsets.only(top: 2),
                                  child: Image.asset(
                                    "assets/images/favorite-heart-button.png",
                                    fit: BoxFit.none,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Align(
                          alignment: Alignment.topLeft,
                          child: Container(
                            width: 202,
                            height: 19,
                            margin: EdgeInsets.only(top: 5),
                            child: Row(
                              children: [
                                Container(
                                  width: 8,
                                  height: 12,
                                  child: Image.asset(
                                    "assets/images/maps-and-flags-3.png",
                                    fit: BoxFit.none,
                                  ),
                                ),
                                Expanded(
                                  flex: 1,
                                  child: Container(
                                    margin: EdgeInsets.only(left: 10, right: 1),
                                    child: Opacity(
                                      opacity: 0.59961,
                                      child: Text(
                                        "Italiano Restaurant and Coffe",
                                        textAlign: TextAlign.left,
                                        style: TextStyle(
                                          color: AppColors.primaryText,
                                          fontFamily: "Avenir",
                                          fontWeight: FontWeight.w400,
                                          fontSize: 14,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Spacer(),
                        Container(
                          height: 13,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Align(
                                alignment: Alignment.bottomLeft,
                                child: Container(
                                  width: 75,
                                  height: 13,
                                  child: Row(
                                    children: [
                                      Container(
                                        width: 15,
                                        height: 14,
                                        child: Image.asset(
                                          "assets/images/path-7.png",
                                          fit: BoxFit.none,
                                        ),
                                      ),
                                      Spacer(),
                                      Container(
                                        margin: EdgeInsets.only(right: 7),
                                        child: Opacity(
                                          opacity: 0.59961,
                                          child: Text(
                                            "4.3 (132)",
                                            textAlign: TextAlign.left,
                                            style: TextStyle(
                                              color: AppColors.primaryText,
                                              fontFamily: "Avenir",
                                              fontWeight: FontWeight.w400,
                                              fontSize: 12,
                                              height: 1.16667,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Align(
                                alignment: Alignment.bottomLeft,
                                child: Container(
                                  width: 62,
                                  height: 12,
                                  margin: EdgeInsets.only(left: 57),
                                  child: Row(
                                    children: [
                                      Container(
                                        width: 12,
                                        height: 12,
                                        child: Image.asset(
                                          "assets/images/002-clock-2.png",
                                          fit: BoxFit.none,
                                        ),
                                      ),
                                      Expanded(
                                        flex: 1,
                                        child: Container(
                                          margin: EdgeInsets.only(left: 7, right: 6),
                                          child: Opacity(
                                            opacity: 0.59961,
                                            child: Text(
                                              "30 min",
                                              textAlign: TextAlign.left,
                                              style: TextStyle(
                                                color: AppColors.primaryText,
                                                fontFamily: "Avenir",
                                                fontWeight: FontWeight.w400,
                                                fontSize: 12,
                                                height: 1.16667,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Spacer(),
                              Align(
                                alignment: Alignment.bottomLeft,
                                child: Container(
                                  width: 58,
                                  height: 12,
                                  child: Row(
                                    children: [
                                      Container(
                                        width: 10,
                                        height: 13,
                                        child: Image.asset(
                                          "assets/images/maps-and-flags-2.png",
                                          fit: BoxFit.none,
                                        ),
                                      ),
                                      Expanded(
                                        flex: 1,
                                        child: Container(
                                          margin: EdgeInsets.symmetric(horizontal: 6),
                                          child: Opacity(
                                            opacity: 0.59961,
                                            child: Text(
                                              "1.4 km",
                                              textAlign: TextAlign.left,
                                              style: TextStyle(
                                                color: AppColors.primaryText,
                                                fontFamily: "Avenir",
                                                fontWeight: FontWeight.w400,
                                                fontSize: 12,
                                                height: 1.16667,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Spacer(),
                  Align(
                    alignment: Alignment.topCenter,
                    child: Container(
                      width: 262,
                      height: 19,
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          Positioned(
                            child: Opacity(
                              opacity: 0.59961,
                              child: Text(
                                "Ingradients",
                                textAlign: TextAlign.left,
                                style: TextStyle(
                                  color: AppColors.primaryText,
                                  fontFamily: "Avenir",
                                  fontWeight: FontWeight.w400,
                                  fontSize: 14,
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            left: 0,
                            right: 0,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: [
                                Align(
                                  alignment: Alignment.centerLeft,
                                  child: Opacity(
                                    opacity: 0.59961,
                                    child: Text(
                                      "Details",
                                      textAlign: TextAlign.left,
                                      style: TextStyle(
                                        color: AppColors.primaryText,
                                        fontFamily: "Avenir",
                                        fontWeight: FontWeight.w400,
                                        fontSize: 14,
                                      ),
                                    ),
                                  ),
                                ),
                                Spacer(),
                                Align(
                                  alignment: Alignment.centerLeft,
                                  child: Text(
                                    "Review",
                                    textAlign: TextAlign.left,
                                    style: TextStyle(
                                      color: AppColors.primaryText,
                                      fontFamily: "Avenir",
                                      fontWeight: FontWeight.w800,
                                      fontSize: 14,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              flex: 1,
              child: Container(
                margin: EdgeInsets.only(top: 12),
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    Positioned(
                      left: 0,
                      right: 0,
                      bottom: 0,
                      child: Container(
                        height: 354,
                        decoration: BoxDecoration(
                          color: Color.fromARGB(255, 252, 252, 252),
                          borderRadius: BorderRadius.all(Radius.circular(33)),
                        ),
                        child: Container(),
                      ),
                    ),
                    Positioned(
                      left: 16,
                      top: 18,
                      right: 16,
                      bottom: 60,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Container(
                            height: 159,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: [
                                Container(
                                  height: 100,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.stretch,
                                    children: [
                                      Align(
                                        alignment: Alignment.topLeft,
                                        child: Container(
                                          width: 40,
                                          height: 40,
                                          child: Image.asset(
                                            "assets/images/bitmap-4.png",
                                            fit: BoxFit.none,
                                          ),
                                        ),
                                      ),
                                      Expanded(
                                        flex: 1,
                                        child: Align(
                                          alignment: Alignment.topLeft,
                                          child: Container(
                                            height: 100,
                                            margin: EdgeInsets.only(left: 10),
                                            child: Column(
                                              crossAxisAlignment: CrossAxisAlignment.stretch,
                                              children: [
                                                Align(
                                                  alignment: Alignment.topLeft,
                                                  child: Container(
                                                    width: 60,
                                                    height: 12,
                                                    child: Image.asset(
                                                      "assets/images/rating-3.png",
                                                      fit: BoxFit.none,
                                                    ),
                                                  ),
                                                ),
                                                Container(
                                                  height: 20,
                                                  margin: EdgeInsets.only(top: 4, right: 29),
                                                  child: Row(
                                                    crossAxisAlignment: CrossAxisAlignment.stretch,
                                                    children: [
                                                      Align(
                                                        alignment: Alignment.topLeft,
                                                        child: Text(
                                                          "Rafa Islam",
                                                          textAlign: TextAlign.left,
                                                          style: TextStyle(
                                                            color: AppColors.primaryText,
                                                            fontFamily: "Avenir",
                                                            fontWeight: FontWeight.w500,
                                                            fontSize: 14,
                                                            height: 1,
                                                          ),
                                                        ),
                                                      ),
                                                      Spacer(),
                                                      Align(
                                                        alignment: Alignment.topLeft,
                                                        child: Container(
                                                          margin: EdgeInsets.only(top: 2),
                                                          child: Opacity(
                                                            opacity: 0.59961,
                                                            child: Text(
                                                              "01-02-19",
                                                              textAlign: TextAlign.left,
                                                              style: TextStyle(
                                                                color: AppColors.primaryText,
                                                                fontFamily: "Avenir",
                                                                fontWeight: FontWeight.w400,
                                                                fontSize: 12,
                                                                height: 1.16667,
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                                Align(
                                                  alignment: Alignment.topRight,
                                                  child: Container(
                                                    width: 293,
                                                    margin: EdgeInsets.only(top: 1),
                                                    child: Opacity(
                                                      opacity: 0.59961,
                                                      child: Text(
                                                        "Pizza is a savory dish of Italian origin consistin usualy round, flattened base of leavene cheas topped with tomatoes.",
                                                        textAlign: TextAlign.left,
                                                        style: TextStyle(
                                                          color: AppColors.primaryText,
                                                          fontFamily: "Avenir",
                                                          fontWeight: FontWeight.w400,
                                                          fontSize: 14,
                                                          height: 1.5,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Spacer(),
                                Align(
                                  alignment: Alignment.topLeft,
                                  child: Container(
                                    width: 170,
                                    height: 50,
                                    margin: EdgeInsets.only(left: 50),
                                    child: Stack(
                                      alignment: Alignment.center,
                                      children: [
                                        Positioned(
                                          left: 0,
                                          right: -5,
                                          child: Row(
                                            crossAxisAlignment: CrossAxisAlignment.stretch,
                                            children: [
                                              Align(
                                                alignment: Alignment.centerLeft,
                                                child: Container(
                                                  width: 50,
                                                  height: 50,
                                                  child: Image.asset(
                                                    "assets/images/layer-0-2.png",
                                                    fit: BoxFit.none,
                                                  ),
                                                ),
                                              ),
                                              Spacer(),
                                              Align(
                                                alignment: Alignment.centerLeft,
                                                child: Container(
                                                  width: 55,
                                                  height: 50,
                                                  child: Image.asset(
                                                    "assets/images/layer-0-copy-2.png",
                                                    fit: BoxFit.none,
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Positioned(
                                          child: Image.asset(
                                            "assets/images/layer-0-copy.png",
                                            fit: BoxFit.none,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Spacer(),
                          Container(
                            height: 97,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  width: 40,
                                  height: 40,
                                  child: Image.asset(
                                    "assets/images/oval.png",
                                    fit: BoxFit.none,
                                  ),
                                ),
                                Expanded(
                                  flex: 1,
                                  child: Container(
                                    height: 100,
                                    margin: EdgeInsets.only(left: 10),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.stretch,
                                      children: [
                                        Align(
                                          alignment: Alignment.topLeft,
                                          child: Container(
                                            width: 60,
                                            height: 12,
                                            child: Image.asset(
                                              "assets/images/rating-3.png",
                                              fit: BoxFit.none,
                                            ),
                                          ),
                                        ),
                                        Container(
                                          height: 20,
                                          margin: EdgeInsets.only(top: 4, right: 29),
                                          child: Row(
                                            crossAxisAlignment: CrossAxisAlignment.stretch,
                                            children: [
                                              Align(
                                                alignment: Alignment.topLeft,
                                                child: Text(
                                                  "Jon Kalbert",
                                                  textAlign: TextAlign.left,
                                                  style: TextStyle(
                                                    color: AppColors.primaryText,
                                                    fontFamily: "Avenir",
                                                    fontWeight: FontWeight.w500,
                                                    fontSize: 14,
                                                    height: 1,
                                                  ),
                                                ),
                                              ),
                                              Spacer(),
                                              Align(
                                                alignment: Alignment.topLeft,
                                                child: Container(
                                                  margin: EdgeInsets.only(top: 2),
                                                  child: Opacity(
                                                    opacity: 0.59961,
                                                    child: Text(
                                                      "01-02-19",
                                                      textAlign: TextAlign.left,
                                                      style: TextStyle(
                                                        color: AppColors.primaryText,
                                                        fontFamily: "Avenir",
                                                        fontWeight: FontWeight.w400,
                                                        fontSize: 12,
                                                        height: 1.16667,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Align(
                                          alignment: Alignment.topRight,
                                          child: Container(
                                            width: 293,
                                            margin: EdgeInsets.only(top: 1),
                                            child: Opacity(
                                              opacity: 0.59961,
                                              child: Text(
                                                "Pizza is a savory dish of Italian origin consistin usualy round, flattened base of leavene cheas topped with tomatoes.",
                                                textAlign: TextAlign.left,
                                                style: TextStyle(
                                                  color: AppColors.primaryText,
                                                  fontFamily: "Avenir",
                                                  fontWeight: FontWeight.w400,
                                                  fontSize: 14,
                                                  height: 1.5,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Positioned(
                      left: 0,
                      right: 0,
                      bottom: 0,
                      child: Container(
                        height: 90,
                        decoration: BoxDecoration(
                          color: Color.fromARGB(255, 255, 245, 176),
                          boxShadow: [
                            Shadows.secondaryShadow,
                          ],
                          borderRadius: BorderRadius.all(Radius.circular(12)),
                        ),
                        child: Row(
                          children: [
                            Container(
                              width: 110,
                              height: 50,
                              margin: EdgeInsets.only(left: 24),
                              decoration: BoxDecoration(
                                color: AppColors.secondaryElement,
                                boxShadow: [
                                  BoxShadow(
                                    color: Color.fromARGB(6, 0, 0, 0),
                                    offset: Offset(0, 2),
                                    blurRadius: 8,
                                  ),
                                ],
                                borderRadius: BorderRadius.all(Radius.circular(4)),
                              ),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                children: [
                                  Container(
                                    height: 16,
                                    margin: EdgeInsets.symmetric(horizontal: 18),
                                    child: Stack(
                                      alignment: Alignment.center,
                                      children: [
                                        Positioned(
                                          left: 0,
                                          right: 0,
                                          child: Row(
                                            crossAxisAlignment: CrossAxisAlignment.stretch,
                                            children: [
                                              Align(
                                                alignment: Alignment.centerLeft,
                                                child: Container(
                                                  width: 16,
                                                  height: 16,
                                                  child: FlatButton(
                                                    onPressed: () => this.onGroup4CopyPressed(context),
                                                    color: Color.fromARGB(255, 243, 243, 243),
                                                    shape: RoundedRectangleBorder(
                                                      borderRadius: BorderRadius.all(Radius.circular(8)),
                                                    ),
                                                    textColor: Color.fromARGB(255, 0, 0, 0),
                                                    padding: EdgeInsets.all(0),
                                                    child: Row(
                                                      mainAxisAlignment: MainAxisAlignment.center,
                                                      children: [
                                                        Image.asset("assets/images/group-3-7.png",),
                                                        SizedBox(
                                                          width: 10,
                                                        ),
                                                        Text(
                                                          "",
                                                          textAlign: TextAlign.left,
                                                          style: TextStyle(
                                                            color: Color.fromARGB(255, 0, 0, 0),
                                                            fontWeight: FontWeight.w400,
                                                            fontSize: 12,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Spacer(),
                                              Align(
                                                alignment: Alignment.centerLeft,
                                                child: Container(
                                                  width: 16,
                                                  height: 16,
                                                  decoration: BoxDecoration(
                                                    color: Color.fromARGB(255, 243, 243, 243),
                                                    borderRadius: BorderRadius.all(Radius.circular(8)),
                                                  ),
                                                  child: Column(
                                                    mainAxisAlignment: MainAxisAlignment.center,
                                                    crossAxisAlignment: CrossAxisAlignment.stretch,
                                                    children: [
                                                      Container(
                                                        height: 8,
                                                        margin: EdgeInsets.symmetric(horizontal: 4),
                                                        child: FlatButton(
                                                          onPressed: () => this.onGroup3Pressed(context),
                                                          color: Color.fromARGB(0, 0, 0, 0),
                                                          shape: RoundedRectangleBorder(
                                                            borderRadius: BorderRadius.all(Radius.circular(0)),
                                                          ),
                                                          textColor: Color.fromARGB(255, 0, 0, 0),
                                                          padding: EdgeInsets.all(0),
                                                          child: Row(
                                                            mainAxisAlignment: MainAxisAlignment.center,
                                                            children: [
                                                              Image.asset("assets/images/group-3-5.png",),
                                                              SizedBox(
                                                                width: 10,
                                                              ),
                                                              Text(
                                                                "",
                                                                textAlign: TextAlign.left,
                                                                style: TextStyle(
                                                                  color: Color.fromARGB(255, 0, 0, 0),
                                                                  fontWeight: FontWeight.w400,
                                                                  fontSize: 12,
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Positioned(
                                          child: Text(
                                            "2",
                                            textAlign: TextAlign.left,
                                            style: TextStyle(
                                              color: AppColors.primaryText,
                                              fontFamily: "Avenir",
                                              fontWeight: FontWeight.w500,
                                              fontSize: 14,
                                              height: 1,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Spacer(),
                            Container(
                              width: 212,
                              height: 50,
                              margin: EdgeInsets.only(right: 16),
                              child: FlatButton(
                                onPressed: () => this.onAddToCartButtonPressed(context),
                                color: AppColors.primaryElement,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.all(Radius.circular(4)),
                                ),
                                textColor: Color.fromARGB(255, 66, 80, 96),
                                padding: EdgeInsets.all(0),
                                child: Text(
                                  "Add To Cart",
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    color: Color.fromARGB(255, 66, 80, 96),
                                    fontFamily: "Avenir",
                                    fontWeight: FontWeight.w800,
                                    fontSize: 14,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}