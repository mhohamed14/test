/*
*  track_order_widget.dart
*  Food UI Kit
*
*  Created by [Author].
*  Copyright © 2018 [Company]. All rights reserved.
    */

import 'package:flutter/material.dart';
import 'package:food_ui_kit/notification_widget/notification_widget.dart';
import 'package:food_ui_kit/order_details_widget/order_details_widget.dart';
import 'package:food_ui_kit/values/values.dart';


class TrackOrderWidget extends StatelessWidget {
  
  void onRectanglePressed(BuildContext context) => Navigator.push(context, MaterialPageRoute(builder: (context) => OrderDetailsWidget()));
  
  void onBackPressed(BuildContext context) => Navigator.push(context, MaterialPageRoute(builder: (context) => NotificationWidget()));
  
  void onButtonPressed(BuildContext context) => Navigator.push(context, MaterialPageRoute(builder: (context) => OrderDetailsWidget()));
  
  @override
  Widget build(BuildContext context) {
  
    return Scaffold(
      body: Container(
        constraints: BoxConstraints.expand(),
        decoration: BoxDecoration(
          color: Color.fromARGB(255, 250, 250, 250),
        ),
        child: Stack(
          alignment: Alignment.topRight,
          children: [
            Positioned(
              left: -174,
              right: -253,
              bottom: -433,
              child: Image.asset(
                "assets/images/bitmap-9.png",
                fit: BoxFit.cover,
              ),
            ),
            Positioned(
              left: 134,
              top: 207,
              right: 0,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Align(
                    alignment: Alignment.topRight,
                    child: Container(
                      width: 58,
                      height: 40,
                      decoration: BoxDecoration(
                        color: Color.fromARGB(255, 247, 248, 249),
                      ),
                      child: Container(),
                    ),
                  ),
                  Align(
                    alignment: Alignment.topLeft,
                    child: Container(
                      width: 58,
                      height: 40,
                      margin: EdgeInsets.only(top: 186),
                      decoration: BoxDecoration(
                        color: Color.fromARGB(255, 247, 248, 249),
                      ),
                      child: Container(),
                    ),
                  ),
                ],
              ),
            ),
            Positioned(
              left: 0,
              top: -8,
              right: 0,
              child: Opacity(
                opacity: 0.30118,
                child: Container(
                  height: 812,
                  decoration: BoxDecoration(
                    color: Color.fromARGB(255, 245, 246, 246),
                  ),
                  child: Container(),
                ),
              ),
            ),
            Positioned(
              left: 0,
              top: 0,
              right: 0,
              bottom: 30,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    height: 81,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.end,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          width: 133,
                          height: 22,
                          margin: EdgeInsets.only(left: 16),
                          child: Row(
                            children: [
                              Container(
                                width: 13,
                                height: 19,
                                child: FlatButton(
                                  onPressed: () => this.onBackPressed(context),
                                  color: Color.fromARGB(0, 0, 0, 0),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.all(Radius.circular(0)),
                                  ),
                                  textColor: Color.fromARGB(255, 0, 0, 0),
                                  padding: EdgeInsets.all(0),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Image.asset("assets/images/back-3.png",),
                                      SizedBox(
                                        width: 10,
                                      ),
                                      Text(
                                        "",
                                        textAlign: TextAlign.left,
                                        style: TextStyle(
                                          color: Color.fromARGB(255, 0, 0, 0),
                                          fontWeight: FontWeight.w400,
                                          fontSize: 12,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Spacer(),
                              Container(
                                margin: EdgeInsets.only(right: 2),
                                child: Text(
                                  "Track Order",
                                  textAlign: TextAlign.left,
                                  style: TextStyle(
                                    color: AppColors.primaryText,
                                    fontFamily: "Avenir",
                                    fontWeight: FontWeight.w800,
                                    fontSize: 16,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Align(
                    alignment: Alignment.topRight,
                    child: Container(
                      width: 24,
                      height: 34,
                      margin: EdgeInsets.only(top: 72, right: 23),
                      child: Image.asset(
                        "assets/images/shape-14.png",
                        fit: BoxFit.none,
                      ),
                    ),
                  ),
                  Align(
                    alignment: Alignment.topRight,
                    child: Container(
                      width: 136,
                      height: 41,
                      margin: EdgeInsets.only(top: 4, right: 53),
                      child: Image.asset(
                        "assets/images/rectangle-copy-5.png",
                        fit: BoxFit.none,
                      ),
                    ),
                  ),
                  Align(
                    alignment: Alignment.topLeft,
                    child: Container(
                      width: 30,
                      height: 40,
                      margin: EdgeInsets.only(left: 135, top: 193),
                      child: Image.asset(
                        "assets/images/shape-15.png",
                        fit: BoxFit.none,
                      ),
                    ),
                  ),
                  Spacer(),
                  Container(
                    height: 215,
                    margin: EdgeInsets.symmetric(horizontal: 20),
                    decoration: BoxDecoration(
                      color: AppColors.primaryBackground,
                      boxShadow: [
                        Shadows.primaryShadow,
                      ],
                      borderRadius: BorderRadius.all(Radius.circular(24)),
                    ),
                    child: Column(
                      children: [
                        Container(
                          width: 285,
                          height: 44,
                          margin: EdgeInsets.only(top: 40),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Container(
                                width: 126,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.stretch,
                                  children: [
                                    Align(
                                      alignment: Alignment.topLeft,
                                      child: Text(
                                        "Tracking Order",
                                        textAlign: TextAlign.left,
                                        style: TextStyle(
                                          color: AppColors.primaryText,
                                          fontFamily: "Avenir",
                                          fontWeight: FontWeight.w800,
                                          fontSize: 18,
                                          height: 1,
                                        ),
                                      ),
                                    ),
                                    Spacer(),
                                    Align(
                                      alignment: Alignment.topLeft,
                                      child: Text(
                                        "Order No: 1454530",
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                          color: Color.fromARGB(255, 248, 197, 49),
                                          fontFamily: "Avenir",
                                          fontWeight: FontWeight.w500,
                                          fontSize: 14,
                                          height: 1,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Spacer(),
                              Align(
                                alignment: Alignment.centerLeft,
                                child: Container(
                                  width: 100,
                                  height: 40,
                                  child: FlatButton(
                                    onPressed: () => this.onButtonPressed(context),
                                    color: AppColors.primaryElement,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.all(Radius.circular(4)),
                                    ),
                                    textColor: Color.fromARGB(255, 66, 80, 96),
                                    padding: EdgeInsets.all(0),
                                    child: Text(
                                      "Details",
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        color: Color.fromARGB(255, 66, 80, 96),
                                        fontFamily: "Avenir",
                                        fontWeight: FontWeight.w800,
                                        fontSize: 14,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          width: 285,
                          height: 2,
                          margin: EdgeInsets.only(top: 20),
                          decoration: BoxDecoration(
                            color: AppColors.accentElement,
                          ),
                          child: Container(),
                        ),
                        Container(
                          width: 285,
                          height: 50,
                          margin: EdgeInsets.only(top: 19),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Align(
                                alignment: Alignment.centerLeft,
                                child: Container(
                                  width: 50,
                                  height: 50,
                                  child: Stack(
                                    alignment: Alignment.center,
                                    children: [
                                      Positioned(
                                        left: 0,
                                        child: Container(
                                          width: 50,
                                          height: 50,
                                          decoration: BoxDecoration(
                                            color: Color.fromARGB(255, 255, 226, 140),
                                            borderRadius: BorderRadius.all(Radius.circular(12)),
                                          ),
                                          child: Container(),
                                        ),
                                      ),
                                      Positioned(
                                        left: 14,
                                        child: Image.asset(
                                          "assets/images/group-6.png",
                                          fit: BoxFit.none,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Container(
                                width: 90,
                                margin: EdgeInsets.only(left: 15, top: 1, bottom: 4),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.stretch,
                                  children: [
                                    Align(
                                      alignment: Alignment.topLeft,
                                      child: Text(
                                        "Mahfuz Ali",
                                        textAlign: TextAlign.left,
                                        style: TextStyle(
                                          color: AppColors.primaryText,
                                          fontFamily: "Avenir",
                                          fontWeight: FontWeight.w800,
                                          fontSize: 18,
                                          height: 1,
                                        ),
                                      ),
                                    ),
                                    Spacer(),
                                    Align(
                                      alignment: Alignment.topLeft,
                                      child: Opacity(
                                        opacity: 0.59961,
                                        child: Text(
                                          "Delivery Man",
                                          textAlign: TextAlign.left,
                                          style: TextStyle(
                                            color: AppColors.primaryText,
                                            fontFamily: "Avenir",
                                            fontWeight: FontWeight.w400,
                                            fontSize: 12,
                                            height: 1.16667,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Spacer(),
                              Align(
                                alignment: Alignment.centerLeft,
                                child: Container(
                                  width: 36,
                                  height: 36,
                                  child: Image.asset(
                                    "assets/images/call.png",
                                    fit: BoxFit.none,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Positioned(
              top: 224,
              right: 142,
              child: Image.asset(
                "assets/images/rectangle-4.png",
                fit: BoxFit.none,
              ),
            ),
            Positioned(
              top: 420,
              right: 143,
              child: Image.asset(
                "assets/images/rectangle-copy-4.png",
                fit: BoxFit.none,
              ),
            ),
            Positioned(
              top: 140,
              right: 110,
              child: Image.asset(
                "assets/images/bike-2.png",
                fit: BoxFit.none,
              ),
            ),
            Positioned(
              left: 122,
              top: 171,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  Positioned(
                    left: 3,
                    top: 12,
                    right: 3,
                    child: Container(
                      height: 24,
                      decoration: BoxDecoration(
                        color: AppColors.primaryElement,
                        borderRadius: BorderRadius.all(Radius.circular(6)),
                      ),
                      child: Container(),
                    ),
                  ),
                  Positioned(
                    left: 0,
                    right: 0,
                    child: FlatButton(
                      onPressed: () => this.onRectanglePressed(context),
                      color: AppColors.primaryElement,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.all(Radius.circular(6)),
                      ),
                      textColor: Color.fromARGB(255, 0, 0, 0),
                      padding: EdgeInsets.all(0),
                      child: Text(
                        "",
                        textAlign: TextAlign.left,
                        style: TextStyle(
                          color: Color.fromARGB(255, 0, 0, 0),
                          fontWeight: FontWeight.w400,
                          fontSize: 12,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    left: 16,
                    top: 7,
                    right: 16,
                    child: Text(
                      "20 min",
                      textAlign: TextAlign.left,
                      style: TextStyle(
                        color: AppColors.primaryText,
                        fontFamily: "Avenir",
                        fontWeight: FontWeight.w800,
                        fontSize: 12,
                        height: 1.16667,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}