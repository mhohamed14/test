/*
*  food_category_widget.dart
*  Food UI Kit
*
*  Created by [Author].
*  Copyright © 2018 [Company]. All rights reserved.
    */

import 'package:flutter/material.dart';
import 'package:food_ui_kit/burger_category_page_widget/burger_category_page_widget.dart';
import 'package:food_ui_kit/home_widget/home_widget.dart';
import 'package:food_ui_kit/values/values.dart';


class FoodCategoryWidget extends StatelessWidget {
  
  void onBackPressed(BuildContext context) => Navigator.push(context, MaterialPageRoute(builder: (context) => BurgerCategoryPageWidget()));
  
  void onCartPressed(BuildContext context) => Navigator.push(context, MaterialPageRoute(builder: (context) => HomeWidget()));
  
  void onCombinedShapePressed(BuildContext context) {
  
  }
  
  void onGroup5Pressed(BuildContext context) => Navigator.push(context, MaterialPageRoute(builder: (context) => HomeWidget()));
  
  void onGroup2Pressed(BuildContext context) {
  
  }
  
  void onGroup3CopyPressed(BuildContext context) {
  
  }
  
  void onNearbyCopyPressed(BuildContext context) {
  
  }
  
  @override
  Widget build(BuildContext context) {
  
    return Scaffold(
      body: Container(
        constraints: BoxConstraints.expand(),
        decoration: BoxDecoration(
          color: Color.fromARGB(255, 250, 250, 250),
        ),
        child: Stack(
          alignment: Alignment.topCenter,
          children: [
            Positioned(
              left: 0,
              top: 0,
              right: 0,
              child: Container(
                height: 820,
                decoration: BoxDecoration(
                  color: AppColors.primaryBackground,
                ),
                child: Container(),
              ),
            ),
            Positioned(
              left: 0,
              top: 0,
              right: 0,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    height: 100,
                    decoration: BoxDecoration(
                      color: AppColors.primaryBackground,
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Container(
                          height: 22,
                          margin: EdgeInsets.only(left: 16, top: 56, right: 15),
                          child: Row(
                            children: [
                              Container(
                                width: 11,
                                height: 17,
                                child: FlatButton(
                                  onPressed: () => this.onBackPressed(context),
                                  color: Color.fromARGB(0, 0, 0, 0),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.all(Radius.circular(0)),
                                  ),
                                  textColor: Color.fromARGB(255, 0, 0, 0),
                                  padding: EdgeInsets.all(0),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Image.asset("assets/images/back-2.png",),
                                      SizedBox(
                                        width: 10,
                                      ),
                                      Text(
                                        "",
                                        textAlign: TextAlign.left,
                                        style: TextStyle(
                                          color: Color.fromARGB(255, 0, 0, 0),
                                          fontWeight: FontWeight.w400,
                                          fontSize: 12,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.only(left: 30),
                                child: Text(
                                  "Food Category",
                                  textAlign: TextAlign.left,
                                  style: TextStyle(
                                    color: AppColors.primaryText,
                                    fontFamily: "Avenir",
                                    fontWeight: FontWeight.w800,
                                    fontSize: 16,
                                  ),
                                ),
                              ),
                              Spacer(),
                              Align(
                                alignment: Alignment.topLeft,
                                child: Container(
                                  width: 16,
                                  height: 18,
                                  margin: EdgeInsets.only(right: 24),
                                  child: Image.asset(
                                    "assets/images/003-notification-1.png",
                                    fit: BoxFit.none,
                                  ),
                                ),
                              ),
                              Container(
                                width: 14,
                                height: 18,
                                child: FlatButton(
                                  onPressed: () => this.onCartPressed(context),
                                  color: Color.fromARGB(0, 0, 0, 0),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.all(Radius.circular(0)),
                                  ),
                                  textColor: Color.fromARGB(255, 0, 0, 0),
                                  padding: EdgeInsets.all(0),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Image.asset("assets/images/cart.png",),
                                      SizedBox(
                                        width: 10,
                                      ),
                                      Text(
                                        "",
                                        textAlign: TextAlign.left,
                                        style: TextStyle(
                                          color: Color.fromARGB(255, 0, 0, 0),
                                          fontWeight: FontWeight.w400,
                                          fontSize: 12,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    height: 741,
                    margin: EdgeInsets.only(top: 4, right: 14),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Align(
                          alignment: Alignment.topLeft,
                          child: Container(
                            width: 90,
                            height: 708,
                            child: Stack(
                              alignment: Alignment.center,
                              children: [
                                Positioned(
                                  left: 0,
                                  right: 0,
                                  child: Container(
                                    height: 704,
                                    decoration: BoxDecoration(
                                      color: Color.fromARGB(255, 247, 248, 249),
                                    ),
                                    child: Container(),
                                  ),
                                ),
                                Positioned(
                                  left: 0,
                                  top: 0,
                                  right: 0,
                                  bottom: 58,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.stretch,
                                    children: [
                                      Container(
                                        height: 139,
                                        child: Stack(
                                          alignment: Alignment.center,
                                          children: [
                                            Positioned(
                                              left: 0,
                                              right: 0,
                                              child: FlatButton(
                                                onPressed: () => this.onCombinedShapePressed(context),
                                                color: Color.fromARGB(0, 0, 0, 0),
                                                shape: RoundedRectangleBorder(
                                                  borderRadius: BorderRadius.all(Radius.circular(0)),
                                                ),
                                                textColor: Color.fromARGB(255, 0, 0, 0),
                                                padding: EdgeInsets.all(0),
                                                child: Text(
                                                  "",
                                                  textAlign: TextAlign.left,
                                                  style: TextStyle(
                                                    color: Color.fromARGB(255, 0, 0, 0),
                                                    fontWeight: FontWeight.w400,
                                                    fontSize: 12,
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Positioned(
                                              left: 17,
                                              top: 39,
                                              right: 17,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                                children: [
                                                  Align(
                                                    alignment: Alignment.topCenter,
                                                    child: Container(
                                                      width: 40,
                                                      height: 40,
                                                      child: Stack(
                                                        alignment: Alignment.center,
                                                        children: [
                                                          Positioned(
                                                            left: 0,
                                                            right: 0,
                                                            child: Row(
                                                              crossAxisAlignment: CrossAxisAlignment.stretch,
                                                              children: [
                                                                Align(
                                                                  alignment: Alignment.centerLeft,
                                                                  child: Container(
                                                                    width: 19,
                                                                    height: 37,
                                                                    child: Image.asset(
                                                                      "assets/images/fried-potatoes.png",
                                                                      fit: BoxFit.none,
                                                                    ),
                                                                  ),
                                                                ),
                                                                Spacer(),
                                                                Align(
                                                                  alignment: Alignment.centerLeft,
                                                                  child: Container(
                                                                    width: 13,
                                                                    height: 40,
                                                                    child: Image.asset(
                                                                      "assets/images/group-71.png",
                                                                      fit: BoxFit.none,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                          Positioned(
                                                            left: 10,
                                                            top: 18,
                                                            right: 6,
                                                            child: Image.asset(
                                                              "assets/images/burger.png",
                                                              fit: BoxFit.none,
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    margin: EdgeInsets.only(top: 5),
                                                    child: Text(
                                                      "Fast Food",
                                                      textAlign: TextAlign.center,
                                                      style: TextStyle(
                                                        color: Color.fromARGB(255, 68, 67, 78),
                                                        fontFamily: "Avenir",
                                                        fontWeight: FontWeight.w800,
                                                        fontSize: 12,
                                                        height: 1,
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Container(
                                        height: 61,
                                        child: Opacity(
                                          opacity: 0.5006,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.stretch,
                                            children: [
                                              Container(
                                                height: 41,
                                                margin: EdgeInsets.symmetric(horizontal: 15),
                                                child: Image.asset(
                                                  "assets/images/layer-03x.png",
                                                  fit: BoxFit.none,
                                                ),
                                              ),
                                              Spacer(),
                                              Container(
                                                margin: EdgeInsets.symmetric(horizontal: 26),
                                                child: Text(
                                                  "Dinner",
                                                  textAlign: TextAlign.center,
                                                  style: TextStyle(
                                                    color: Color.fromARGB(255, 68, 67, 78),
                                                    fontFamily: "Avenir",
                                                    fontWeight: FontWeight.w800,
                                                    fontSize: 12,
                                                    height: 1,
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                      Container(
                                        height: 60,
                                        margin: EdgeInsets.only(top: 30),
                                        child: Opacity(
                                          opacity: 0.5006,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.stretch,
                                            children: [
                                              Align(
                                                alignment: Alignment.topCenter,
                                                child: Container(
                                                  width: 40,
                                                  height: 40,
                                                  child: Image.asset(
                                                    "assets/images/layer-0.png",
                                                    fit: BoxFit.none,
                                                  ),
                                                ),
                                              ),
                                              Spacer(),
                                              Container(
                                                margin: EdgeInsets.symmetric(horizontal: 18),
                                                child: Text(
                                                  "Breakfast",
                                                  textAlign: TextAlign.center,
                                                  style: TextStyle(
                                                    color: Color.fromARGB(255, 68, 67, 78),
                                                    fontFamily: "Avenir",
                                                    fontWeight: FontWeight.w800,
                                                    fontSize: 12,
                                                    height: 1,
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                      Container(
                                        height: 60,
                                        margin: EdgeInsets.only(top: 30),
                                        child: Opacity(
                                          opacity: 0.5006,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.stretch,
                                            children: [
                                              Align(
                                                alignment: Alignment.topCenter,
                                                child: Container(
                                                  width: 40,
                                                  height: 40,
                                                  child: Stack(
                                                    alignment: Alignment.center,
                                                    children: [
                                                      Positioned(
                                                        left: 0,
                                                        right: 0,
                                                        child: Stack(
                                                          alignment: Alignment.center,
                                                          children: [
                                                            Positioned(
                                                              left: 1,
                                                              right: 0,
                                                              child: Image.asset(
                                                                "assets/images/path-24.png",
                                                                fit: BoxFit.none,
                                                              ),
                                                            ),
                                                            Positioned(
                                                              left: 0,
                                                              right: 1,
                                                              child: Image.asset(
                                                                "assets/images/group-66.png",
                                                                fit: BoxFit.none,
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                      Positioned(
                                                        left: 4,
                                                        right: 4,
                                                        child: Image.asset(
                                                          "assets/images/group-75.png",
                                                          fit: BoxFit.none,
                                                        ),
                                                      ),
                                                      Positioned(
                                                        left: 15,
                                                        right: 20,
                                                        bottom: 4,
                                                        child: Image.asset(
                                                          "assets/images/group-83.png",
                                                          fit: BoxFit.none,
                                                        ),
                                                      ),
                                                      Positioned(
                                                        left: 19,
                                                        right: 17,
                                                        bottom: 5,
                                                        child: Image.asset(
                                                          "assets/images/group-26.png",
                                                          fit: BoxFit.none,
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Spacer(),
                                              Container(
                                                margin: EdgeInsets.symmetric(horizontal: 28),
                                                child: Text(
                                                  "Lunch",
                                                  textAlign: TextAlign.center,
                                                  style: TextStyle(
                                                    color: Color.fromARGB(255, 68, 67, 78),
                                                    fontFamily: "Avenir",
                                                    fontWeight: FontWeight.w800,
                                                    fontSize: 12,
                                                    height: 1,
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                      Container(
                                        height: 61,
                                        margin: EdgeInsets.only(top: 30),
                                        child: Opacity(
                                          opacity: 0.5006,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.stretch,
                                            children: [
                                              Container(
                                                height: 41,
                                                margin: EdgeInsets.only(left: 18, right: 17),
                                                child: Stack(
                                                  alignment: Alignment.center,
                                                  children: [
                                                    Positioned(
                                                      left: 0,
                                                      top: 0,
                                                      right: 0,
                                                      bottom: 0,
                                                      child: Stack(
                                                        alignment: Alignment.center,
                                                        children: [
                                                          Positioned(
                                                            left: 0,
                                                            top: 5,
                                                            right: 0,
                                                            bottom: 0,
                                                            child: Column(
                                                              crossAxisAlignment: CrossAxisAlignment.stretch,
                                                              children: [
                                                                Align(
                                                                  alignment: Alignment.topLeft,
                                                                  child: Container(
                                                                    width: 3,
                                                                    height: 2,
                                                                    margin: EdgeInsets.only(left: 9),
                                                                    child: Image.asset(
                                                                      "assets/images/shape-7.png",
                                                                      fit: BoxFit.none,
                                                                    ),
                                                                  ),
                                                                ),
                                                                Container(
                                                                  height: 4,
                                                                  margin: EdgeInsets.only(left: 13, top: 1, right: 12),
                                                                  child: Row(
                                                                    crossAxisAlignment: CrossAxisAlignment.stretch,
                                                                    children: [
                                                                      Align(
                                                                        alignment: Alignment.topLeft,
                                                                        child: Container(
                                                                          width: 4,
                                                                          height: 4,
                                                                          child: Image.asset(
                                                                            "assets/images/group-39.png",
                                                                            fit: BoxFit.none,
                                                                          ),
                                                                        ),
                                                                      ),
                                                                      Spacer(),
                                                                      Align(
                                                                        alignment: Alignment.topLeft,
                                                                        child: Container(
                                                                          width: 4,
                                                                          height: 4,
                                                                          child: Image.asset(
                                                                            "assets/images/group-68.png",
                                                                            fit: BoxFit.none,
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ),
                                                                Align(
                                                                  alignment: Alignment.topLeft,
                                                                  child: Container(
                                                                    width: 3,
                                                                    height: 3,
                                                                    margin: EdgeInsets.only(left: 13),
                                                                    child: Image.asset(
                                                                      "assets/images/shape-2.png",
                                                                      fit: BoxFit.none,
                                                                    ),
                                                                  ),
                                                                ),
                                                                Container(
                                                                  height: 11,
                                                                  margin: EdgeInsets.only(left: 10, top: 3, right: 13),
                                                                  child: Image.asset(
                                                                    "assets/images/path-13.png",
                                                                    fit: BoxFit.none,
                                                                  ),
                                                                ),
                                                                Spacer(),
                                                                Container(
                                                                  height: 8,
                                                                  child: Opacity(
                                                                    opacity: 0.5,
                                                                    child: Image.asset(
                                                                      "assets/images/path-38.png",
                                                                      fit: BoxFit.none,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                          Positioned(
                                                            left: 0,
                                                            right: 1,
                                                            bottom: 1,
                                                            child: Row(
                                                              crossAxisAlignment: CrossAxisAlignment.stretch,
                                                              children: [
                                                                Align(
                                                                  alignment: Alignment.bottomLeft,
                                                                  child: Container(
                                                                    width: 21,
                                                                    height: 8,
                                                                    child: Image.asset(
                                                                      "assets/images/path-27.png",
                                                                      fit: BoxFit.none,
                                                                    ),
                                                                  ),
                                                                ),
                                                                Spacer(),
                                                                Align(
                                                                  alignment: Alignment.bottomLeft,
                                                                  child: Container(
                                                                    width: 21,
                                                                    height: 8,
                                                                    child: Image.asset(
                                                                      "assets/images/path-28.png",
                                                                      fit: BoxFit.none,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                          Positioned(
                                                            left: 14,
                                                            right: 13,
                                                            bottom: 4,
                                                            child: Row(
                                                              crossAxisAlignment: CrossAxisAlignment.stretch,
                                                              children: [
                                                                Align(
                                                                  alignment: Alignment.bottomLeft,
                                                                  child: Container(
                                                                    width: 7,
                                                                    height: 5,
                                                                    child: Opacity(
                                                                      opacity: 0.6,
                                                                      child: Image.asset(
                                                                        "assets/images/path-14.png",
                                                                        fit: BoxFit.none,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                                Spacer(),
                                                                Align(
                                                                  alignment: Alignment.bottomLeft,
                                                                  child: Container(
                                                                    width: 9,
                                                                    height: 4,
                                                                    child: Opacity(
                                                                      opacity: 0.6,
                                                                      child: Image.asset(
                                                                        "assets/images/path-23.png",
                                                                        fit: BoxFit.none,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                          Positioned(
                                                            top: 16,
                                                            right: 18,
                                                            child: Image.asset(
                                                              "assets/images/shape-3.png",
                                                              fit: BoxFit.none,
                                                            ),
                                                          ),
                                                          Positioned(
                                                            left: 14,
                                                            top: 18,
                                                            child: Image.asset(
                                                              "assets/images/path-35.png",
                                                              fit: BoxFit.none,
                                                            ),
                                                          ),
                                                          Positioned(
                                                            left: 9,
                                                            top: 26,
                                                            right: 12,
                                                            child: Image.asset(
                                                              "assets/images/path-39.png",
                                                              fit: BoxFit.none,
                                                            ),
                                                          ),
                                                          Positioned(
                                                            top: 18,
                                                            right: 17,
                                                            child: Image.asset(
                                                              "assets/images/group-90.png",
                                                              fit: BoxFit.none,
                                                            ),
                                                          ),
                                                          Positioned(
                                                            top: 8,
                                                            right: 13,
                                                            child: Column(
                                                              crossAxisAlignment: CrossAxisAlignment.stretch,
                                                              children: [
                                                                Align(
                                                                  alignment: Alignment.topRight,
                                                                  child: Container(
                                                                    width: 11,
                                                                    height: 11,
                                                                    margin: EdgeInsets.only(right: 7),
                                                                    child: Image.asset(
                                                                      "assets/images/group-42.png",
                                                                      fit: BoxFit.none,
                                                                    ),
                                                                  ),
                                                                ),
                                                                Align(
                                                                  alignment: Alignment.topRight,
                                                                  child: Container(
                                                                    width: 10,
                                                                    height: 11,
                                                                    margin: EdgeInsets.only(top: 2),
                                                                    child: Image.asset(
                                                                      "assets/images/group-87.png",
                                                                      fit: BoxFit.none,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                          Positioned(
                                                            top: 22,
                                                            right: 21,
                                                            child: Image.asset(
                                                              "assets/images/group-64.png",
                                                              fit: BoxFit.none,
                                                            ),
                                                          ),
                                                          Positioned(
                                                            left: 4,
                                                            top: 4,
                                                            right: 18,
                                                            child: Row(
                                                              crossAxisAlignment: CrossAxisAlignment.stretch,
                                                              children: [
                                                                Align(
                                                                  alignment: Alignment.topLeft,
                                                                  child: Container(
                                                                    width: 21,
                                                                    height: 22,
                                                                    child: Stack(
                                                                      alignment: Alignment.center,
                                                                      children: [
                                                                        Positioned(
                                                                          left: 0,
                                                                          right: 2,
                                                                          child: Image.asset(
                                                                            "assets/images/path-17.png",
                                                                            fit: BoxFit.none,
                                                                          ),
                                                                        ),
                                                                        Positioned(
                                                                          left: 0,
                                                                          right: 1,
                                                                          child: Image.asset(
                                                                            "assets/images/group-23.png",
                                                                            fit: BoxFit.none,
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                ),
                                                                Spacer(),
                                                                Align(
                                                                  alignment: Alignment.topLeft,
                                                                  child: Container(
                                                                    width: 3,
                                                                    height: 2,
                                                                    margin: EdgeInsets.only(top: 7),
                                                                    child: Image.asset(
                                                                      "assets/images/group-51.png",
                                                                      fit: BoxFit.none,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                          Positioned(
                                                            left: 18,
                                                            top: 11,
                                                            child: Column(
                                                              crossAxisAlignment: CrossAxisAlignment.stretch,
                                                              children: [
                                                                Align(
                                                                  alignment: Alignment.topLeft,
                                                                  child: Container(
                                                                    width: 5,
                                                                    height: 4,
                                                                    child: Image.asset(
                                                                      "assets/images/group-38.png",
                                                                      fit: BoxFit.none,
                                                                    ),
                                                                  ),
                                                                ),
                                                                Align(
                                                                  alignment: Alignment.topLeft,
                                                                  child: Container(
                                                                    width: 6,
                                                                    height: 5,
                                                                    margin: EdgeInsets.only(left: 3, top: 6),
                                                                    child: Image.asset(
                                                                      "assets/images/group-63.png",
                                                                      fit: BoxFit.none,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                          Positioned(
                                                            left: 8,
                                                            top: 13,
                                                            right: 13,
                                                            child: Column(
                                                              crossAxisAlignment: CrossAxisAlignment.stretch,
                                                              children: [
                                                                Align(
                                                                  alignment: Alignment.topLeft,
                                                                  child: Container(
                                                                    width: 2,
                                                                    height: 3,
                                                                    child: Image.asset(
                                                                      "assets/images/group-43.png",
                                                                      fit: BoxFit.none,
                                                                    ),
                                                                  ),
                                                                ),
                                                                Container(
                                                                  height: 20,
                                                                  margin: EdgeInsets.only(left: 2, top: 2),
                                                                  child: Image.asset(
                                                                    "assets/images/group-14.png",
                                                                    fit: BoxFit.none,
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                          Positioned(
                                                            left: 15,
                                                            top: 0,
                                                            right: 1,
                                                            bottom: 5,
                                                            child: Column(
                                                              crossAxisAlignment: CrossAxisAlignment.stretch,
                                                              children: [
                                                                Container(
                                                                  height: 9,
                                                                  margin: EdgeInsets.only(left: 3, right: 18),
                                                                  child: Row(
                                                                    crossAxisAlignment: CrossAxisAlignment.stretch,
                                                                    children: [
                                                                      Align(
                                                                        alignment: Alignment.topLeft,
                                                                        child: Container(
                                                                          width: 8,
                                                                          height: 7,
                                                                          child: Image.asset(
                                                                            "assets/images/group-34.png",
                                                                            fit: BoxFit.none,
                                                                          ),
                                                                        ),
                                                                      ),
                                                                      Spacer(),
                                                                      Align(
                                                                        alignment: Alignment.topLeft,
                                                                        child: Container(
                                                                          width: 5,
                                                                          height: 5,
                                                                          margin: EdgeInsets.only(top: 4),
                                                                          child: Image.asset(
                                                                            "assets/images/group-85.png",
                                                                            fit: BoxFit.none,
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ),
                                                                Align(
                                                                  alignment: Alignment.topRight,
                                                                  child: Container(
                                                                    width: 28,
                                                                    height: 7,
                                                                    margin: EdgeInsets.only(top: 2),
                                                                    child: Image.asset(
                                                                      "assets/images/group-72.png",
                                                                      fit: BoxFit.none,
                                                                    ),
                                                                  ),
                                                                ),
                                                                Spacer(),
                                                                Container(
                                                                  height: 4,
                                                                  margin: EdgeInsets.only(right: 18),
                                                                  child: Opacity(
                                                                    opacity: 0.4,
                                                                    child: Image.asset(
                                                                      "assets/images/path-26.png",
                                                                      fit: BoxFit.none,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                          Positioned(
                                                            left: 8,
                                                            top: 25,
                                                            right: 12,
                                                            child: Image.asset(
                                                              "assets/images/group-30.png",
                                                              fit: BoxFit.none,
                                                            ),
                                                          ),
                                                          Positioned(
                                                            left: 7,
                                                            top: 2,
                                                            right: 5,
                                                            bottom: 1,
                                                            child: Column(
                                                              crossAxisAlignment: CrossAxisAlignment.stretch,
                                                              children: [
                                                                Container(
                                                                  height: 23,
                                                                  child: Image.asset(
                                                                    "assets/images/group-4.png",
                                                                    fit: BoxFit.none,
                                                                  ),
                                                                ),
                                                                Spacer(),
                                                                Align(
                                                                  alignment: Alignment.topRight,
                                                                  child: Container(
                                                                    width: 14,
                                                                    height: 11,
                                                                    child: Image.asset(
                                                                      "assets/images/group-35.png",
                                                                      fit: BoxFit.none,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                          Positioned(
                                                            left: 2,
                                                            top: 20,
                                                            child: Image.asset(
                                                              "assets/images/group-21.png",
                                                              fit: BoxFit.none,
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    Positioned(
                                                      left: 11,
                                                      right: 17,
                                                      child: Column(
                                                        crossAxisAlignment: CrossAxisAlignment.stretch,
                                                        children: [
                                                          Align(
                                                            alignment: Alignment.topLeft,
                                                            child: Container(
                                                              width: 5,
                                                              height: 1,
                                                              child: Image.asset(
                                                                "assets/images/path-8.png",
                                                                fit: BoxFit.none,
                                                              ),
                                                            ),
                                                          ),
                                                          Align(
                                                            alignment: Alignment.topRight,
                                                            child: Container(
                                                              width: 2,
                                                              height: 3,
                                                              child: Image.asset(
                                                                "assets/images/shape-13.png",
                                                                fit: BoxFit.none,
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    Positioned(
                                                      left: 15,
                                                      child: Image.asset(
                                                        "assets/images/path-34.png",
                                                        fit: BoxFit.none,
                                                      ),
                                                    ),
                                                    Positioned(
                                                      child: Image.asset(
                                                        "assets/images/shape-5.png",
                                                        fit: BoxFit.none,
                                                      ),
                                                    ),
                                                    Positioned(
                                                      left: 10,
                                                      child: Row(
                                                        crossAxisAlignment: CrossAxisAlignment.stretch,
                                                        children: [
                                                          Align(
                                                            alignment: Alignment.centerLeft,
                                                            child: Container(
                                                              width: 13,
                                                              height: 11,
                                                              child: Image.asset(
                                                                "assets/images/group-41.png",
                                                                fit: BoxFit.none,
                                                              ),
                                                            ),
                                                          ),
                                                          Align(
                                                            alignment: Alignment.centerLeft,
                                                            child: Container(
                                                              width: 4,
                                                              height: 4,
                                                              child: Image.asset(
                                                                "assets/images/group-46.png",
                                                                fit: BoxFit.none,
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    Positioned(
                                                      left: 15,
                                                      child: Image.asset(
                                                        "assets/images/shape-11.png",
                                                        fit: BoxFit.none,
                                                      ),
                                                    ),
                                                    Positioned(
                                                      left: 12,
                                                      child: Image.asset(
                                                        "assets/images/group-78.png",
                                                        fit: BoxFit.none,
                                                      ),
                                                    ),
                                                    Positioned(
                                                      left: 10,
                                                      right: 13,
                                                      child: Image.asset(
                                                        "assets/images/path-4.png",
                                                        fit: BoxFit.none,
                                                      ),
                                                    ),
                                                    Positioned(
                                                      left: 15,
                                                      top: 5,
                                                      right: 14,
                                                      child: Column(
                                                        crossAxisAlignment: CrossAxisAlignment.stretch,
                                                        children: [
                                                          Align(
                                                            alignment: Alignment.topCenter,
                                                            child: Container(
                                                              width: 2,
                                                              height: 3,
                                                              child: Image.asset(
                                                                "assets/images/shape-4.png",
                                                                fit: BoxFit.none,
                                                              ),
                                                            ),
                                                          ),
                                                          Align(
                                                            alignment: Alignment.topLeft,
                                                            child: Container(
                                                              width: 7,
                                                              height: 1,
                                                              child: Image.asset(
                                                                "assets/images/path-31.png",
                                                                fit: BoxFit.none,
                                                              ),
                                                            ),
                                                          ),
                                                          Align(
                                                            alignment: Alignment.topRight,
                                                            child: Container(
                                                              width: 20,
                                                              height: 5,
                                                              child: Image.asset(
                                                                "assets/images/path-3.png",
                                                                fit: BoxFit.none,
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Spacer(),
                                              Container(
                                                margin: EdgeInsets.symmetric(horizontal: 29),
                                                child: Text(
                                                  "Salad",
                                                  textAlign: TextAlign.center,
                                                  style: TextStyle(
                                                    color: Color.fromARGB(255, 68, 67, 78),
                                                    fontFamily: "Avenir",
                                                    fontWeight: FontWeight.w800,
                                                    fontSize: 12,
                                                    height: 1,
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                      Container(
                                        height: 59,
                                        margin: EdgeInsets.only(top: 30),
                                        child: Opacity(
                                          opacity: 0.5006,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.stretch,
                                            children: [
                                              Align(
                                                alignment: Alignment.topCenter,
                                                child: Container(
                                                  width: 40,
                                                  height: 39,
                                                  child: Stack(
                                                    alignment: Alignment.bottomCenter,
                                                    children: [
                                                      Positioned(
                                                        left: 0,
                                                        right: 0,
                                                        bottom: 0,
                                                        child: Row(
                                                          crossAxisAlignment: CrossAxisAlignment.stretch,
                                                          children: [
                                                            Align(
                                                              alignment: Alignment.bottomLeft,
                                                              child: Container(
                                                                width: 19,
                                                                height: 19,
                                                                child: Image.asset(
                                                                  "assets/images/group-82.png",
                                                                  fit: BoxFit.none,
                                                                ),
                                                              ),
                                                            ),
                                                            Spacer(),
                                                            Align(
                                                              alignment: Alignment.bottomLeft,
                                                              child: Container(
                                                                width: 18,
                                                                height: 19,
                                                                child: Image.asset(
                                                                  "assets/images/group-76.png",
                                                                  fit: BoxFit.none,
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                      Positioned(
                                                        left: 11,
                                                        top: 0,
                                                        right: 9,
                                                        child: Image.asset(
                                                          "assets/images/group-37.png",
                                                          fit: BoxFit.none,
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Spacer(),
                                              Container(
                                                margin: EdgeInsets.symmetric(horizontal: 22),
                                                child: Text(
                                                  "Cookies",
                                                  textAlign: TextAlign.center,
                                                  style: TextStyle(
                                                    color: Color.fromARGB(255, 68, 67, 78),
                                                    fontFamily: "Avenir",
                                                    fontWeight: FontWeight.w800,
                                                    fontSize: 12,
                                                    height: 1,
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                      Spacer(),
                                      Container(
                                        height: 60,
                                        child: Opacity(
                                          opacity: 0.5006,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.stretch,
                                            children: [
                                              Align(
                                                alignment: Alignment.topCenter,
                                                child: Container(
                                                  width: 40,
                                                  height: 41,
                                                  child: Row(
                                                    children: [
                                                      Container(
                                                        width: 18,
                                                        height: 40,
                                                        child: Image.asset(
                                                          "assets/images/group-77.png",
                                                          fit: BoxFit.none,
                                                        ),
                                                      ),
                                                      Spacer(),
                                                      Container(
                                                        width: 18,
                                                        height: 40,
                                                        child: Stack(
                                                          alignment: Alignment.center,
                                                          children: [
                                                            Positioned(
                                                              left: 0,
                                                              right: 0,
                                                              child: Stack(
                                                                alignment: Alignment.topCenter,
                                                                children: [
                                                                  Positioned(
                                                                    left: 1,
                                                                    top: 14,
                                                                    right: 0,
                                                                    child: Image.asset(
                                                                      "assets/images/group-19.png",
                                                                      fit: BoxFit.none,
                                                                    ),
                                                                  ),
                                                                  Positioned(
                                                                    left: 3,
                                                                    top: 14,
                                                                    right: 1,
                                                                    child: Image.asset(
                                                                      "assets/images/path-5.png",
                                                                      fit: BoxFit.none,
                                                                    ),
                                                                  ),
                                                                  Positioned(
                                                                    left: 0,
                                                                    top: 14,
                                                                    right: 0,
                                                                    child: Column(
                                                                      crossAxisAlignment: CrossAxisAlignment.stretch,
                                                                      children: [
                                                                        Container(
                                                                          height: 5,
                                                                          child: Image.asset(
                                                                            "assets/images/group-65.png",
                                                                            fit: BoxFit.none,
                                                                          ),
                                                                        ),
                                                                        Container(
                                                                          height: 12,
                                                                          margin: EdgeInsets.only(left: 2, right: 14),
                                                                          child: Opacity(
                                                                            opacity: 0.6,
                                                                            child: Stack(
                                                                              alignment: Alignment.center,
                                                                              children: [
                                                                                Positioned(
                                                                                  left: 0,
                                                                                  right: 0,
                                                                                  child: Image.asset(
                                                                                    "assets/images/group-36.png",
                                                                                    fit: BoxFit.none,
                                                                                  ),
                                                                                ),
                                                                                Positioned(
                                                                                  left: 1,
                                                                                  right: 0,
                                                                                  bottom: 0,
                                                                                  child: Image.asset(
                                                                                    "assets/images/group-86.png",
                                                                                    fit: BoxFit.none,
                                                                                  ),
                                                                                ),
                                                                              ],
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                  Positioned(
                                                                    left: 0,
                                                                    top: 12,
                                                                    right: 0,
                                                                    child: Image.asset(
                                                                      "assets/images/group-55.png",
                                                                      fit: BoxFit.none,
                                                                    ),
                                                                  ),
                                                                  Positioned(
                                                                    left: 2,
                                                                    top: 13,
                                                                    right: 1,
                                                                    child: Image.asset(
                                                                      "assets/images/group-9.png",
                                                                      fit: BoxFit.none,
                                                                    ),
                                                                  ),
                                                                  Positioned(
                                                                    left: 0,
                                                                    top: 0,
                                                                    right: 7,
                                                                    child: Stack(
                                                                      alignment: Alignment.center,
                                                                      children: [
                                                                        Positioned(
                                                                          left: 0,
                                                                          right: 1,
                                                                          child: Image.asset(
                                                                            "assets/images/group-10.png",
                                                                            fit: BoxFit.none,
                                                                          ),
                                                                        ),
                                                                        Positioned(
                                                                          left: 4,
                                                                          right: 0,
                                                                          child: Stack(
                                                                            alignment: Alignment.center,
                                                                            children: [
                                                                              Positioned(
                                                                                left: 3,
                                                                                right: 1,
                                                                                bottom: 0,
                                                                                child: Image.asset(
                                                                                  "assets/images/group-22.png",
                                                                                  fit: BoxFit.none,
                                                                                ),
                                                                              ),
                                                                              Positioned(
                                                                                left: 3,
                                                                                right: 1,
                                                                                child: Image.asset(
                                                                                  "assets/images/group-45.png",
                                                                                  fit: BoxFit.none,
                                                                                ),
                                                                              ),
                                                                              Positioned(
                                                                                left: 0,
                                                                                top: 0,
                                                                                right: 3,
                                                                                child: Image.asset(
                                                                                  "assets/images/group-62.png",
                                                                                  fit: BoxFit.none,
                                                                                ),
                                                                              ),
                                                                            ],
                                                                          ),
                                                                        ),
                                                                        Positioned(
                                                                          left: 1,
                                                                          right: 3,
                                                                          child: Image.asset(
                                                                            "assets/images/path.png",
                                                                            fit: BoxFit.none,
                                                                          ),
                                                                        ),
                                                                        Positioned(
                                                                          left: 0,
                                                                          top: 0,
                                                                          right: 9,
                                                                          child: Image.asset(
                                                                            "assets/images/group-80.png",
                                                                            fit: BoxFit.none,
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                  Positioned(
                                                                    left: 1,
                                                                    top: 7,
                                                                    right: 1,
                                                                    child: Image.asset(
                                                                      "assets/images/shape-16.png",
                                                                      fit: BoxFit.none,
                                                                    ),
                                                                  ),
                                                                  Positioned(
                                                                    left: 2,
                                                                    top: 7,
                                                                    right: 1,
                                                                    child: Opacity(
                                                                      opacity: 0.9,
                                                                      child: Image.asset(
                                                                        "assets/images/group-11.png",
                                                                        fit: BoxFit.none,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                            Positioned(
                                                              left: 5,
                                                              top: 25,
                                                              right: 4,
                                                              child: Stack(
                                                                alignment: Alignment.center,
                                                                children: [
                                                                  Positioned(
                                                                    left: 0,
                                                                    right: 0,
                                                                    child: Row(
                                                                      children: [
                                                                        Expanded(
                                                                          flex: 1,
                                                                          child: Container(
                                                                            height: 3,
                                                                            margin: EdgeInsets.only(right: 2),
                                                                            child: Image.asset(
                                                                              "assets/images/group-40.png",
                                                                              fit: BoxFit.none,
                                                                            ),
                                                                          ),
                                                                        ),
                                                                        Expanded(
                                                                          flex: 1,
                                                                          child: Container(
                                                                            height: 3,
                                                                            margin: EdgeInsets.only(left: 2, right: 1),
                                                                            child: Image.asset(
                                                                              "assets/images/group-40.png",
                                                                              fit: BoxFit.none,
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                  Positioned(
                                                                    left: -1,
                                                                    right: 1,
                                                                    child: Image.asset(
                                                                      "assets/images/group-67.png",
                                                                      fit: BoxFit.none,
                                                                    ),
                                                                  ),
                                                                  Positioned(
                                                                    left: 2,
                                                                    right: 3,
                                                                    child: Image.asset(
                                                                      "assets/images/group-58.png",
                                                                      fit: BoxFit.none,
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Spacer(),
                                              Container(
                                                margin: EdgeInsets.symmetric(horizontal: 27),
                                                child: Text(
                                                  "Drinks",
                                                  textAlign: TextAlign.center,
                                                  style: TextStyle(
                                                    color: Color.fromARGB(255, 68, 67, 78),
                                                    fontFamily: "Avenir",
                                                    fontWeight: FontWeight.w800,
                                                    fontSize: 12,
                                                    height: 1,
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Spacer(),
                        Align(
                          alignment: Alignment.topLeft,
                          child: Container(
                            width: 256,
                            height: 740,
                            margin: EdgeInsets.only(top: 1),
                            child: Stack(
                              alignment: Alignment.center,
                              children: [
                                Positioned(
                                  left: 0,
                                  top: 0,
                                  right: 0,
                                  bottom: 0,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.stretch,
                                    children: [
                                      Container(
                                        height: 136,
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.stretch,
                                          children: [
                                            Align(
                                              alignment: Alignment.topLeft,
                                              child: Container(
                                                width: 122,
                                                height: 136,
                                                decoration: BoxDecoration(
                                                  color: AppColors.primaryBackground,
                                                  border: Border.all(
                                                    width: 1,
                                                    color: Color.fromARGB(255, 247, 248, 249),
                                                  ),
                                                  borderRadius: BorderRadius.all(Radius.circular(14)),
                                                ),
                                                child: Column(
                                                  crossAxisAlignment: CrossAxisAlignment.stretch,
                                                  children: [
                                                    Container(
                                                      height: 86,
                                                      margin: EdgeInsets.only(left: 11, top: 10, right: 11),
                                                      child: Image.asset(
                                                        "assets/images/burger-10917-3.png",
                                                        fit: BoxFit.none,
                                                      ),
                                                    ),
                                                    Spacer(),
                                                    Align(
                                                      alignment: Alignment.topCenter,
                                                      child: Container(
                                                        margin: EdgeInsets.only(bottom: 12),
                                                        child: Text(
                                                          "Burger",
                                                          textAlign: TextAlign.center,
                                                          style: TextStyle(
                                                            color: AppColors.primaryText,
                                                            fontFamily: "Avenir",
                                                            fontWeight: FontWeight.w800,
                                                            fontSize: 14,
                                                            height: 1,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                            Spacer(),
                                            Align(
                                              alignment: Alignment.topLeft,
                                              child: Container(
                                                width: 122,
                                                height: 136,
                                                decoration: BoxDecoration(
                                                  color: AppColors.primaryBackground,
                                                  border: Border.all(
                                                    width: 1,
                                                    color: Color.fromARGB(255, 247, 248, 249),
                                                  ),
                                                  borderRadius: BorderRadius.all(Radius.circular(14)),
                                                ),
                                                child: Column(
                                                  crossAxisAlignment: CrossAxisAlignment.stretch,
                                                  children: [
                                                    Container(
                                                      height: 61,
                                                      margin: EdgeInsets.only(left: 11, top: 20, right: 11),
                                                      child: Image.asset(
                                                        "assets/images/kisspng-cheese-sandwich-chicken-sandwich-vegetable-sandwic-sandwich-5abb4c17f38bd62105519915222241519976.png",
                                                        fit: BoxFit.none,
                                                      ),
                                                    ),
                                                    Spacer(),
                                                    Align(
                                                      alignment: Alignment.topCenter,
                                                      child: Container(
                                                        margin: EdgeInsets.only(bottom: 12),
                                                        child: Text(
                                                          "Sandwitch",
                                                          textAlign: TextAlign.center,
                                                          style: TextStyle(
                                                            color: AppColors.primaryText,
                                                            fontFamily: "Avenir",
                                                            fontWeight: FontWeight.w800,
                                                            fontSize: 14,
                                                            height: 1,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Container(
                                        height: 136,
                                        margin: EdgeInsets.only(top: 15),
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.stretch,
                                          children: [
                                            Align(
                                              alignment: Alignment.topLeft,
                                              child: Container(
                                                width: 122,
                                                height: 136,
                                                decoration: BoxDecoration(
                                                  color: AppColors.primaryBackground,
                                                  border: Border.all(
                                                    width: 1,
                                                    color: Color.fromARGB(255, 247, 248, 249),
                                                  ),
                                                  borderRadius: BorderRadius.all(Radius.circular(14)),
                                                ),
                                                child: Column(
                                                  crossAxisAlignment: CrossAxisAlignment.stretch,
                                                  children: [
                                                    Container(
                                                      height: 68,
                                                      margin: EdgeInsets.only(left: 17, top: 15, right: 16),
                                                      child: Image.asset(
                                                        "assets/images/kisspng-maggi-instant-noodle-fast-food-chinese-cuisine-chi-5afa4e07697d562341149515263534154321.png",
                                                        fit: BoxFit.none,
                                                      ),
                                                    ),
                                                    Spacer(),
                                                    Align(
                                                      alignment: Alignment.topCenter,
                                                      child: Container(
                                                        margin: EdgeInsets.only(bottom: 12),
                                                        child: Text(
                                                          "Noodles",
                                                          textAlign: TextAlign.center,
                                                          style: TextStyle(
                                                            color: AppColors.primaryText,
                                                            fontFamily: "Avenir",
                                                            fontWeight: FontWeight.w800,
                                                            fontSize: 14,
                                                            height: 1,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                            Spacer(),
                                            Align(
                                              alignment: Alignment.topLeft,
                                              child: Container(
                                                width: 122,
                                                height: 136,
                                                decoration: BoxDecoration(
                                                  color: AppColors.primaryBackground,
                                                  border: Border.all(
                                                    width: 1,
                                                    color: Color.fromARGB(255, 247, 248, 249),
                                                  ),
                                                  borderRadius: BorderRadius.all(Radius.circular(14)),
                                                ),
                                                child: Column(
                                                  children: [
                                                    Container(
                                                      width: 74,
                                                      height: 66,
                                                      margin: EdgeInsets.only(top: 20),
                                                      child: Image.asset(
                                                        "assets/images/20-pizza-png-image-3.png",
                                                        fit: BoxFit.none,
                                                      ),
                                                    ),
                                                    Spacer(),
                                                    Container(
                                                      margin: EdgeInsets.only(bottom: 12),
                                                      child: Text(
                                                        "Pizza",
                                                        textAlign: TextAlign.center,
                                                        style: TextStyle(
                                                          color: AppColors.primaryText,
                                                          fontFamily: "Avenir",
                                                          fontWeight: FontWeight.w800,
                                                          fontSize: 14,
                                                          height: 1,
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Container(
                                        height: 136,
                                        margin: EdgeInsets.only(top: 166),
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.stretch,
                                          children: [
                                            Align(
                                              alignment: Alignment.topLeft,
                                              child: Container(
                                                width: 122,
                                                height: 136,
                                                decoration: BoxDecoration(
                                                  border: Border.all(
                                                    width: 1,
                                                    color: Color.fromARGB(255, 247, 248, 249),
                                                  ),
                                                  borderRadius: BorderRadius.all(Radius.circular(14)),
                                                ),
                                                child: Column(
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      width: 82,
                                                      height: 60,
                                                      margin: EdgeInsets.only(left: 20, top: 24),
                                                      child: Image.asset(
                                                        "assets/images/kisspng-fast-food-french-fries-onion-ring-kfc-chicken-nugg-bucket-5ab593036d0f642743732615218490914467.png",
                                                        fit: BoxFit.none,
                                                      ),
                                                    ),
                                                    Spacer(),
                                                    Align(
                                                      alignment: Alignment.topCenter,
                                                      child: Container(
                                                        margin: EdgeInsets.only(bottom: 12),
                                                        child: Text(
                                                          "Nuggets",
                                                          textAlign: TextAlign.center,
                                                          style: TextStyle(
                                                            color: AppColors.primaryText,
                                                            fontFamily: "Avenir",
                                                            fontWeight: FontWeight.w800,
                                                            fontSize: 14,
                                                            height: 1,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                            Spacer(),
                                            Align(
                                              alignment: Alignment.topLeft,
                                              child: Container(
                                                width: 122,
                                                height: 136,
                                                decoration: BoxDecoration(
                                                  border: Border.all(
                                                    width: 1,
                                                    color: Color.fromARGB(255, 247, 248, 249),
                                                  ),
                                                  borderRadius: BorderRadius.all(Radius.circular(14)),
                                                ),
                                                child: Column(
                                                  children: [
                                                    Container(
                                                      width: 72,
                                                      height: 75,
                                                      margin: EdgeInsets.only(top: 18),
                                                      child: Stack(
                                                        alignment: Alignment.center,
                                                        children: [
                                                          Positioned(
                                                            top: 3,
                                                            child: Container(
                                                              width: 72,
                                                              height: 72,
                                                              decoration: BoxDecoration(
                                                                color: Color.fromARGB(255, 64, 43, 66),
                                                                borderRadius: BorderRadius.all(Radius.circular(36)),
                                                              ),
                                                              child: Container(),
                                                            ),
                                                          ),
                                                          Positioned(
                                                            top: 0,
                                                            child: Image.asset(
                                                              "assets/images/kisspng-fish-and-chips-french-fries-fast-food-chicken-fing-french-fries-5abd82863a10582996228815223691582378.png",
                                                              fit: BoxFit.none,
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    Spacer(),
                                                    Container(
                                                      margin: EdgeInsets.only(bottom: 12),
                                                      child: Text(
                                                        "Chips",
                                                        textAlign: TextAlign.center,
                                                        style: TextStyle(
                                                          color: AppColors.primaryText,
                                                          fontFamily: "Avenir",
                                                          fontWeight: FontWeight.w800,
                                                          fontSize: 14,
                                                          height: 1,
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Spacer(),
                                      Container(
                                        height: 136,
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.stretch,
                                          children: [
                                            Align(
                                              alignment: Alignment.bottomLeft,
                                              child: Container(
                                                width: 122,
                                                height: 136,
                                                decoration: BoxDecoration(
                                                  color: AppColors.primaryBackground,
                                                  border: Border.all(
                                                    width: 1,
                                                    color: Color.fromARGB(255, 247, 248, 249),
                                                  ),
                                                  borderRadius: BorderRadius.all(Radius.circular(14)),
                                                ),
                                                child: Column(
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      width: 82,
                                                      height: 60,
                                                      margin: EdgeInsets.only(left: 20, top: 24),
                                                      child: Image.asset(
                                                        "assets/images/kisspng-fast-food-french-fries-onion-ring-kfc-chicken-nugg-bucket-5ab593036d0f642743732615218490914467.png",
                                                        fit: BoxFit.none,
                                                      ),
                                                    ),
                                                    Spacer(),
                                                    Align(
                                                      alignment: Alignment.topCenter,
                                                      child: Container(
                                                        margin: EdgeInsets.only(bottom: 12),
                                                        child: Text(
                                                          "Nuggets",
                                                          textAlign: TextAlign.center,
                                                          style: TextStyle(
                                                            color: AppColors.primaryText,
                                                            fontFamily: "Avenir",
                                                            fontWeight: FontWeight.w800,
                                                            fontSize: 14,
                                                            height: 1,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                            Spacer(),
                                            Align(
                                              alignment: Alignment.bottomLeft,
                                              child: Container(
                                                width: 122,
                                                height: 136,
                                                decoration: BoxDecoration(
                                                  color: AppColors.primaryBackground,
                                                  border: Border.all(
                                                    width: 1,
                                                    color: Color.fromARGB(255, 247, 248, 249),
                                                  ),
                                                  borderRadius: BorderRadius.all(Radius.circular(14)),
                                                ),
                                                child: Column(
                                                  children: [
                                                    Container(
                                                      width: 72,
                                                      height: 75,
                                                      margin: EdgeInsets.only(top: 18),
                                                      child: Stack(
                                                        alignment: Alignment.center,
                                                        children: [
                                                          Positioned(
                                                            top: 3,
                                                            child: Container(
                                                              width: 72,
                                                              height: 72,
                                                              decoration: BoxDecoration(
                                                                color: Color.fromARGB(255, 64, 43, 66),
                                                                borderRadius: BorderRadius.all(Radius.circular(36)),
                                                              ),
                                                              child: Container(),
                                                            ),
                                                          ),
                                                          Positioned(
                                                            top: 0,
                                                            child: Image.asset(
                                                              "assets/images/kisspng-fish-and-chips-french-fries-fast-food-chicken-fing-french-fries-5abd82863a10582996228815223691582378.png",
                                                              fit: BoxFit.none,
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    Spacer(),
                                                    Container(
                                                      margin: EdgeInsets.only(bottom: 12),
                                                      child: Text(
                                                        "Chips",
                                                        textAlign: TextAlign.center,
                                                        style: TextStyle(
                                                          color: AppColors.primaryText,
                                                          fontFamily: "Avenir",
                                                          fontWeight: FontWeight.w800,
                                                          fontSize: 14,
                                                          height: 1,
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Positioned(
                                  left: 0,
                                  right: 0,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.stretch,
                                    children: [
                                      Align(
                                        alignment: Alignment.centerLeft,
                                        child: Container(
                                          width: 122,
                                          height: 136,
                                          decoration: BoxDecoration(
                                            border: Border.all(
                                              width: 1,
                                              color: Color.fromARGB(255, 247, 248, 249),
                                            ),
                                            borderRadius: BorderRadius.all(Radius.circular(14)),
                                          ),
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.stretch,
                                            children: [
                                              Container(
                                                height: 48,
                                                margin: EdgeInsets.only(left: 11, top: 30, right: 11),
                                                child: Image.asset(
                                                  "assets/images/5a3abbc910ca1588946379151379860106881411-copy.png",
                                                  fit: BoxFit.none,
                                                ),
                                              ),
                                              Spacer(),
                                              Align(
                                                alignment: Alignment.topCenter,
                                                child: Container(
                                                  margin: EdgeInsets.only(bottom: 12),
                                                  child: Text(
                                                    "Hot Dog",
                                                    textAlign: TextAlign.center,
                                                    style: TextStyle(
                                                      color: AppColors.primaryText,
                                                      fontFamily: "Avenir",
                                                      fontWeight: FontWeight.w800,
                                                      fontSize: 14,
                                                      height: 1,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                      Spacer(),
                                      Align(
                                        alignment: Alignment.centerLeft,
                                        child: Container(
                                          width: 122,
                                          height: 136,
                                          decoration: BoxDecoration(
                                            border: Border.all(
                                              width: 1,
                                              color: Color.fromARGB(255, 247, 248, 249),
                                            ),
                                            borderRadius: BorderRadius.all(Radius.circular(14)),
                                          ),
                                          child: Column(
                                            children: [
                                              Container(
                                                width: 74,
                                                height: 70,
                                                margin: EdgeInsets.only(top: 20),
                                                child: Image.asset(
                                                  "assets/images/5a1cd6813b7f971363143115118393612437.png",
                                                  fit: BoxFit.none,
                                                ),
                                              ),
                                              Spacer(),
                                              Container(
                                                margin: EdgeInsets.only(bottom: 12),
                                                child: Text(
                                                  "Donuts",
                                                  textAlign: TextAlign.center,
                                                  style: TextStyle(
                                                    color: AppColors.primaryText,
                                                    fontFamily: "Avenir",
                                                    fontWeight: FontWeight.w800,
                                                    fontSize: 14,
                                                    height: 1,
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              child: Container(
                height: 82,
                decoration: BoxDecoration(
                  color: AppColors.primaryBackground,
                  boxShadow: [
                    BoxShadow(
                      color: Color.fromARGB(27, 137, 168, 203),
                      offset: Offset(0, -1),
                      blurRadius: 3,
                    ),
                  ],
                  borderRadius: BorderRadius.all(Radius.circular(16)),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Container(
                      height: 41,
                      margin: EdgeInsets.only(left: 16, right: 15),
                      child: Row(
                        children: [
                          Container(
                            width: 33,
                            height: 38,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: [
                                Container(
                                  height: 18,
                                  margin: EdgeInsets.only(left: 10, right: 9),
                                  child: FlatButton(
                                    onPressed: () => this.onGroup5Pressed(context),
                                    color: Color.fromARGB(0, 0, 0, 0),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.all(Radius.circular(0)),
                                    ),
                                    textColor: Color.fromARGB(255, 0, 0, 0),
                                    padding: EdgeInsets.all(0),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        Image.asset("assets/images/group-5-3.png",),
                                        SizedBox(
                                          width: 10,
                                        ),
                                        Text(
                                          "",
                                          textAlign: TextAlign.left,
                                          style: TextStyle(
                                            color: Color.fromARGB(255, 0, 0, 0),
                                            fontWeight: FontWeight.w400,
                                            fontSize: 12,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                Spacer(),
                                Text(
                                  "Home",
                                  textAlign: TextAlign.left,
                                  style: TextStyle(
                                    color: AppColors.accentText,
                                    fontFamily: "Avenir",
                                    fontWeight: FontWeight.w400,
                                    fontSize: 12,
                                    height: 1,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            width: 44,
                            height: 39,
                            margin: EdgeInsets.only(left: 32),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: [
                                Container(
                                  height: 19,
                                  margin: EdgeInsets.only(left: 13, right: 12),
                                  child: FlatButton(
                                    onPressed: () => this.onNearbyCopyPressed(context),
                                    color: Color.fromARGB(0, 0, 0, 0),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.all(Radius.circular(0)),
                                    ),
                                    textColor: Color.fromARGB(255, 0, 0, 0),
                                    padding: EdgeInsets.all(0),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        Image.asset("assets/images/005-nearby-copy-2.png",),
                                        SizedBox(
                                          width: 10,
                                        ),
                                        Text(
                                          "",
                                          textAlign: TextAlign.left,
                                          style: TextStyle(
                                            color: Color.fromARGB(255, 0, 0, 0),
                                            fontWeight: FontWeight.w400,
                                            fontSize: 12,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                Spacer(),
                                Text(
                                  "Near By",
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    color: AppColors.accentText,
                                    fontFamily: "Avenir",
                                    fontWeight: FontWeight.w400,
                                    fontSize: 12,
                                    height: 1,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            width: 52,
                            height: 40,
                            margin: EdgeInsets.only(left: 32),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: [
                                Container(
                                  height: 19,
                                  margin: EdgeInsets.only(left: 18, right: 14),
                                  child: Stack(
                                    alignment: Alignment.center,
                                    children: [
                                      Positioned(
                                        top: 2,
                                        right: 0,
                                        child: FlatButton(
                                          onPressed: () => this.onGroup3CopyPressed(context),
                                          color: Color.fromARGB(0, 0, 0, 0),
                                          shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.all(Radius.circular(0)),
                                          ),
                                          textColor: Color.fromARGB(255, 0, 0, 0),
                                          padding: EdgeInsets.all(0),
                                          child: Row(
                                            mainAxisAlignment: MainAxisAlignment.center,
                                            children: [
                                              Image.asset("assets/images/group-3-copy.png",),
                                              SizedBox(
                                                width: 10,
                                              ),
                                              Text(
                                                "",
                                                textAlign: TextAlign.left,
                                                style: TextStyle(
                                                  color: Color.fromARGB(255, 0, 0, 0),
                                                  fontWeight: FontWeight.w400,
                                                  fontSize: 12,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        left: 0,
                                        top: 0,
                                        right: 2,
                                        child: Image.asset(
                                          "assets/images/group-3-2.png",
                                          fit: BoxFit.none,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Spacer(),
                                Text(
                                  "Category",
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    color: AppColors.primaryText,
                                    fontFamily: "Avenir",
                                    fontWeight: FontWeight.w500,
                                    fontSize: 12,
                                    height: 1,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Spacer(),
                          Container(
                            width: 52,
                            height: 40,
                            margin: EdgeInsets.only(right: 32),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: [
                                Container(
                                  height: 18,
                                  margin: EdgeInsets.symmetric(horizontal: 16),
                                  child: Image.asset(
                                    "assets/images/path-16.png",
                                    fit: BoxFit.none,
                                  ),
                                ),
                                Spacer(),
                                Text(
                                  "Favourite",
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    color: AppColors.accentText,
                                    fontFamily: "Avenir",
                                    fontWeight: FontWeight.w400,
                                    fontSize: 12,
                                    height: 1,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            width: 35,
                            height: 41,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: [
                                Container(
                                  height: 18,
                                  margin: EdgeInsets.only(left: 8, right: 9),
                                  child: FlatButton(
                                    onPressed: () => this.onGroup2Pressed(context),
                                    color: Color.fromARGB(0, 0, 0, 0),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.all(Radius.circular(0)),
                                    ),
                                    textColor: Color.fromARGB(255, 0, 0, 0),
                                    padding: EdgeInsets.all(0),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        Image.asset("assets/images/group-2-5.png",),
                                        SizedBox(
                                          width: 10,
                                        ),
                                        Text(
                                          "",
                                          textAlign: TextAlign.left,
                                          style: TextStyle(
                                            color: Color.fromARGB(255, 0, 0, 0),
                                            fontWeight: FontWeight.w400,
                                            fontSize: 12,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                Spacer(),
                                Text(
                                  "Profile",
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    color: AppColors.accentText,
                                    fontFamily: "Avenir",
                                    fontWeight: FontWeight.w400,
                                    fontSize: 12,
                                    height: 1,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}