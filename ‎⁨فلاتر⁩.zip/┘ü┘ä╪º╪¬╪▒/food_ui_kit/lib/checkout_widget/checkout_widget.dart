/*
*  checkout_widget.dart
*  Food UI Kit
*
*  Created by [Author].
*  Copyright © 2018 [Company]. All rights reserved.
    */

import 'package:flutter/material.dart';
import 'package:food_ui_kit/cart_delete_widget/cart_delete_widget.dart';
import 'package:food_ui_kit/values/values.dart';


class CheckoutWidget extends StatelessWidget {
  
  void onSelectedPressed(BuildContext context) {
  
  }
  
  void onButtonPressed(BuildContext context) => Navigator.push(context, MaterialPageRoute(builder: (context) => CartDeleteWidget()));
  
  @override
  Widget build(BuildContext context) {
  
    return Scaffold(
      body: Container(
        constraints: BoxConstraints.expand(),
        decoration: BoxDecoration(
          color: Color.fromARGB(255, 255, 255, 255),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              height: 81,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.end,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 113,
                    height: 22,
                    margin: EdgeInsets.only(left: 16),
                    child: Row(
                      children: [
                        Container(
                          width: 13,
                          height: 19,
                          child: Image.asset(
                            "assets/images/back-3.png",
                            fit: BoxFit.none,
                          ),
                        ),
                        Spacer(),
                        Text(
                          "Checkout",
                          textAlign: TextAlign.left,
                          style: TextStyle(
                            color: AppColors.primaryText,
                            fontFamily: "Avenir",
                            fontWeight: FontWeight.w800,
                            fontSize: 16,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              height: 589,
              margin: EdgeInsets.only(left: 16, top: 40, right: 16),
              child: Stack(
                alignment: Alignment.center,
                children: [
                  Positioned(
                    left: 0,
                    top: 0,
                    right: 0,
                    child: Container(
                      height: 589,
                      decoration: BoxDecoration(
                        color: Color.fromARGB(255, 250, 250, 250),
                        boxShadow: [
                          Shadows.primaryShadow,
                        ],
                        borderRadius: BorderRadius.all(Radius.circular(12)),
                      ),
                      child: Container(),
                    ),
                  ),
                  Positioned(
                    top: 30,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Align(
                          alignment: Alignment.topCenter,
                          child: Container(
                            width: 300,
                            height: 99,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: [
                                Align(
                                  alignment: Alignment.topLeft,
                                  child: Text(
                                    "Delivery Address",
                                    textAlign: TextAlign.left,
                                    style: TextStyle(
                                      color: AppColors.primaryText,
                                      fontFamily: "Avenir",
                                      fontWeight: FontWeight.w800,
                                      fontSize: 16,
                                    ),
                                  ),
                                ),
                                Expanded(
                                  flex: 1,
                                  child: Container(
                                    margin: EdgeInsets.only(top: 15),
                                    child: Stack(
                                      alignment: Alignment.center,
                                      children: [
                                        Positioned(
                                          left: 0,
                                          right: 0,
                                          bottom: 0,
                                          child: Opacity(
                                            opacity: 0.19887,
                                            child: Container(
                                              height: 46,
                                              decoration: BoxDecoration(
                                                color: Color.fromARGB(255, 66, 80, 96),
                                              ),
                                              child: Container(),
                                            ),
                                          ),
                                        ),
                                        Positioned(
                                          left: 0,
                                          top: 0,
                                          right: 0,
                                          child: Container(
                                            height: 62,
                                            decoration: BoxDecoration(
                                              color: AppColors.primaryBackground,
                                              borderRadius: BorderRadius.all(Radius.circular(9)),
                                            ),
                                            child: Container(),
                                          ),
                                        ),
                                        Positioned(
                                          left: 15,
                                          top: 10,
                                          right: 15,
                                          bottom: 10,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.stretch,
                                            children: [
                                              Align(
                                                alignment: Alignment.topLeft,
                                                child: Opacity(
                                                  opacity: 0.59961,
                                                  child: Text(
                                                    "Home",
                                                    textAlign: TextAlign.left,
                                                    style: TextStyle(
                                                      color: AppColors.primaryText,
                                                      fontFamily: "Avenir",
                                                      fontWeight: FontWeight.w400,
                                                      fontSize: 14,
                                                      height: 1,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Spacer(),
                                              Container(
                                                height: 21,
                                                child: Row(
                                                  crossAxisAlignment: CrossAxisAlignment.stretch,
                                                  children: [
                                                    Align(
                                                      alignment: Alignment.bottomLeft,
                                                      child: Container(
                                                        width: 174,
                                                        height: 20,
                                                        child: TextField(
                                                          decoration: InputDecoration(
                                                            hintText: "216/ East Custom, Chhatak",
                                                            contentPadding: EdgeInsets.all(0),
                                                            border: InputBorder.none,
                                                          ),
                                                          style: TextStyle(
                                                            color: Color.fromARGB(255, 66, 80, 96),
                                                            fontFamily: "Avenir",
                                                            fontWeight: FontWeight.w500,
                                                            fontSize: 14,
                                                          ),
                                                          obscureText: true,
                                                          maxLines: 1,
                                                          keyboardType: TextInputType.url,
                                                          autocorrect: false,
                                                        ),
                                                      ),
                                                    ),
                                                    Spacer(),
                                                    Align(
                                                      alignment: Alignment.bottomLeft,
                                                      child: Container(
                                                        width: 18,
                                                        height: 18,
                                                        margin: EdgeInsets.only(bottom: 3),
                                                        child: FlatButton(
                                                          onPressed: () => this.onSelectedPressed(context),
                                                          color: Color.fromARGB(0, 0, 0, 0),
                                                          shape: RoundedRectangleBorder(
                                                            borderRadius: BorderRadius.all(Radius.circular(0)),
                                                          ),
                                                          textColor: Color.fromARGB(255, 0, 0, 0),
                                                          padding: EdgeInsets.all(0),
                                                          child: Row(
                                                            mainAxisAlignment: MainAxisAlignment.center,
                                                            children: [
                                                              Image.asset("assets/images/selected.png",),
                                                              SizedBox(
                                                                width: 10,
                                                              ),
                                                              Text(
                                                                "",
                                                                textAlign: TextAlign.left,
                                                                style: TextStyle(
                                                                  color: Color.fromARGB(255, 0, 0, 0),
                                                                  fontWeight: FontWeight.w400,
                                                                  fontSize: 12,
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Align(
                          alignment: Alignment.topCenter,
                          child: Container(
                            width: 300,
                            height: 400,
                            margin: EdgeInsets.only(top: 30),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: [
                                Align(
                                  alignment: Alignment.topLeft,
                                  child: Text(
                                    "Payment Method",
                                    textAlign: TextAlign.left,
                                    style: TextStyle(
                                      color: AppColors.primaryText,
                                      fontFamily: "Avenir",
                                      fontWeight: FontWeight.w800,
                                      fontSize: 16,
                                    ),
                                  ),
                                ),
                                Container(
                                  height: 60,
                                  margin: EdgeInsets.only(top: 13),
                                  decoration: BoxDecoration(
                                    color: AppColors.secondaryElement,
                                    borderRadius: BorderRadius.all(Radius.circular(9)),
                                  ),
                                  child: Container(),
                                ),
                                Container(
                                  height: 60,
                                  margin: EdgeInsets.only(top: 15),
                                  child: Stack(
                                    alignment: Alignment.centerLeft,
                                    children: [
                                      Positioned(
                                        left: 0,
                                        top: 16,
                                        right: 0,
                                        child: Opacity(
                                          opacity: 0.19887,
                                          child: Container(
                                            height: 44,
                                            decoration: BoxDecoration(
                                              color: Color.fromARGB(255, 66, 80, 96),
                                            ),
                                            child: Container(),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        left: 0,
                                        right: 0,
                                        child: Container(
                                          height: 60,
                                          decoration: BoxDecoration(
                                            color: AppColors.secondaryElement,
                                            borderRadius: BorderRadius.all(Radius.circular(9)),
                                          ),
                                          child: Container(),
                                        ),
                                      ),
                                      Positioned(
                                        left: 6,
                                        top: 8,
                                        right: 15,
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.stretch,
                                          children: [
                                            Align(
                                              alignment: Alignment.centerLeft,
                                              child: Container(
                                                width: 44,
                                                height: 44,
                                                decoration: BoxDecoration(
                                                  color: AppColors.secondaryElement,
                                                  borderRadius: Radii.k7pxRadius,
                                                ),
                                                child: Container(),
                                              ),
                                            ),
                                            Align(
                                              alignment: Alignment.topLeft,
                                              child: Container(
                                                width: 152,
                                                height: 42,
                                                margin: EdgeInsets.only(left: 15, top: 1),
                                                child: Column(
                                                  crossAxisAlignment: CrossAxisAlignment.stretch,
                                                  children: [
                                                    Align(
                                                      alignment: Alignment.topLeft,
                                                      child: Opacity(
                                                        opacity: 0.59961,
                                                        child: Text(
                                                          "Cash On Delivery",
                                                          textAlign: TextAlign.left,
                                                          style: TextStyle(
                                                            color: AppColors.primaryText,
                                                            fontFamily: "Avenir",
                                                            fontWeight: FontWeight.w400,
                                                            fontSize: 14,
                                                            height: 1,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Align(
                                                      alignment: Alignment.topLeft,
                                                      child: Container(
                                                        margin: EdgeInsets.only(top: 2),
                                                        child: Text(
                                                          "Pay after recive delivery",
                                                          textAlign: TextAlign.left,
                                                          style: TextStyle(
                                                            color: AppColors.primaryText,
                                                            fontFamily: "Avenir",
                                                            fontWeight: FontWeight.w500,
                                                            fontSize: 14,
                                                            height: 1,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                            Spacer(),
                                            Align(
                                              alignment: Alignment.topLeft,
                                              child: Container(
                                                width: 18,
                                                height: 18,
                                                margin: EdgeInsets.only(top: 22),
                                                child: Image.asset(
                                                  "assets/images/selected.png",
                                                  fit: BoxFit.none,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Positioned(
                                        left: 12,
                                        child: Image.asset(
                                          "assets/images/005-money-2.png",
                                          fit: BoxFit.none,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  height: 60,
                                  margin: EdgeInsets.only(top: 15),
                                  decoration: BoxDecoration(
                                    color: AppColors.secondaryElement,
                                    borderRadius: BorderRadius.all(Radius.circular(9)),
                                  ),
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Align(
                                        alignment: Alignment.centerLeft,
                                        child: Container(
                                          width: 44,
                                          height: 44,
                                          margin: EdgeInsets.only(left: 6),
                                          child: Stack(
                                            alignment: Alignment.center,
                                            children: [
                                              Positioned(
                                                left: 0,
                                                child: Container(
                                                  width: 44,
                                                  height: 44,
                                                  decoration: BoxDecoration(
                                                    color: AppColors.secondaryElement,
                                                    borderRadius: Radii.k7pxRadius,
                                                  ),
                                                  child: Container(),
                                                ),
                                              ),
                                              Positioned(
                                                left: 9,
                                                child: Image.asset(
                                                  "assets/images/002-paypal-1-2.png",
                                                  fit: BoxFit.none,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                      Container(
                                        width: 117,
                                        height: 42,
                                        margin: EdgeInsets.only(left: 15, top: 9),
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.stretch,
                                          children: [
                                            Align(
                                              alignment: Alignment.topLeft,
                                              child: Opacity(
                                                opacity: 0.59961,
                                                child: Text(
                                                  "Paypal",
                                                  textAlign: TextAlign.left,
                                                  style: TextStyle(
                                                    color: AppColors.primaryText,
                                                    fontFamily: "Avenir",
                                                    fontWeight: FontWeight.w400,
                                                    fontSize: 14,
                                                    height: 1,
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Align(
                                              alignment: Alignment.topLeft,
                                              child: Container(
                                                width: 117,
                                                height: 20,
                                                margin: EdgeInsets.only(top: 2),
                                                child: TextField(
                                                  decoration: InputDecoration(
                                                    hintText: "shakib402@paypal",
                                                    contentPadding: EdgeInsets.all(0),
                                                    border: InputBorder.none,
                                                  ),
                                                  style: TextStyle(
                                                    color: Color.fromARGB(255, 66, 80, 96),
                                                    fontFamily: "Avenir",
                                                    fontWeight: FontWeight.w500,
                                                    fontSize: 14,
                                                  ),
                                                  maxLines: 1,
                                                  keyboardType: TextInputType.emailAddress,
                                                  autocorrect: false,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  height: 60,
                                  margin: EdgeInsets.only(top: 15),
                                  decoration: BoxDecoration(
                                    color: AppColors.secondaryElement,
                                    borderRadius: BorderRadius.all(Radius.circular(9)),
                                  ),
                                  child: Row(
                                    children: [
                                      Container(
                                        width: 44,
                                        height: 44,
                                        margin: EdgeInsets.only(left: 6),
                                        child: Stack(
                                          alignment: Alignment.center,
                                          children: [
                                            Positioned(
                                              left: 0,
                                              child: Container(
                                                width: 44,
                                                height: 44,
                                                decoration: BoxDecoration(
                                                  color: AppColors.secondaryElement,
                                                  borderRadius: Radii.k7pxRadius,
                                                ),
                                                child: Container(),
                                              ),
                                            ),
                                            Positioned(
                                              left: 9,
                                              child: Image.asset(
                                                "assets/images/apple.png",
                                                fit: BoxFit.none,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Align(
                                        alignment: Alignment.topLeft,
                                        child: Container(
                                          width: 138,
                                          height: 42,
                                          margin: EdgeInsets.only(left: 15, top: 9),
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.stretch,
                                            children: [
                                              Align(
                                                alignment: Alignment.topLeft,
                                                child: Opacity(
                                                  opacity: 0.59961,
                                                  child: Text(
                                                    "Apple Pay",
                                                    textAlign: TextAlign.left,
                                                    style: TextStyle(
                                                      color: AppColors.primaryText,
                                                      fontFamily: "Avenir",
                                                      fontWeight: FontWeight.w400,
                                                      fontSize: 14,
                                                      height: 1,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Align(
                                                alignment: Alignment.topLeft,
                                                child: Container(
                                                  width: 138,
                                                  height: 20,
                                                  margin: EdgeInsets.only(top: 2),
                                                  child: TextField(
                                                    decoration: InputDecoration(
                                                      hintText: "shakib402@apple.pay",
                                                      contentPadding: EdgeInsets.all(0),
                                                      border: InputBorder.none,
                                                    ),
                                                    style: TextStyle(
                                                      color: Color.fromARGB(255, 66, 80, 96),
                                                      fontFamily: "Avenir",
                                                      fontWeight: FontWeight.w500,
                                                      fontSize: 14,
                                                    ),
                                                    maxLines: 1,
                                                    autocorrect: false,
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Spacer(),
                                Container(
                                  height: 50,
                                  child: FlatButton(
                                    onPressed: () => this.onButtonPressed(context),
                                    color: AppColors.primaryElement,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.all(Radius.circular(4)),
                                    ),
                                    textColor: Color.fromARGB(255, 66, 80, 96),
                                    padding: EdgeInsets.all(0),
                                    child: Text(
                                      "Order Now",
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        color: Color.fromARGB(255, 66, 80, 96),
                                        fontFamily: "Avenir",
                                        fontWeight: FontWeight.w800,
                                        fontSize: 14,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}