/*
*  notification_widget.dart
*  Food UI Kit
*
*  Created by [Author].
*  Copyright © 2018 [Company]. All rights reserved.
    */

import 'package:flutter/material.dart';
import 'package:food_ui_kit/edit_profile_widget/edit_profile_widget.dart';
import 'package:food_ui_kit/values/values.dart';


class NotificationWidget extends StatelessWidget {
  
  void onBackPressed(BuildContext context) => Navigator.push(context, MaterialPageRoute(builder: (context) => EditProfileWidget()));
  
  @override
  Widget build(BuildContext context) {
  
    return Scaffold(
      body: Container(
        constraints: BoxConstraints.expand(),
        decoration: BoxDecoration(
          color: Color.fromARGB(255, 250, 250, 250),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              height: 81,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.end,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 130,
                    height: 22,
                    margin: EdgeInsets.only(left: 16),
                    child: Row(
                      children: [
                        Container(
                          width: 13,
                          height: 19,
                          child: FlatButton(
                            onPressed: () => this.onBackPressed(context),
                            color: Color.fromARGB(0, 0, 0, 0),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.all(Radius.circular(0)),
                            ),
                            textColor: Color.fromARGB(255, 0, 0, 0),
                            padding: EdgeInsets.all(0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Image.asset("assets/images/back-3.png",),
                                SizedBox(
                                  width: 10,
                                ),
                                Text(
                                  "",
                                  textAlign: TextAlign.left,
                                  style: TextStyle(
                                    color: Color.fromARGB(255, 0, 0, 0),
                                    fontWeight: FontWeight.w400,
                                    fontSize: 12,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Spacer(),
                        Text(
                          "Notification",
                          textAlign: TextAlign.left,
                          style: TextStyle(
                            color: AppColors.primaryText,
                            fontFamily: "Avenir",
                            fontWeight: FontWeight.w800,
                            fontSize: 16,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              height: 330,
              margin: EdgeInsets.only(left: 20, top: 50, right: 20),
              decoration: BoxDecoration(
                color: AppColors.primaryBackground,
                boxShadow: [
                  Shadows.primaryShadow,
                ],
                borderRadius: BorderRadius.all(Radius.circular(12)),
              ),
              child: Stack(
                alignment: Alignment.center,
                children: [
                  Positioned(
                    left: 18,
                    top: 100,
                    right: 17,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Container(
                          height: 30,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Container(
                                height: 20,
                                margin: EdgeInsets.only(left: 6, right: 3),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.stretch,
                                  children: [
                                    Align(
                                      alignment: Alignment.topLeft,
                                      child: Text(
                                        "App Notification",
                                        textAlign: TextAlign.left,
                                        style: TextStyle(
                                          color: AppColors.primaryText,
                                          fontFamily: "Avenir",
                                          fontWeight: FontWeight.w500,
                                          fontSize: 14,
                                          height: 1,
                                        ),
                                      ),
                                    ),
                                    Spacer(),
                                    Align(
                                      alignment: Alignment.topLeft,
                                      child: Container(
                                        width: 30,
                                        height: 16,
                                        margin: EdgeInsets.only(top: 3),
                                        child: Stack(
                                          alignment: Alignment.center,
                                          children: [
                                            Positioned(
                                              top: 0,
                                              right: 0,
                                              child: Container(
                                                width: 30,
                                                height: 16,
                                                decoration: BoxDecoration(
                                                  color: AppColors.primaryElement,
                                                  borderRadius: BorderRadius.all(Radius.circular(8)),
                                                ),
                                                child: Container(),
                                              ),
                                            ),
                                            Positioned(
                                              top: 2,
                                              right: 3,
                                              child: Container(
                                                width: 12,
                                                height: 12,
                                                decoration: BoxDecoration(
                                                  color: AppColors.secondaryElement,
                                                  borderRadius: BorderRadius.all(Radius.circular(6)),
                                                ),
                                                child: Container(),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Spacer(),
                              Container(
                                height: 1,
                                decoration: BoxDecoration(
                                  color: Color.fromARGB(255, 243, 243, 243),
                                  borderRadius: BorderRadius.all(Radius.circular(0.5)),
                                ),
                                child: Container(),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          height: 30,
                          margin: EdgeInsets.only(top: 70),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Container(
                                height: 20,
                                margin: EdgeInsets.only(left: 6, right: 3),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.stretch,
                                  children: [
                                    Align(
                                      alignment: Alignment.topLeft,
                                      child: Text(
                                        "Offer Notification",
                                        textAlign: TextAlign.left,
                                        style: TextStyle(
                                          color: AppColors.primaryText,
                                          fontFamily: "Avenir",
                                          fontWeight: FontWeight.w500,
                                          fontSize: 14,
                                          height: 1,
                                        ),
                                      ),
                                    ),
                                    Spacer(),
                                    Align(
                                      alignment: Alignment.topLeft,
                                      child: Container(
                                        width: 30,
                                        height: 16,
                                        margin: EdgeInsets.only(top: 3),
                                        child: Stack(
                                          alignment: Alignment.center,
                                          children: [
                                            Positioned(
                                              top: 0,
                                              right: 0,
                                              child: Container(
                                                width: 30,
                                                height: 16,
                                                decoration: BoxDecoration(
                                                  color: AppColors.primaryElement,
                                                  borderRadius: BorderRadius.all(Radius.circular(8)),
                                                ),
                                                child: Container(),
                                              ),
                                            ),
                                            Positioned(
                                              top: 2,
                                              right: 3,
                                              child: Container(
                                                width: 12,
                                                height: 12,
                                                decoration: BoxDecoration(
                                                  color: AppColors.secondaryElement,
                                                  borderRadius: BorderRadius.all(Radius.circular(6)),
                                                ),
                                                child: Container(),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Spacer(),
                              Container(
                                height: 1,
                                decoration: BoxDecoration(
                                  color: Color.fromARGB(255, 243, 243, 243),
                                  borderRadius: BorderRadius.all(Radius.circular(0.5)),
                                ),
                                child: Container(),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Positioned(
                    left: 18,
                    right: 17,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Container(
                          height: 20,
                          margin: EdgeInsets.only(left: 6, right: 3),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Align(
                                alignment: Alignment.topLeft,
                                child: Text(
                                  "Email Notification",
                                  textAlign: TextAlign.left,
                                  style: TextStyle(
                                    color: AppColors.primaryText,
                                    fontFamily: "Avenir",
                                    fontWeight: FontWeight.w500,
                                    fontSize: 14,
                                    height: 1,
                                  ),
                                ),
                              ),
                              Spacer(),
                              Align(
                                alignment: Alignment.topLeft,
                                child: Container(
                                  width: 30,
                                  height: 16,
                                  margin: EdgeInsets.only(top: 3),
                                  child: Stack(
                                    alignment: Alignment.center,
                                    children: [
                                      Positioned(
                                        top: 0,
                                        right: 0,
                                        child: Container(
                                          width: 30,
                                          height: 16,
                                          decoration: BoxDecoration(
                                            color: Color.fromARGB(255, 243, 243, 243),
                                            borderRadius: BorderRadius.all(Radius.circular(8)),
                                          ),
                                          child: Container(),
                                        ),
                                      ),
                                      Positioned(
                                        top: 2,
                                        right: 15,
                                        child: Container(
                                          width: 12,
                                          height: 12,
                                          decoration: BoxDecoration(
                                            color: AppColors.secondaryElement,
                                            borderRadius: BorderRadius.all(Radius.circular(6)),
                                          ),
                                          child: Container(),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Spacer(),
                        Container(
                          height: 1,
                          decoration: BoxDecoration(
                            color: Color.fromARGB(255, 243, 243, 243),
                            borderRadius: BorderRadius.all(Radius.circular(0.5)),
                          ),
                          child: Container(),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}