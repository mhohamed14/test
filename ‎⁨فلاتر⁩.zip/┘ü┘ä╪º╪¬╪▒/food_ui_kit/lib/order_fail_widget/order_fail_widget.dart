/*
*  order_fail_widget.dart
*  Food UI Kit
*
*  Created by [Author].
*  Copyright © 2018 [Company]. All rights reserved.
    */

import 'package:flutter/material.dart';
import 'package:food_ui_kit/empty_cart_widget/empty_cart_widget.dart';
import 'package:food_ui_kit/order_done_widget/order_done_widget.dart';
import 'package:food_ui_kit/values/values.dart';


class OrderFailWidget extends StatelessWidget {
  
  void onBackPressed(BuildContext context) => Navigator.push(context, MaterialPageRoute(builder: (context) => EmptyCartWidget()));
  
  void onButtonPressed(BuildContext context) => Navigator.push(context, MaterialPageRoute(builder: (context) => OrderDoneWidget()));
  
  @override
  Widget build(BuildContext context) {
  
    return Scaffold(
      body: Container(
        constraints: BoxConstraints.expand(),
        decoration: BoxDecoration(
          color: Color.fromARGB(255, 250, 250, 250),
        ),
        child: Stack(
          alignment: Alignment.center,
          children: [
            Positioned(
              left: 0,
              top: 0,
              right: 0,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    height: 81,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.end,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          width: 113,
                          height: 22,
                          margin: EdgeInsets.only(left: 16),
                          child: Row(
                            children: [
                              Container(
                                width: 13,
                                height: 19,
                                child: FlatButton(
                                  onPressed: () => this.onBackPressed(context),
                                  color: Color.fromARGB(0, 0, 0, 0),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.all(Radius.circular(0)),
                                  ),
                                  textColor: Color.fromARGB(255, 0, 0, 0),
                                  padding: EdgeInsets.all(0),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Image.asset("assets/images/back-3.png",),
                                      SizedBox(
                                        width: 10,
                                      ),
                                      Text(
                                        "",
                                        textAlign: TextAlign.left,
                                        style: TextStyle(
                                          color: Color.fromARGB(255, 0, 0, 0),
                                          fontWeight: FontWeight.w400,
                                          fontSize: 12,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Spacer(),
                              Text(
                                "Checkout",
                                textAlign: TextAlign.left,
                                style: TextStyle(
                                  color: AppColors.primaryText,
                                  fontFamily: "Avenir",
                                  fontWeight: FontWeight.w800,
                                  fontSize: 16,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    height: 564,
                    margin: EdgeInsets.only(left: 20, top: 40, right: 20),
                    decoration: BoxDecoration(
                      color: AppColors.primaryBackground,
                      boxShadow: [
                        Shadows.primaryShadow,
                      ],
                      borderRadius: BorderRadius.all(Radius.circular(12)),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Container(
                          height: 93,
                          margin: EdgeInsets.only(left: 18, top: 30, right: 17),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Align(
                                alignment: Alignment.topLeft,
                                child: Text(
                                  "Delivery Address",
                                  textAlign: TextAlign.left,
                                  style: TextStyle(
                                    color: AppColors.primaryText,
                                    fontFamily: "Avenir",
                                    fontWeight: FontWeight.w800,
                                    fontSize: 16,
                                  ),
                                ),
                              ),
                              Expanded(
                                flex: 1,
                                child: Container(
                                  margin: EdgeInsets.only(top: 13, bottom: 2),
                                  child: Stack(
                                    alignment: Alignment.center,
                                    children: [
                                      Positioned(
                                        left: 0,
                                        top: 0,
                                        right: 0,
                                        child: Container(
                                          height: 56,
                                          decoration: BoxDecoration(
                                            color: AppColors.accentElement,
                                            border: Border.all(
                                              width: 1,
                                              color: Color.fromARGB(255, 255, 210, 78),
                                            ),
                                            borderRadius: Radii.k7pxRadius,
                                          ),
                                          child: Container(),
                                        ),
                                      ),
                                      Positioned(
                                        left: 15,
                                        right: 15,
                                        bottom: 8,
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.stretch,
                                          children: [
                                            Align(
                                              alignment: Alignment.bottomLeft,
                                              child: Text(
                                                "216/ East Custom, Chhatak",
                                                textAlign: TextAlign.left,
                                                style: TextStyle(
                                                  color: AppColors.primaryText,
                                                  fontFamily: "Avenir",
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: 14,
                                                  height: 1,
                                                ),
                                              ),
                                            ),
                                            Spacer(),
                                            Align(
                                              alignment: Alignment.bottomLeft,
                                              child: Container(
                                                width: 18,
                                                height: 18,
                                                child: Image.asset(
                                                  "assets/images/selected.png",
                                                  fit: BoxFit.none,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Positioned(
                                        left: 15,
                                        top: 9,
                                        child: Opacity(
                                          opacity: 0.59961,
                                          child: Text(
                                            "Home",
                                            textAlign: TextAlign.left,
                                            style: TextStyle(
                                              color: AppColors.primaryText,
                                              fontFamily: "Avenir",
                                              fontWeight: FontWeight.w400,
                                              fontSize: 14,
                                              height: 1,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          height: 381,
                          margin: EdgeInsets.only(left: 18, top: 30, right: 17),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Align(
                                alignment: Alignment.topLeft,
                                child: Text(
                                  "Payment Method",
                                  textAlign: TextAlign.left,
                                  style: TextStyle(
                                    color: AppColors.primaryText,
                                    fontFamily: "Avenir",
                                    fontWeight: FontWeight.w800,
                                    fontSize: 16,
                                  ),
                                ),
                              ),
                              Container(
                                height: 56,
                                margin: EdgeInsets.only(top: 15),
                                decoration: BoxDecoration(
                                  color: AppColors.accentElement,
                                  border: Border.all(
                                    width: 1,
                                    color: Color.fromARGB(255, 243, 243, 243),
                                  ),
                                  borderRadius: Radii.k7pxRadius,
                                ),
                                child: Row(
                                  children: [
                                    Container(
                                      width: 44,
                                      height: 44,
                                      margin: EdgeInsets.only(left: 6),
                                      child: Stack(
                                        alignment: Alignment.center,
                                        children: [
                                          Positioned(
                                            left: 0,
                                            child: Container(
                                              width: 44,
                                              height: 44,
                                              decoration: BoxDecoration(
                                                color: AppColors.secondaryElement,
                                                borderRadius: Radii.k7pxRadius,
                                              ),
                                              child: Container(),
                                            ),
                                          ),
                                          Positioned(
                                            left: 6,
                                            child: Image.asset(
                                              "assets/images/visa.png",
                                              fit: BoxFit.none,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Align(
                                      alignment: Alignment.topLeft,
                                      child: Container(
                                        width: 121,
                                        height: 42,
                                        margin: EdgeInsets.only(left: 15, top: 7),
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.stretch,
                                          children: [
                                            Align(
                                              alignment: Alignment.topLeft,
                                              child: Opacity(
                                                opacity: 0.59961,
                                                child: Text(
                                                  "Visa Card",
                                                  textAlign: TextAlign.left,
                                                  style: TextStyle(
                                                    color: AppColors.primaryText,
                                                    fontFamily: "Avenir",
                                                    fontWeight: FontWeight.w400,
                                                    fontSize: 14,
                                                    height: 1,
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Align(
                                              alignment: Alignment.topLeft,
                                              child: Container(
                                                margin: EdgeInsets.only(top: 2),
                                                child: Text(
                                                  "**** **** **** 5162",
                                                  textAlign: TextAlign.left,
                                                  style: TextStyle(
                                                    color: AppColors.primaryText,
                                                    fontFamily: "Avenir",
                                                    fontWeight: FontWeight.w500,
                                                    fontSize: 14,
                                                    height: 1,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                height: 56,
                                margin: EdgeInsets.only(top: 10),
                                decoration: BoxDecoration(
                                  color: AppColors.accentElement,
                                  border: Border.all(
                                    width: 1,
                                    color: Color.fromARGB(255, 255, 210, 78),
                                  ),
                                  borderRadius: Radii.k7pxRadius,
                                ),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Align(
                                      alignment: Alignment.centerLeft,
                                      child: Container(
                                        width: 44,
                                        height: 44,
                                        margin: EdgeInsets.only(left: 6),
                                        child: Stack(
                                          alignment: Alignment.center,
                                          children: [
                                            Positioned(
                                              left: 0,
                                              child: Container(
                                                width: 44,
                                                height: 44,
                                                decoration: BoxDecoration(
                                                  color: AppColors.secondaryElement,
                                                  borderRadius: Radii.k7pxRadius,
                                                ),
                                                child: Container(),
                                              ),
                                            ),
                                            Positioned(
                                              left: 6,
                                              child: Image.asset(
                                                "assets/images/005-money-2.png",
                                                fit: BoxFit.none,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    Container(
                                      width: 152,
                                      height: 42,
                                      margin: EdgeInsets.only(left: 15, top: 7),
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.stretch,
                                        children: [
                                          Align(
                                            alignment: Alignment.topLeft,
                                            child: Opacity(
                                              opacity: 0.59961,
                                              child: Text(
                                                "Cash On Delivery",
                                                textAlign: TextAlign.left,
                                                style: TextStyle(
                                                  color: AppColors.primaryText,
                                                  fontFamily: "Avenir",
                                                  fontWeight: FontWeight.w400,
                                                  fontSize: 14,
                                                  height: 1,
                                                ),
                                              ),
                                            ),
                                          ),
                                          Align(
                                            alignment: Alignment.topLeft,
                                            child: Container(
                                              margin: EdgeInsets.only(top: 2),
                                              child: Text(
                                                "Pay after recive delivery",
                                                textAlign: TextAlign.left,
                                                style: TextStyle(
                                                  color: AppColors.primaryText,
                                                  fontFamily: "Avenir",
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: 14,
                                                  height: 1,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Spacer(),
                                    Container(
                                      width: 18,
                                      height: 18,
                                      margin: EdgeInsets.only(top: 28, right: 15),
                                      child: Image.asset(
                                        "assets/images/selected.png",
                                        fit: BoxFit.none,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                height: 56,
                                margin: EdgeInsets.only(top: 10),
                                decoration: BoxDecoration(
                                  color: AppColors.accentElement,
                                  border: Border.all(
                                    width: 1,
                                    color: Color.fromARGB(255, 243, 243, 243),
                                  ),
                                  borderRadius: Radii.k7pxRadius,
                                ),
                                child: Row(
                                  children: [
                                    Container(
                                      width: 44,
                                      height: 44,
                                      margin: EdgeInsets.only(left: 6),
                                      child: Stack(
                                        alignment: Alignment.center,
                                        children: [
                                          Positioned(
                                            left: 0,
                                            child: Container(
                                              width: 44,
                                              height: 44,
                                              decoration: BoxDecoration(
                                                color: AppColors.secondaryElement,
                                                borderRadius: Radii.k7pxRadius,
                                              ),
                                              child: Container(),
                                            ),
                                          ),
                                          Positioned(
                                            left: 9,
                                            child: Image.asset(
                                              "assets/images/002-paypal-1-2.png",
                                              fit: BoxFit.none,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Align(
                                      alignment: Alignment.topLeft,
                                      child: Container(
                                        width: 117,
                                        height: 42,
                                        margin: EdgeInsets.only(left: 15, top: 7),
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.stretch,
                                          children: [
                                            Align(
                                              alignment: Alignment.topLeft,
                                              child: Opacity(
                                                opacity: 0.59961,
                                                child: Text(
                                                  "Paypal",
                                                  textAlign: TextAlign.left,
                                                  style: TextStyle(
                                                    color: AppColors.primaryText,
                                                    fontFamily: "Avenir",
                                                    fontWeight: FontWeight.w400,
                                                    fontSize: 14,
                                                    height: 1,
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Align(
                                              alignment: Alignment.topLeft,
                                              child: Container(
                                                margin: EdgeInsets.only(top: 2),
                                                child: Text(
                                                  "shakib402@paypal",
                                                  textAlign: TextAlign.left,
                                                  style: TextStyle(
                                                    color: AppColors.primaryText,
                                                    fontFamily: "Avenir",
                                                    fontWeight: FontWeight.w500,
                                                    fontSize: 14,
                                                    height: 1,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                height: 56,
                                margin: EdgeInsets.only(top: 10),
                                decoration: BoxDecoration(
                                  color: AppColors.accentElement,
                                  border: Border.all(
                                    width: 1,
                                    color: Color.fromARGB(255, 243, 243, 243),
                                  ),
                                  borderRadius: Radii.k7pxRadius,
                                ),
                                child: Row(
                                  children: [
                                    Container(
                                      width: 44,
                                      height: 44,
                                      margin: EdgeInsets.only(left: 6),
                                      child: Stack(
                                        alignment: Alignment.center,
                                        children: [
                                          Positioned(
                                            left: 0,
                                            child: Container(
                                              width: 44,
                                              height: 44,
                                              decoration: BoxDecoration(
                                                color: AppColors.secondaryElement,
                                                borderRadius: Radii.k7pxRadius,
                                              ),
                                              child: Container(),
                                            ),
                                          ),
                                          Positioned(
                                            left: 9,
                                            child: Image.asset(
                                              "assets/images/apple.png",
                                              fit: BoxFit.none,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Align(
                                      alignment: Alignment.topLeft,
                                      child: Container(
                                        width: 138,
                                        height: 42,
                                        margin: EdgeInsets.only(left: 15, top: 7),
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.stretch,
                                          children: [
                                            Align(
                                              alignment: Alignment.topLeft,
                                              child: Opacity(
                                                opacity: 0.59961,
                                                child: Text(
                                                  "Apple Pay",
                                                  textAlign: TextAlign.left,
                                                  style: TextStyle(
                                                    color: AppColors.primaryText,
                                                    fontFamily: "Avenir",
                                                    fontWeight: FontWeight.w400,
                                                    fontSize: 14,
                                                    height: 1,
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Align(
                                              alignment: Alignment.topLeft,
                                              child: Container(
                                                margin: EdgeInsets.only(top: 2),
                                                child: Text(
                                                  "shakib402@apple.pay",
                                                  textAlign: TextAlign.left,
                                                  style: TextStyle(
                                                    color: AppColors.primaryText,
                                                    fontFamily: "Avenir",
                                                    fontWeight: FontWeight.w500,
                                                    fontSize: 14,
                                                    height: 1,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Spacer(),
                              Container(
                                height: 50,
                                decoration: BoxDecoration(
                                  color: AppColors.primaryElement,
                                  borderRadius: BorderRadius.all(Radius.circular(9)),
                                ),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text(
                                      "Pay Now",
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        color: AppColors.primaryText,
                                        fontFamily: "Avenir",
                                        fontWeight: FontWeight.w800,
                                        fontSize: 14,
                                        height: 1,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Positioned(
              left: 0,
              right: 0,
              child: Opacity(
                opacity: 0.30222,
                child: Container(
                  height: 812,
                  decoration: BoxDecoration(
                    color: Color.fromARGB(255, 0, 0, 0),
                  ),
                  child: Container(),
                ),
              ),
            ),
            Positioned(
              left: 20,
              top: 141,
              right: 20,
              child: Container(
                height: 580,
                decoration: BoxDecoration(
                  color: AppColors.primaryBackground,
                  boxShadow: [
                    Shadows.primaryShadow,
                  ],
                  borderRadius: BorderRadius.all(Radius.circular(30)),
                ),
                child: Container(),
              ),
            ),
            Positioned(
              left: 0,
              top: 161,
              right: -11,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    height: 251,
                    child: Stack(
                      children: [
                        Positioned(
                          left: -0,
                          top: 1,
                          right: 1,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Align(
                                alignment: Alignment.topLeft,
                                child: Container(
                                  width: 124,
                                  height: 165,
                                  margin: EdgeInsets.only(top: 10),
                                  child: Image.asset(
                                    "assets/images/group-copy-2.png",
                                    fit: BoxFit.none,
                                  ),
                                ),
                              ),
                              Spacer(),
                              Align(
                                alignment: Alignment.topLeft,
                                child: Container(
                                  width: 148,
                                  height: 163,
                                  child: Image.asset(
                                    "assets/images/group-copy.png",
                                    fit: BoxFit.none,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Positioned(
                          left: 85,
                          top: 45,
                          child: Image.asset(
                            "assets/images/o-5.png",
                            fit: BoxFit.cover,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Align(
                    alignment: Alignment.topCenter,
                    child: Container(
                      width: 284,
                      height: 195,
                      margin: EdgeInsets.only(top: 30),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Align(
                            alignment: Alignment.topCenter,
                            child: Container(
                              width: 215,
                              child: Text(
                                "Sorry, Your Order has Failed",
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  color: AppColors.primaryText,
                                  fontFamily: "Avenir",
                                  fontWeight: FontWeight.w800,
                                  fontSize: 24,
                                  height: 1.41667,
                                ),
                              ),
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.only(left: 14, top: 15, right: 14),
                            child: Opacity(
                              opacity: 0.59961,
                              child: Text(
                                "Sorry, somethings went wrong. \nPlease try again to continue your order.  ",
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  color: AppColors.primaryText,
                                  fontFamily: "Avenir",
                                  fontWeight: FontWeight.w400,
                                  fontSize: 14,
                                  height: 1.5,
                                ),
                              ),
                            ),
                          ),
                          Spacer(),
                          Align(
                            alignment: Alignment.topCenter,
                            child: Container(
                              width: 122,
                              height: 44,
                              child: FlatButton(
                                onPressed: () => this.onButtonPressed(context),
                                color: AppColors.primaryElement,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.all(Radius.circular(4)),
                                ),
                                textColor: Color.fromARGB(255, 66, 80, 96),
                                padding: EdgeInsets.all(0),
                                child: Text(
                                  "Try Again",
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    color: Color.fromARGB(255, 66, 80, 96),
                                    fontFamily: "Avenir",
                                    fontWeight: FontWeight.w800,
                                    fontSize: 14,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}