/*
*  shop_home_widget.dart
*  Food UI Kit
*
*  Created by [Author].
*  Copyright © 2018 [Company]. All rights reserved.
    */

import 'package:flutter/material.dart';
import 'package:food_ui_kit/search_filter_widget/search_filter_widget.dart';
import 'package:food_ui_kit/search_on_list_widget/search_on_list_widget.dart';
import 'package:food_ui_kit/values/values.dart';


class ShopHomeWidget extends StatelessWidget {
  
  void onButtonPressed(BuildContext context) => Navigator.push(context, MaterialPageRoute(builder: (context) => SearchOnListWidget()));
  
  void onSharePressed(BuildContext context) {
  
  }
  
  void onBackPressed(BuildContext context) => Navigator.push(context, MaterialPageRoute(builder: (context) => SearchFilterWidget()));
  
  @override
  Widget build(BuildContext context) {
  
    return Scaffold(
      body: Container(
        constraints: BoxConstraints.expand(),
        decoration: BoxDecoration(
          color: Color.fromARGB(255, 250, 250, 250),
        ),
        child: Stack(
          alignment: Alignment.topCenter,
          children: [
            Positioned(
              left: 0,
              top: 0,
              right: 0,
              bottom: -362,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    height: 421,
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        Positioned(
                          left: 0,
                          top: 0,
                          right: 0,
                          child: Container(
                            height: 421,
                            decoration: BoxDecoration(
                              color: AppColors.primaryBackground,
                              boxShadow: [
                                BoxShadow(
                                  color: Color.fromARGB(76, 211, 217, 227),
                                  offset: Offset(0, -1),
                                  blurRadius: 5,
                                ),
                              ],
                              borderRadius: BorderRadius.all(Radius.circular(22)),
                            ),
                            child: Container(),
                          ),
                        ),
                        Positioned(
                          left: 0,
                          top: 0,
                          right: 0,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Container(
                                height: 239,
                                child: Image.asset(
                                  "assets/images/image.png",
                                  fit: BoxFit.cover,
                                ),
                              ),
                              Container(
                                height: 52,
                                margin: EdgeInsets.only(left: 24, top: 16, right: 16),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.stretch,
                                  children: [
                                    Align(
                                      alignment: Alignment.topLeft,
                                      child: Container(
                                        width: 211,
                                        height: 52,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.stretch,
                                          children: [
                                            Align(
                                              alignment: Alignment.topLeft,
                                              child: Text(
                                                "Italiano Restaurant",
                                                textAlign: TextAlign.left,
                                                style: TextStyle(
                                                  color: AppColors.primaryText,
                                                  fontFamily: "Avenir",
                                                  fontWeight: FontWeight.w800,
                                                  fontSize: 24,
                                                  height: 0.91667,
                                                ),
                                              ),
                                            ),
                                            Align(
                                              alignment: Alignment.topLeft,
                                              child: Container(
                                                width: 181,
                                                height: 14,
                                                margin: EdgeInsets.only(top: 5),
                                                child: Row(
                                                  children: [
                                                    Container(
                                                      width: 8,
                                                      height: 12,
                                                      child: Image.asset(
                                                        "assets/images/maps-and-flags-3.png",
                                                        fit: BoxFit.none,
                                                      ),
                                                    ),
                                                    Expanded(
                                                      flex: 1,
                                                      child: Container(
                                                        margin: EdgeInsets.only(left: 10),
                                                        child: Opacity(
                                                          opacity: 0.59961,
                                                          child: Text(
                                                            "Nayasharak Road, Sylhet  ",
                                                            textAlign: TextAlign.left,
                                                            style: TextStyle(
                                                              color: AppColors.primaryText,
                                                              fontFamily: "Avenir",
                                                              fontWeight: FontWeight.w400,
                                                              fontSize: 14,
                                                              height: 1,
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    Spacer(),
                                    Align(
                                      alignment: Alignment.topLeft,
                                      child: Container(
                                        width: 90,
                                        height: 36,
                                        margin: EdgeInsets.only(top: 16),
                                        child: FlatButton(
                                          onPressed: () => this.onButtonPressed(context),
                                          color: AppColors.primaryElement,
                                          shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.all(Radius.circular(4)),
                                          ),
                                          textColor: Color.fromARGB(255, 66, 80, 96),
                                          padding: EdgeInsets.all(0),
                                          child: Text(
                                            "Follow",
                                            textAlign: TextAlign.center,
                                            style: TextStyle(
                                              color: Color.fromARGB(255, 66, 80, 96),
                                              fontFamily: "Avenir",
                                              fontWeight: FontWeight.w800,
                                              fontSize: 14,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Align(
                                alignment: Alignment.topCenter,
                                child: Container(
                                  width: 330,
                                  height: 1,
                                  margin: EdgeInsets.only(top: 15),
                                  decoration: BoxDecoration(
                                    color: Color.fromARGB(255, 243, 243, 243),
                                    borderRadius: BorderRadius.all(Radius.circular(0.5)),
                                  ),
                                  child: Container(),
                                ),
                              ),
                              Container(
                                height: 68,
                                margin: EdgeInsets.only(left: 24, top: 15, right: 24),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.stretch,
                                  children: [
                                    Align(
                                      alignment: Alignment.topLeft,
                                      child: Container(
                                        width: 71,
                                        height: 68,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.stretch,
                                          children: [
                                            Container(
                                              height: 30,
                                              margin: EdgeInsets.only(left: 20, right: 19),
                                              child: Image.asset(
                                                "assets/images/delivery-man.png",
                                                fit: BoxFit.none,
                                              ),
                                            ),
                                            Expanded(
                                              flex: 1,
                                              child: Container(
                                                margin: EdgeInsets.only(left: 13, top: 6, right: 13),
                                                child: Stack(
                                                  alignment: Alignment.center,
                                                  children: [
                                                    Positioned(
                                                      left: 2,
                                                      top: 0,
                                                      right: 2,
                                                      child: Text(
                                                        "30min",
                                                        textAlign: TextAlign.center,
                                                        style: TextStyle(
                                                          color: AppColors.primaryText,
                                                          fontFamily: "Avenir",
                                                          fontWeight: FontWeight.w800,
                                                          fontSize: 14,
                                                          height: 1,
                                                        ),
                                                      ),
                                                    ),
                                                    Positioned(
                                                      left: 0,
                                                      right: 0,
                                                      bottom: 0,
                                                      child: Opacity(
                                                        opacity: 0.59961,
                                                        child: Text(
                                                          "Delivery",
                                                          textAlign: TextAlign.center,
                                                          style: TextStyle(
                                                            color: AppColors.primaryText,
                                                            fontFamily: "Avenir",
                                                            fontWeight: FontWeight.w400,
                                                            fontSize: 12,
                                                            height: 1,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    Spacer(),
                                    Align(
                                      alignment: Alignment.topLeft,
                                      child: Container(
                                        width: 71,
                                        height: 68,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.stretch,
                                          children: [
                                            Align(
                                              alignment: Alignment.topRight,
                                              child: Container(
                                                width: 30,
                                                height: 30,
                                                margin: EdgeInsets.only(right: 20),
                                                child: Image.asset(
                                                  "assets/images/rating-3-2.png",
                                                  fit: BoxFit.none,
                                                ),
                                              ),
                                            ),
                                            Expanded(
                                              flex: 1,
                                              child: Container(
                                                margin: EdgeInsets.only(left: 3, top: 6, right: 3),
                                                child: Stack(
                                                  alignment: Alignment.center,
                                                  children: [
                                                    Positioned(
                                                      top: 0,
                                                      child: Text(
                                                        "4.5",
                                                        textAlign: TextAlign.center,
                                                        style: TextStyle(
                                                          color: AppColors.primaryText,
                                                          fontFamily: "Avenir",
                                                          fontWeight: FontWeight.w800,
                                                          fontSize: 14,
                                                          height: 1,
                                                        ),
                                                      ),
                                                    ),
                                                    Positioned(
                                                      left: 0,
                                                      right: 0,
                                                      bottom: 0,
                                                      child: Opacity(
                                                        opacity: 0.59961,
                                                        child: Text(
                                                          "130 reviews",
                                                          textAlign: TextAlign.center,
                                                          style: TextStyle(
                                                            color: AppColors.primaryText,
                                                            fontFamily: "Avenir",
                                                            fontWeight: FontWeight.w400,
                                                            fontSize: 12,
                                                            height: 1,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        Positioned(
                          left: 16,
                          top: 52,
                          right: 16,
                          child: Row(
                            children: [
                              Container(
                                width: 13,
                                height: 19,
                                child: FlatButton(
                                  onPressed: () => this.onBackPressed(context),
                                  color: Color.fromARGB(0, 0, 0, 0),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.all(Radius.circular(0)),
                                  ),
                                  textColor: Color.fromARGB(255, 0, 0, 0),
                                  padding: EdgeInsets.all(0),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Image.asset("assets/images/back.png",),
                                      SizedBox(
                                        width: 10,
                                      ),
                                      Text(
                                        "",
                                        textAlign: TextAlign.left,
                                        style: TextStyle(
                                          color: Color.fromARGB(255, 0, 0, 0),
                                          fontWeight: FontWeight.w400,
                                          fontSize: 12,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Spacer(),
                              Container(
                                width: 16,
                                height: 16,
                                margin: EdgeInsets.only(right: 25),
                                child: FlatButton(
                                  onPressed: () => this.onSharePressed(context),
                                  color: Color.fromARGB(0, 0, 0, 0),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.all(Radius.circular(0)),
                                  ),
                                  textColor: Color.fromARGB(255, 0, 0, 0),
                                  padding: EdgeInsets.all(0),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Image.asset("assets/images/share.png",),
                                      SizedBox(
                                        width: 10,
                                      ),
                                      Text(
                                        "",
                                        textAlign: TextAlign.left,
                                        style: TextStyle(
                                          color: Color.fromARGB(255, 0, 0, 0),
                                          fontWeight: FontWeight.w400,
                                          fontSize: 12,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Container(
                                width: 16,
                                height: 16,
                                margin: EdgeInsets.only(right: 25),
                                child: Image.asset(
                                  "assets/images/search.png",
                                  fit: BoxFit.none,
                                ),
                              ),
                              Container(
                                width: 3,
                                height: 16,
                                child: Image.asset(
                                  "assets/images/option.png",
                                  fit: BoxFit.none,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Spacer(),
                  Container(
                    height: 733,
                    margin: EdgeInsets.symmetric(horizontal: 16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Container(
                          height: 174,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Align(
                                alignment: Alignment.topLeft,
                                child: Container(
                                  width: 166,
                                  height: 174,
                                  child: Stack(
                                    alignment: Alignment.center,
                                    children: [
                                      Positioned(
                                        left: 0,
                                        top: 14,
                                        right: 0,
                                        child: Opacity(
                                          opacity: 0.05,
                                          child: Container(
                                            height: 160,
                                            decoration: BoxDecoration(
                                              color: AppColors.ternaryBackground,
                                              borderRadius: BorderRadius.all(Radius.circular(14)),
                                            ),
                                            child: Container(),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        left: 0,
                                        right: 0,
                                        child: Container(
                                          height: 174,
                                          decoration: BoxDecoration(
                                            color: AppColors.secondaryBackground,
                                            borderRadius: BorderRadius.all(Radius.circular(14)),
                                          ),
                                          child: Container(),
                                        ),
                                      ),
                                      Positioned(
                                        left: 15,
                                        top: 9,
                                        right: 9,
                                        bottom: 11,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.stretch,
                                          children: [
                                            Align(
                                              alignment: Alignment.topRight,
                                              child: Container(
                                                width: 15,
                                                height: 14,
                                                child: Image.asset(
                                                  "assets/images/favorite-heart-button-3.png",
                                                  fit: BoxFit.none,
                                                ),
                                              ),
                                            ),
                                            Align(
                                              alignment: Alignment.topCenter,
                                              child: Container(
                                                width: 110,
                                                height: 75,
                                                margin: EdgeInsets.only(top: 1),
                                                child: Image.asset(
                                                  "assets/images/burger-10963.png",
                                                  fit: BoxFit.none,
                                                ),
                                              ),
                                            ),
                                            Spacer(),
                                            Align(
                                              alignment: Alignment.topLeft,
                                              child: Container(
                                                margin: EdgeInsets.only(bottom: 5),
                                                child: Text(
                                                  "Hot Spicy Burger",
                                                  textAlign: TextAlign.left,
                                                  style: TextStyle(
                                                    color: AppColors.primaryText,
                                                    fontFamily: "Avenir",
                                                    fontWeight: FontWeight.w800,
                                                    fontSize: 14,
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Container(
                                              height: 17,
                                              margin: EdgeInsets.only(right: 6),
                                              child: Row(
                                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                                children: [
                                                  Align(
                                                    alignment: Alignment.bottomLeft,
                                                    child: Opacity(
                                                      opacity: 0.60156,
                                                      child: Text(
                                                        "\$14",
                                                        textAlign: TextAlign.left,
                                                        style: TextStyle(
                                                          color: AppColors.primaryText,
                                                          fontFamily: "Avenir",
                                                          fontWeight: FontWeight.w800,
                                                          fontSize: 12,
                                                          height: 1,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Spacer(),
                                                  Align(
                                                    alignment: Alignment.bottomLeft,
                                                    child: Container(
                                                      width: 37,
                                                      height: 12,
                                                      margin: EdgeInsets.only(bottom: 2),
                                                      child: Row(
                                                        children: [
                                                          Container(
                                                            width: 13,
                                                            height: 12,
                                                            child: Image.asset(
                                                              "assets/images/path-21.png",
                                                              fit: BoxFit.none,
                                                            ),
                                                          ),
                                                          Expanded(
                                                            flex: 1,
                                                            child: Container(
                                                              margin: EdgeInsets.only(left: 5, right: 3),
                                                              child: Opacity(
                                                                opacity: 0.59961,
                                                                child: Text(
                                                                  "4.5",
                                                                  textAlign: TextAlign.left,
                                                                  style: TextStyle(
                                                                    color: AppColors.primaryText,
                                                                    fontFamily: "Avenir",
                                                                    fontWeight: FontWeight.w400,
                                                                    fontSize: 12,
                                                                    height: 1.16667,
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Spacer(),
                              Align(
                                alignment: Alignment.topLeft,
                                child: Container(
                                  width: 166,
                                  height: 174,
                                  child: Stack(
                                    alignment: Alignment.center,
                                    children: [
                                      Positioned(
                                        left: 0,
                                        top: 14,
                                        right: 0,
                                        child: Opacity(
                                          opacity: 0.05,
                                          child: Container(
                                            height: 160,
                                            decoration: BoxDecoration(
                                              color: AppColors.ternaryBackground,
                                              borderRadius: BorderRadius.all(Radius.circular(14)),
                                            ),
                                            child: Container(),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        left: 0,
                                        right: 0,
                                        child: Container(
                                          height: 174,
                                          decoration: BoxDecoration(
                                            color: AppColors.secondaryBackground,
                                            borderRadius: BorderRadius.all(Radius.circular(14)),
                                          ),
                                          child: Container(),
                                        ),
                                      ),
                                      Positioned(
                                        left: 15,
                                        top: 9,
                                        right: 9,
                                        bottom: 11,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.stretch,
                                          children: [
                                            Align(
                                              alignment: Alignment.topRight,
                                              child: Container(
                                                width: 15,
                                                height: 14,
                                                child: Image.asset(
                                                  "assets/images/favorite-heart-button-2.png",
                                                  fit: BoxFit.none,
                                                ),
                                              ),
                                            ),
                                            Align(
                                              alignment: Alignment.topCenter,
                                              child: Container(
                                                width: 114,
                                                height: 73,
                                                margin: EdgeInsets.only(top: 1),
                                                child: Image.asset(
                                                  "assets/images/http-pluspngcom-img-png-png-hd-pizza-download-1356.png",
                                                  fit: BoxFit.none,
                                                ),
                                              ),
                                            ),
                                            Spacer(),
                                            Align(
                                              alignment: Alignment.topLeft,
                                              child: Container(
                                                margin: EdgeInsets.only(bottom: 5),
                                                child: Text(
                                                  "Neapolitan Pizza",
                                                  textAlign: TextAlign.left,
                                                  style: TextStyle(
                                                    color: AppColors.primaryText,
                                                    fontFamily: "Avenir",
                                                    fontWeight: FontWeight.w800,
                                                    fontSize: 14,
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Container(
                                              height: 17,
                                              margin: EdgeInsets.only(right: 6),
                                              child: Row(
                                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                                children: [
                                                  Align(
                                                    alignment: Alignment.bottomLeft,
                                                    child: Opacity(
                                                      opacity: 0.60156,
                                                      child: Text(
                                                        "\$20",
                                                        textAlign: TextAlign.left,
                                                        style: TextStyle(
                                                          color: AppColors.primaryText,
                                                          fontFamily: "Avenir",
                                                          fontWeight: FontWeight.w800,
                                                          fontSize: 12,
                                                          height: 1,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Spacer(),
                                                  Align(
                                                    alignment: Alignment.bottomLeft,
                                                    child: Container(
                                                      width: 37,
                                                      height: 12,
                                                      margin: EdgeInsets.only(bottom: 2),
                                                      child: Row(
                                                        children: [
                                                          Container(
                                                            width: 13,
                                                            height: 12,
                                                            child: Image.asset(
                                                              "assets/images/path-21.png",
                                                              fit: BoxFit.none,
                                                            ),
                                                          ),
                                                          Expanded(
                                                            flex: 1,
                                                            child: Container(
                                                              margin: EdgeInsets.only(left: 5, right: 3),
                                                              child: Opacity(
                                                                opacity: 0.59961,
                                                                child: Text(
                                                                  "4.3",
                                                                  textAlign: TextAlign.left,
                                                                  style: TextStyle(
                                                                    color: AppColors.primaryText,
                                                                    fontFamily: "Avenir",
                                                                    fontWeight: FontWeight.w400,
                                                                    fontSize: 12,
                                                                    height: 1.16667,
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          height: 174,
                          margin: EdgeInsets.only(top: 15),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Align(
                                alignment: Alignment.topLeft,
                                child: Container(
                                  width: 166,
                                  height: 174,
                                  child: Stack(
                                    alignment: Alignment.topCenter,
                                    children: [
                                      Positioned(
                                        left: 0,
                                        top: 0,
                                        right: 0,
                                        bottom: 0,
                                        child: Stack(
                                          alignment: Alignment.center,
                                          children: [
                                            Positioned(
                                              left: 0,
                                              top: 14,
                                              right: 0,
                                              child: Opacity(
                                                opacity: 0.05,
                                                child: Container(
                                                  height: 160,
                                                  decoration: BoxDecoration(
                                                    color: AppColors.ternaryBackground,
                                                    borderRadius: BorderRadius.all(Radius.circular(14)),
                                                  ),
                                                  child: Container(),
                                                ),
                                              ),
                                            ),
                                            Positioned(
                                              left: 0,
                                              right: 0,
                                              child: Container(
                                                height: 174,
                                                decoration: BoxDecoration(
                                                  color: AppColors.secondaryBackground,
                                                  borderRadius: BorderRadius.all(Radius.circular(14)),
                                                ),
                                                child: Container(),
                                              ),
                                            ),
                                            Positioned(
                                              left: 15,
                                              top: 9,
                                              right: 9,
                                              bottom: 11,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                                children: [
                                                  Align(
                                                    alignment: Alignment.topRight,
                                                    child: Container(
                                                      width: 15,
                                                      height: 14,
                                                      child: Image.asset(
                                                        "assets/images/favorite-heart-button-2.png",
                                                        fit: BoxFit.none,
                                                      ),
                                                    ),
                                                  ),
                                                  Spacer(),
                                                  Align(
                                                    alignment: Alignment.topLeft,
                                                    child: Container(
                                                      margin: EdgeInsets.only(bottom: 5),
                                                      child: Text(
                                                        "Beef Burgers",
                                                        textAlign: TextAlign.left,
                                                        style: TextStyle(
                                                          color: AppColors.primaryText,
                                                          fontFamily: "Avenir",
                                                          fontWeight: FontWeight.w800,
                                                          fontSize: 14,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    height: 17,
                                                    margin: EdgeInsets.only(right: 6),
                                                    child: Row(
                                                      crossAxisAlignment: CrossAxisAlignment.stretch,
                                                      children: [
                                                        Align(
                                                          alignment: Alignment.bottomLeft,
                                                          child: Opacity(
                                                            opacity: 0.60156,
                                                            child: Text(
                                                              "\$22",
                                                              textAlign: TextAlign.left,
                                                              style: TextStyle(
                                                                color: AppColors.primaryText,
                                                                fontFamily: "Avenir",
                                                                fontWeight: FontWeight.w800,
                                                                fontSize: 12,
                                                                height: 1,
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                        Spacer(),
                                                        Align(
                                                          alignment: Alignment.bottomLeft,
                                                          child: Container(
                                                            width: 37,
                                                            height: 12,
                                                            margin: EdgeInsets.only(bottom: 2),
                                                            child: Row(
                                                              children: [
                                                                Container(
                                                                  width: 13,
                                                                  height: 12,
                                                                  child: Image.asset(
                                                                    "assets/images/path-21.png",
                                                                    fit: BoxFit.none,
                                                                  ),
                                                                ),
                                                                Expanded(
                                                                  flex: 1,
                                                                  child: Container(
                                                                    margin: EdgeInsets.only(left: 5, right: 3),
                                                                    child: Opacity(
                                                                      opacity: 0.59961,
                                                                      child: Text(
                                                                        "4.0",
                                                                        textAlign: TextAlign.left,
                                                                        style: TextStyle(
                                                                          color: AppColors.primaryText,
                                                                          fontFamily: "Avenir",
                                                                          fontWeight: FontWeight.w400,
                                                                          fontSize: 12,
                                                                          height: 1.16667,
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Positioned(
                                        top: 20,
                                        child: Image.asset(
                                          "assets/images/burger-10956-3.png",
                                          fit: BoxFit.none,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Spacer(),
                              Align(
                                alignment: Alignment.topLeft,
                                child: Container(
                                  width: 166,
                                  height: 174,
                                  child: Stack(
                                    alignment: Alignment.topCenter,
                                    children: [
                                      Positioned(
                                        left: 0,
                                        top: 0,
                                        right: 0,
                                        bottom: 0,
                                        child: Stack(
                                          alignment: Alignment.center,
                                          children: [
                                            Positioned(
                                              left: 0,
                                              top: 14,
                                              right: 0,
                                              child: Opacity(
                                                opacity: 0.05,
                                                child: Container(
                                                  height: 160,
                                                  decoration: BoxDecoration(
                                                    color: AppColors.ternaryBackground,
                                                    borderRadius: BorderRadius.all(Radius.circular(14)),
                                                  ),
                                                  child: Container(),
                                                ),
                                              ),
                                            ),
                                            Positioned(
                                              left: 0,
                                              right: 0,
                                              child: Container(
                                                height: 174,
                                                decoration: BoxDecoration(
                                                  color: AppColors.secondaryBackground,
                                                  borderRadius: BorderRadius.all(Radius.circular(14)),
                                                ),
                                                child: Container(),
                                              ),
                                            ),
                                            Positioned(
                                              left: 15,
                                              top: 9,
                                              right: 9,
                                              bottom: 11,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                                children: [
                                                  Align(
                                                    alignment: Alignment.topRight,
                                                    child: Container(
                                                      width: 15,
                                                      height: 14,
                                                      child: Image.asset(
                                                        "assets/images/favorite-heart-button-3.png",
                                                        fit: BoxFit.none,
                                                      ),
                                                    ),
                                                  ),
                                                  Spacer(),
                                                  Align(
                                                    alignment: Alignment.topLeft,
                                                    child: Container(
                                                      margin: EdgeInsets.only(bottom: 5),
                                                      child: Text(
                                                        "Chicago Pizza",
                                                        textAlign: TextAlign.left,
                                                        style: TextStyle(
                                                          color: AppColors.primaryText,
                                                          fontFamily: "Avenir",
                                                          fontWeight: FontWeight.w800,
                                                          fontSize: 14,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    height: 17,
                                                    margin: EdgeInsets.only(right: 6),
                                                    child: Row(
                                                      crossAxisAlignment: CrossAxisAlignment.stretch,
                                                      children: [
                                                        Align(
                                                          alignment: Alignment.bottomLeft,
                                                          child: Opacity(
                                                            opacity: 0.60156,
                                                            child: Text(
                                                              "\$25",
                                                              textAlign: TextAlign.left,
                                                              style: TextStyle(
                                                                color: AppColors.primaryText,
                                                                fontFamily: "Avenir",
                                                                fontWeight: FontWeight.w800,
                                                                fontSize: 12,
                                                                height: 1,
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                        Spacer(),
                                                        Align(
                                                          alignment: Alignment.bottomLeft,
                                                          child: Container(
                                                            width: 37,
                                                            height: 12,
                                                            margin: EdgeInsets.only(bottom: 2),
                                                            child: Row(
                                                              children: [
                                                                Container(
                                                                  width: 13,
                                                                  height: 12,
                                                                  child: Image.asset(
                                                                    "assets/images/path-21.png",
                                                                    fit: BoxFit.none,
                                                                  ),
                                                                ),
                                                                Expanded(
                                                                  flex: 1,
                                                                  child: Container(
                                                                    margin: EdgeInsets.only(left: 5, right: 3),
                                                                    child: Opacity(
                                                                      opacity: 0.59961,
                                                                      child: Text(
                                                                        "3.9",
                                                                        textAlign: TextAlign.left,
                                                                        style: TextStyle(
                                                                          color: AppColors.primaryText,
                                                                          fontFamily: "Avenir",
                                                                          fontWeight: FontWeight.w400,
                                                                          fontSize: 12,
                                                                          height: 1.16667,
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Positioned(
                                        top: 20,
                                        child: Image.asset(
                                          "assets/images/20-pizza-png-image.png",
                                          fit: BoxFit.none,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          height: 174,
                          margin: EdgeInsets.only(top: 11),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Align(
                                alignment: Alignment.topLeft,
                                child: Container(
                                  width: 166,
                                  height: 174,
                                  child: Stack(
                                    alignment: Alignment.topCenter,
                                    children: [
                                      Positioned(
                                        left: 0,
                                        top: 0,
                                        right: 0,
                                        bottom: 0,
                                        child: Stack(
                                          alignment: Alignment.center,
                                          children: [
                                            Positioned(
                                              left: 0,
                                              top: 14,
                                              right: 0,
                                              child: Opacity(
                                                opacity: 0.05,
                                                child: Container(
                                                  height: 160,
                                                  decoration: BoxDecoration(
                                                    color: AppColors.ternaryBackground,
                                                    borderRadius: BorderRadius.all(Radius.circular(14)),
                                                  ),
                                                  child: Container(),
                                                ),
                                              ),
                                            ),
                                            Positioned(
                                              left: 0,
                                              right: 0,
                                              child: Container(
                                                height: 174,
                                                decoration: BoxDecoration(
                                                  color: AppColors.secondaryBackground,
                                                  borderRadius: BorderRadius.all(Radius.circular(14)),
                                                ),
                                                child: Container(),
                                              ),
                                            ),
                                            Positioned(
                                              left: 15,
                                              top: 9,
                                              right: 9,
                                              bottom: 11,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                                children: [
                                                  Align(
                                                    alignment: Alignment.topRight,
                                                    child: Container(
                                                      width: 15,
                                                      height: 14,
                                                      child: Image.asset(
                                                        "assets/images/favorite-heart-button-3.png",
                                                        fit: BoxFit.none,
                                                      ),
                                                    ),
                                                  ),
                                                  Spacer(),
                                                  Align(
                                                    alignment: Alignment.topLeft,
                                                    child: Container(
                                                      margin: EdgeInsets.only(bottom: 5),
                                                      child: Text(
                                                        "Elk Burgers",
                                                        textAlign: TextAlign.left,
                                                        style: TextStyle(
                                                          color: AppColors.primaryText,
                                                          fontFamily: "Avenir",
                                                          fontWeight: FontWeight.w800,
                                                          fontSize: 14,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    height: 17,
                                                    margin: EdgeInsets.only(right: 6),
                                                    child: Row(
                                                      crossAxisAlignment: CrossAxisAlignment.stretch,
                                                      children: [
                                                        Align(
                                                          alignment: Alignment.bottomLeft,
                                                          child: Opacity(
                                                            opacity: 0.60156,
                                                            child: Text(
                                                              "\$18",
                                                              textAlign: TextAlign.left,
                                                              style: TextStyle(
                                                                color: AppColors.primaryText,
                                                                fontFamily: "Avenir",
                                                                fontWeight: FontWeight.w800,
                                                                fontSize: 12,
                                                                height: 1,
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                        Spacer(),
                                                        Align(
                                                          alignment: Alignment.bottomLeft,
                                                          child: Container(
                                                            width: 37,
                                                            height: 12,
                                                            margin: EdgeInsets.only(bottom: 2),
                                                            child: Row(
                                                              children: [
                                                                Container(
                                                                  width: 13,
                                                                  height: 12,
                                                                  child: Image.asset(
                                                                    "assets/images/path-21.png",
                                                                    fit: BoxFit.none,
                                                                  ),
                                                                ),
                                                                Expanded(
                                                                  flex: 1,
                                                                  child: Container(
                                                                    margin: EdgeInsets.only(left: 5, right: 3),
                                                                    child: Opacity(
                                                                      opacity: 0.59961,
                                                                      child: Text(
                                                                        "3.8",
                                                                        textAlign: TextAlign.left,
                                                                        style: TextStyle(
                                                                          color: AppColors.primaryText,
                                                                          fontFamily: "Avenir",
                                                                          fontWeight: FontWeight.w400,
                                                                          fontSize: 12,
                                                                          height: 1.16667,
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Positioned(
                                        top: 15,
                                        child: Image.asset(
                                          "assets/images/burger-10917-4.png",
                                          fit: BoxFit.none,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Spacer(),
                              Align(
                                alignment: Alignment.topLeft,
                                child: Container(
                                  width: 166,
                                  height: 174,
                                  child: Stack(
                                    alignment: Alignment.topCenter,
                                    children: [
                                      Positioned(
                                        left: 0,
                                        top: 0,
                                        right: 0,
                                        bottom: 0,
                                        child: Stack(
                                          alignment: Alignment.center,
                                          children: [
                                            Positioned(
                                              left: 0,
                                              top: 14,
                                              right: 0,
                                              child: Opacity(
                                                opacity: 0.05,
                                                child: Container(
                                                  height: 160,
                                                  decoration: BoxDecoration(
                                                    color: AppColors.ternaryBackground,
                                                    borderRadius: BorderRadius.all(Radius.circular(14)),
                                                  ),
                                                  child: Container(),
                                                ),
                                              ),
                                            ),
                                            Positioned(
                                              left: 0,
                                              right: 0,
                                              child: Container(
                                                height: 174,
                                                decoration: BoxDecoration(
                                                  color: AppColors.secondaryBackground,
                                                  borderRadius: BorderRadius.all(Radius.circular(14)),
                                                ),
                                                child: Container(),
                                              ),
                                            ),
                                            Positioned(
                                              left: 15,
                                              top: 9,
                                              right: 9,
                                              bottom: 11,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                                children: [
                                                  Align(
                                                    alignment: Alignment.topRight,
                                                    child: Container(
                                                      width: 15,
                                                      height: 14,
                                                      child: Image.asset(
                                                        "assets/images/favorite-heart-button-2.png",
                                                        fit: BoxFit.none,
                                                      ),
                                                    ),
                                                  ),
                                                  Spacer(),
                                                  Align(
                                                    alignment: Alignment.topLeft,
                                                    child: Container(
                                                      margin: EdgeInsets.only(bottom: 5),
                                                      child: Text(
                                                        "Sicilian Pizza",
                                                        textAlign: TextAlign.left,
                                                        style: TextStyle(
                                                          color: AppColors.primaryText,
                                                          fontFamily: "Avenir",
                                                          fontWeight: FontWeight.w800,
                                                          fontSize: 14,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    height: 17,
                                                    margin: EdgeInsets.only(right: 6),
                                                    child: Row(
                                                      crossAxisAlignment: CrossAxisAlignment.stretch,
                                                      children: [
                                                        Align(
                                                          alignment: Alignment.bottomLeft,
                                                          child: Opacity(
                                                            opacity: 0.60156,
                                                            child: Text(
                                                              "\$30",
                                                              textAlign: TextAlign.left,
                                                              style: TextStyle(
                                                                color: AppColors.primaryText,
                                                                fontFamily: "Avenir",
                                                                fontWeight: FontWeight.w800,
                                                                fontSize: 12,
                                                                height: 1,
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                        Spacer(),
                                                        Align(
                                                          alignment: Alignment.bottomLeft,
                                                          child: Container(
                                                            width: 37,
                                                            height: 12,
                                                            margin: EdgeInsets.only(bottom: 2),
                                                            child: Row(
                                                              children: [
                                                                Container(
                                                                  width: 13,
                                                                  height: 12,
                                                                  child: Image.asset(
                                                                    "assets/images/path-21.png",
                                                                    fit: BoxFit.none,
                                                                  ),
                                                                ),
                                                                Expanded(
                                                                  flex: 1,
                                                                  child: Container(
                                                                    margin: EdgeInsets.only(left: 5, right: 3),
                                                                    child: Opacity(
                                                                      opacity: 0.59961,
                                                                      child: Text(
                                                                        "3.5",
                                                                        textAlign: TextAlign.left,
                                                                        style: TextStyle(
                                                                          color: AppColors.primaryText,
                                                                          fontFamily: "Avenir",
                                                                          fontWeight: FontWeight.w400,
                                                                          fontSize: 12,
                                                                          height: 1.16667,
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Positioned(
                                        top: 20,
                                        child: Image.asset(
                                          "assets/images/19-pizza-png-image.png",
                                          fit: BoxFit.none,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Spacer(),
                        Container(
                          height: 174,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Align(
                                alignment: Alignment.bottomLeft,
                                child: Container(
                                  width: 166,
                                  height: 174,
                                  child: Stack(
                                    alignment: Alignment.center,
                                    children: [
                                      Positioned(
                                        left: 0,
                                        top: 14,
                                        right: 0,
                                        child: Opacity(
                                          opacity: 0.05,
                                          child: Container(
                                            height: 160,
                                            decoration: BoxDecoration(
                                              color: AppColors.ternaryBackground,
                                              borderRadius: BorderRadius.all(Radius.circular(14)),
                                            ),
                                            child: Container(),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        left: 0,
                                        right: 0,
                                        child: Container(
                                          height: 174,
                                          decoration: BoxDecoration(
                                            color: AppColors.secondaryBackground,
                                            borderRadius: BorderRadius.all(Radius.circular(14)),
                                          ),
                                          child: Container(),
                                        ),
                                      ),
                                      Positioned(
                                        left: 15,
                                        top: 9,
                                        right: 9,
                                        bottom: 11,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.stretch,
                                          children: [
                                            Align(
                                              alignment: Alignment.topRight,
                                              child: Container(
                                                width: 15,
                                                height: 14,
                                                child: Image.asset(
                                                  "assets/images/favorite-heart-button-2.png",
                                                  fit: BoxFit.none,
                                                ),
                                              ),
                                            ),
                                            Spacer(),
                                            Align(
                                              alignment: Alignment.topLeft,
                                              child: Container(
                                                margin: EdgeInsets.only(bottom: 5),
                                                child: Text(
                                                  "Mushroom Burgers",
                                                  textAlign: TextAlign.left,
                                                  style: TextStyle(
                                                    color: AppColors.primaryText,
                                                    fontFamily: "Avenir",
                                                    fontWeight: FontWeight.w800,
                                                    fontSize: 14,
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Container(
                                              height: 17,
                                              margin: EdgeInsets.only(right: 6),
                                              child: Row(
                                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                                children: [
                                                  Align(
                                                    alignment: Alignment.bottomLeft,
                                                    child: Opacity(
                                                      opacity: 0.60156,
                                                      child: Text(
                                                        "\$15",
                                                        textAlign: TextAlign.left,
                                                        style: TextStyle(
                                                          color: AppColors.primaryText,
                                                          fontFamily: "Avenir",
                                                          fontWeight: FontWeight.w800,
                                                          fontSize: 12,
                                                          height: 1,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Spacer(),
                                                  Align(
                                                    alignment: Alignment.bottomLeft,
                                                    child: Container(
                                                      width: 37,
                                                      height: 12,
                                                      margin: EdgeInsets.only(bottom: 2),
                                                      child: Row(
                                                        children: [
                                                          Container(
                                                            width: 13,
                                                            height: 12,
                                                            child: Image.asset(
                                                              "assets/images/path-21.png",
                                                              fit: BoxFit.none,
                                                            ),
                                                          ),
                                                          Expanded(
                                                            flex: 1,
                                                            child: Container(
                                                              margin: EdgeInsets.only(left: 5, right: 3),
                                                              child: Opacity(
                                                                opacity: 0.59961,
                                                                child: Text(
                                                                  "3.4",
                                                                  textAlign: TextAlign.left,
                                                                  style: TextStyle(
                                                                    color: AppColors.primaryText,
                                                                    fontFamily: "Avenir",
                                                                    fontWeight: FontWeight.w400,
                                                                    fontSize: 12,
                                                                    height: 1.16667,
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Positioned(
                                        left: 17,
                                        top: 18,
                                        right: 19,
                                        child: Image.asset(
                                          "assets/images/burger-10909.png",
                                          fit: BoxFit.none,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Spacer(),
                              Align(
                                alignment: Alignment.bottomLeft,
                                child: Container(
                                  width: 166,
                                  height: 174,
                                  child: Stack(
                                    alignment: Alignment.topCenter,
                                    children: [
                                      Positioned(
                                        left: 0,
                                        top: 0,
                                        right: 0,
                                        bottom: 0,
                                        child: Stack(
                                          alignment: Alignment.center,
                                          children: [
                                            Positioned(
                                              left: 0,
                                              top: 14,
                                              right: 0,
                                              child: Opacity(
                                                opacity: 0.05,
                                                child: Container(
                                                  height: 160,
                                                  decoration: BoxDecoration(
                                                    color: AppColors.ternaryBackground,
                                                    borderRadius: BorderRadius.all(Radius.circular(14)),
                                                  ),
                                                  child: Container(),
                                                ),
                                              ),
                                            ),
                                            Positioned(
                                              left: 0,
                                              right: 0,
                                              child: Container(
                                                height: 174,
                                                decoration: BoxDecoration(
                                                  color: AppColors.secondaryBackground,
                                                  borderRadius: BorderRadius.all(Radius.circular(14)),
                                                ),
                                                child: Container(),
                                              ),
                                            ),
                                            Positioned(
                                              left: 15,
                                              top: 9,
                                              right: 9,
                                              bottom: 11,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                                children: [
                                                  Align(
                                                    alignment: Alignment.topRight,
                                                    child: Container(
                                                      width: 15,
                                                      height: 14,
                                                      child: Image.asset(
                                                        "assets/images/favorite-heart-button-3.png",
                                                        fit: BoxFit.none,
                                                      ),
                                                    ),
                                                  ),
                                                  Spacer(),
                                                  Align(
                                                    alignment: Alignment.topLeft,
                                                    child: Container(
                                                      margin: EdgeInsets.only(bottom: 5),
                                                      child: Text(
                                                        "Detroit Pizza",
                                                        textAlign: TextAlign.left,
                                                        style: TextStyle(
                                                          color: AppColors.primaryText,
                                                          fontFamily: "Avenir",
                                                          fontWeight: FontWeight.w800,
                                                          fontSize: 14,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    height: 17,
                                                    margin: EdgeInsets.only(right: 6),
                                                    child: Row(
                                                      crossAxisAlignment: CrossAxisAlignment.stretch,
                                                      children: [
                                                        Align(
                                                          alignment: Alignment.bottomLeft,
                                                          child: Opacity(
                                                            opacity: 0.60156,
                                                            child: Text(
                                                              "\$35",
                                                              textAlign: TextAlign.left,
                                                              style: TextStyle(
                                                                color: AppColors.primaryText,
                                                                fontFamily: "Avenir",
                                                                fontWeight: FontWeight.w800,
                                                                fontSize: 12,
                                                                height: 1,
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                        Spacer(),
                                                        Align(
                                                          alignment: Alignment.bottomLeft,
                                                          child: Container(
                                                            width: 37,
                                                            height: 12,
                                                            margin: EdgeInsets.only(bottom: 2),
                                                            child: Row(
                                                              children: [
                                                                Container(
                                                                  width: 13,
                                                                  height: 12,
                                                                  child: Image.asset(
                                                                    "assets/images/path-21.png",
                                                                    fit: BoxFit.none,
                                                                  ),
                                                                ),
                                                                Expanded(
                                                                  flex: 1,
                                                                  child: Container(
                                                                    margin: EdgeInsets.only(left: 5, right: 3),
                                                                    child: Opacity(
                                                                      opacity: 0.59961,
                                                                      child: Text(
                                                                        "3.3",
                                                                        textAlign: TextAlign.left,
                                                                        style: TextStyle(
                                                                          color: AppColors.primaryText,
                                                                          fontFamily: "Avenir",
                                                                          fontWeight: FontWeight.w400,
                                                                          fontSize: 12,
                                                                          height: 1.16667,
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Positioned(
                                        top: 20,
                                        child: Image.asset(
                                          "assets/images/35-pizza-png-image.png",
                                          fit: BoxFit.none,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Positioned(
              top: 338,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Align(
                    alignment: Alignment.topRight,
                    child: Container(
                      width: 30,
                      height: 30,
                      margin: EdgeInsets.only(right: 20),
                      child: Image.asset(
                        "assets/images/clock.png",
                        fit: BoxFit.none,
                      ),
                    ),
                  ),
                  Expanded(
                    flex: 1,
                    child: Container(
                      margin: EdgeInsets.only(top: 6),
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          Positioned(
                            left: 17,
                            top: 0,
                            right: 17,
                            child: Text(
                              "Open",
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: AppColors.primaryText,
                                fontFamily: "Avenir",
                                fontWeight: FontWeight.w800,
                                fontSize: 14,
                                height: 1,
                              ),
                            ),
                          ),
                          Positioned(
                            left: 0,
                            right: 0,
                            bottom: 0,
                            child: Opacity(
                              opacity: 0.59961,
                              child: Text(
                                "10am - 11am",
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  color: AppColors.primaryText,
                                  fontFamily: "Avenir",
                                  fontWeight: FontWeight.w400,
                                  fontSize: 12,
                                  height: 1,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}