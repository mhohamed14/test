/*
*  borders.dart
*  Food UI Kit
*
*  Created by [Author].
*  Copyright © 2018 [Company]. All rights reserved.
    */

import 'package:flutter/rendering.dart';


class Borders {
  static const BorderSide primaryBorder = BorderSide(
    color: Color.fromARGB(255, 237, 240, 242),
    width: 1,
    style: BorderStyle.solid,
  );
  static const BorderSide secondaryBorder = BorderSide(
    color: Color.fromARGB(255, 243, 243, 243),
    width: 1,
    style: BorderStyle.solid,
  );
}